function BotoAudio( index,  botton) {
	
  	this.width = 58;
  	this.height = 58;
  	this.index = index;

	var _imgLoaded = new Image(); 
	
	
	_imgLoaded.src = (Motor.grado == 1)? pppPreloader.from("module", 'motor/images/btnAudio.png') : pppPreloader.from("module", 'motor/images/btnAudioPetit.png');
	var ample = (Motor.grado == 1)? 58 : 41;
	var alt = (Motor.grado == 1)? 58 : 38;
//	_imgLoaded.name = 'tancar';

	var data = {
	    images: [_imgLoaded],
	    frames: { width: ample, height: alt},
	    animations: { normal: [0], hover: [2], play:{ frames: [2,3,4,5,6,7,8,9] , next: "play", speed: 0.5}}
	};
	var spriteSheet = new createjs.SpriteSheet(data);
	this.bt = new createjs.Sprite(spriteSheet);
	
	// the code block in this helper.addEventListener (It works with button.addEventListener)
	
	this.bt.on("mouseover", function(evt){ if( $('#audio'+this.index)[0].paused)  this.bt.gotoAndStop("hover"); document.body.style.cursor='pointer';},this);
	this.bt.on("mouseout", function(evt){ if($('#audio'+this.index)[0].paused) this.bt.gotoAndStop("normal"); document.body.style.cursor='default';},this);
	
	/*this.bt.on("mouseover", function(evt){ if( this.botton.stopped )  this.bt.gotoAndStop("hover"); document.body.style.cursor='pointer';},this);
	this.bt.on("mouseout", function(evt){ if( this.botton.stopped ) this.bt.gotoAndStop("normal"); document.body.style.cursor='default';},this);*/

	this.bt.x = 0;
	this.bt.y = 0;
	this.bt.gotoAndStop("normal");
 }
function AudioBoxPrimaria(resposta,  index)
{

	this.contenedor = new createjs.Container();
//	console.log(index);
	this.id  = index;
	this.correcte = false;
	this.stopped = true;

	//debugger;
	this.contesta = new createjs.RichText();
    this.contesta.text = "";
    this.contesta.font =  "16px Arial" ;
	this.contesta.fontSize =  16;
	this.contesta.color = "#E1001A";
	this.contesta.x = 2;
	this.contesta.y = 84+60+5 ;
	this.contesta.lineWidth = 285;
	this.contesta.lineHeight = 22;
	this.contesta.mouseEnabled = false;
	
	this.fonsInput = new createjs.Shape();
	this.fonsInput.graphics.beginFill("#fff").drawRoundRect(0, 0, 285, 84, 5);
	
	this.marcInput = new createjs.Shape();
	this.marcInput.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 285, 84, 5);
	
	this.areaText = new createjs.Container();
	this.areaText.x = 0;
	this.areaText.y = 60;

	this.areaText.addChild( this.fonsInput );
	this.areaText.addChild( this.marcInput );
	
	this.bt = new BotoAudio(this.id, this);
	this.bt.x = 0;
	this.bt.y = 0;
	
	//$('<input type="text" id="input'+index+'"/>').appendTo($("#mediaHolder"));
	var $input = $('<textarea type="text" id="input'+index+'" class="input"/>');
    //$input.tabindex = i+1;

	$("#mediaHolder").append($input);
	
	
	//$input.css("width","275px");
	//$input.css("height","95px");
	this.inputDOM = new createjs.DOMElementCustom($input.attr("id"), this.contenedor);
	
	this.inputDOM.element_x = 5;
	this.inputDOM.element_y = 65;
	this.inputDOM.element_width = 275;
	this.inputDOM.element_height = 75;
	this.inputDOM.fontsize = 17;
	
	this.inputDOM.x = this.inputDOM.element_x ;
	this.inputDOM.y = this.inputDOM.element_y ;
	$(this.inputDOM.htmlElement).css("width",this.inputDOM.element_width);
	$(this.inputDOM.htmlElement).css("height",this.inputDOM.element_height );
	
	this.contenedor.addChild( this.areaText );
	this.contenedor.addChild( this.bt.bt );
	this.contenedor.addChild( this.inputDOM );
	this.contenedor.addChild( this.contesta );

	this.bt.bt.on("mousedown", this.pressHandler, this);
	
	var index = Main.navegador.split(' ')[0].indexOf("IE");
    var mobil = Main.mobil;
	if(index > -1 && mobil =="Tablet"){
        $input.focusout(function(event){ $("body").focus(); });
        $(this.inputDOM.htmlElement).click(this.select);
    }
	
	//this.desactivar();

}
AudioBoxPrimaria.prototype.select = function(){
	$(this).blur().focus();
}
AudioBoxPrimaria.prototype.pressHandler = function(){

	if( $('#audio'+this.id)[0].paused ) 
	{
		for( key in Motor.audios)
		{
			if( !$('#audio'+Motor.audios[key].id)[0].paused )
			{
				Motor.audios[key].bt.bt.gotoAndStop("normal");
				$('#audio'+Motor.audios[key].id)[0].pause();
				$('#audio'+Motor.audios[key].id)[0].currentTime = 0;
			}
		}
		
		//$('#audio'+this.id)[0].load(); 
		$('#audio'+this.id)[0].play(); 
		this.bt.bt.gotoAndPlay("play");
		$('#audio'+this.id)[0].addEventListener("ended",this.final);
	}
	else 
	{
		$('#audio'+this.id)[0].pause(); 
		$('#audio'+this.id)[0].currentTime = 0;
		this.bt.bt.gotoAndStop("normal");
	}
	/*createjs.Sound.stop();
	if( this.stopped )
	{
		var instance = createjs.Sound.play('audio'+this.id); // play using id.  Could also use full sourcepath or event.src.
		instance.addEventListener("complete", createjs.proxy(this.final, instance));
		this.bt.bt.gotoAndPlay("play");
	}else{
		this.bt.bt.gotoAndStop("normal");
	}
		
	this.stopped = !this.stopped ;*/
	 
}
AudioBoxPrimaria.prototype.final= function(){
	for( key in Motor.audios)
	{
		if(Motor.audios[key].id == this.id[5])
		{
			Motor.audios[key].bt.bt.gotoAndStop("normal");
		}
	}
}
AudioBoxPrimaria.prototype.desactivar = function()
{
	this.bt.bt.removeAllEventListeners();
}
AudioBoxPrimaria.prototype.activar = function()
{
	if( !this.bt.bt.hasEventListener("mousedown") )
	{
	   this.bt.bt.on("mousedown", this.pressHandler, this);
	}
}
AudioBoxPrimaria.prototype.setCorreccio = function( correcio )
{
	this.contesta.text = correcio;
}
AudioBoxPrimaria.prototype.clear = function(){

	this.marcInput.graphics.clear();
	this.marcInput.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 285, 84, 5);

}
AudioBoxPrimaria.prototype.error = function(){

	this.marcInput.graphics.beginStroke("#E1001A").setStrokeStyle(2).drawRoundRect(0, 0, 285, 84, 5);
	this.correcte = false;
}

AudioBoxPrimaria.prototype.correct = function(){

	this.marcInput.graphics.beginStroke("#41A62A").setStrokeStyle(2).drawRoundRect(0, 0, 285, 84, 5);
	this.correcte = true;
}

function AudioBoxSecundaria(resposta,  index)
{

	this.contenedor = new createjs.Container();
//	console.log(index);
	this.id  = index;
	this.correcte = false;

	this.ample = ( Motor.datosXML.anchoespecial == 0 )? 175 : 385;

	//debugger;
	this.contesta = new createjs.RichText();
    this.contesta.text = "";
    this.contesta.font = "14px Arial" ;
	this.contesta.fontSize =  14 ;
	this.contesta.color = "#E1001A";
	this.contesta.x = 45;
	this.contesta.y = 84+20+5 ;
	this.contesta.lineWidth = this.ample ;
	this.contesta.lineHeight = 19;
	this.contesta.mouseEnabled = false;

	this.fonsInput = new createjs.Shape();
	this.fonsInput.graphics.beginFill("#fff").drawRoundRect(0, 0, this.ample, 100, 5);
	
	this.marcInput  = new createjs.Shape();
	this.marcInput .graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, this.ample, 100, 5);
	
	this.areaText = new createjs.Container();
	this.areaText.x = 46;
	this.areaText.y = 0;

	this.areaText.addChild( this.fonsInput );
	this.areaText.addChild( this.marcInput );
	
	
	this.bt = new BotoAudio(this.id, this);
	this.bt.x = 0;
	this.bt.y = 0;
	
	//$('<input type="text" id="input'+index+'"/>').appendTo($("#mediaHolder"));
	var $input = $('<textarea type="text" id="input'+index+'" tabindex="'+ (index+1) +'" class="input" />');


    var navegador = Main.navegador.split(' ')[0].indexOf("IE");
    var mobil = Main.mobil;

	if(navegador > -1 && mobil =="Tablet"){
        $input.focusout(function(event){ $("body").focus(); });
    }
	$("#mediaHolder").append($input);
	//$input.css("width","275px");
	//$input.css("height","95px");
	this.inputDOM = new createjs.DOMElementCustom($input.attr("id"), this.contenedor);
	
	this.inputDOM.element_x = 51;
	this.inputDOM.element_y = 5;
	this.inputDOM.element_width = this.ample-10;
	this.inputDOM.element_height = 90;
	this.inputDOM.fontsize = 16;
	
	this.inputDOM.x = this.inputDOM.element_x ;
	this.inputDOM.y = this.inputDOM.element_y ;
	$(this.inputDOM.htmlElement).css("width",this.inputDOM.element_width);
	$(this.inputDOM.htmlElement).css("height",this.inputDOM.element_height );
	
	this.contenedor.addChild( this.areaText );
	this.contenedor.addChild( this.bt.bt );
	this.contenedor.addChild( this.inputDOM );
	this.contenedor.addChild( this.contesta );

	this.bt.bt.on("mousedown", this.pressHandler, this);
	
	$(this.inputDOM.htmlElement).click(this.select);
	//this.desactivar();

}
AudioBoxSecundaria.prototype.select = function(){
	$(this).focus();
}
AudioBoxSecundaria.prototype.pressHandler = function(){
	//console.log($('#audio'+this.id)[0].paused);
	//$('#audio'+this.id)[0].trigger("click");
	if( $('#audio'+this.id)[0].paused ) 
	{
		for( key in Motor.audios)
		{
			if( !$('#audio'+Motor.audios[key].id)[0].paused )
			{
				Motor.audios[key].bt.bt.gotoAndStop("normal");
				$('#audio'+Motor.audios[key].id)[0].pause();
				$('#audio'+Motor.audios[key].id)[0].currentTime = 0;
			}
		}
		
		//$('#audio'+this.id)[0].load(); 
		$('#audio'+this.id)[0].play(); 
		this.bt.bt.gotoAndPlay("play");
		$('#audio'+this.id)[0].addEventListener("ended",this.final);
	}
	else 
	{
		$('#audio'+this.id)[0].pause(); 
		$('#audio'+this.id)[0].currentTime = 0;
		this.bt.bt.gotoAndStop("normal");
	}
	 
}
AudioBoxSecundaria.prototype.final= function(){
	for( key in Motor.audios)
	{
		if(Motor.audios[key].id == this.id[5])
		{
			Motor.audios[key].bt.bt.gotoAndStop("normal");
		}
	}
}
AudioBoxSecundaria.prototype.desactivar = function()
{
	this.bt.bt.removeAllEventListeners();
}
AudioBoxSecundaria.prototype.activar = function()
{
	if( !this.bt.bt.hasEventListener("mousedown") )
	{
	   this.bt.bt.on("mousedown", this.pressHandler, this);
	}
}
AudioBoxSecundaria.prototype.setCorreccio = function( correcio )
{
	this.contesta.text = correcio;
}
AudioBoxSecundaria.prototype.clear = function(){

	this.marcInput.graphics.clear();
	this.marcInput.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, this.ample, 100, 5);

}
AudioBoxSecundaria.prototype.error = function(){

	this.marcInput.graphics.beginStroke("#E1001A").setStrokeStyle(2).drawRoundRect(0, 0, this.ample, 100, 5);
	this.correcte = false;
}

AudioBoxSecundaria.prototype.correct = function(){

	this.marcInput.graphics.beginStroke("#41A62A").setStrokeStyle(2).drawRoundRect(0, 0, this.ample, 100, 5);
	this.correcte = true;
}
