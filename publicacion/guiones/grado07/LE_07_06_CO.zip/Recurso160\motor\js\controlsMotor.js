


function LineaItem( index, paraules)
{
	this.contenedor = new createjs.Container();
	this.id  = index;
	
	this.xpos = 0;
	for( key2 in paraules)
	{
		//console.log(paraules[key2]);
		paraules[key2].contenedor.x = this.xpos;
		paraules[key2].contenedor.y = 0;
		this.contenedor.addChild( paraules[key2].contenedor );
		
		this.xpos += paraules[key2].texto.getMeasuredWidth()+7;
	}

}

function ParaulaEditItem(){
	this.contenedor = new createjs.Container();
	this.correcte = false;
	this.Y = ( Main.navegador.indexOf("Firefox") >=0 )? -6 : -4;
	this.inputDOM = new createjs.DOMElementCustom(Motor.input.attr("id"), this.contenedor);
	
	this.inputDOM.element_x = 0;
	this.inputDOM.element_y = 3 + this.Y;
	this.inputDOM.element_width = 175;
	this.inputDOM.element_height = 22;
	this.inputDOM.fontsize = (Contenedor.datosXML.plataforma.grado == 1)? 18 : 16 ;
	
	this.inputDOM.x = this.inputDOM.element_x ;
	this.inputDOM.y = this.inputDOM.element_y ;
	//this.inputDOM.grandParent = Motor.contenedor;
	$( this.inputDOM.htmlElement ).css("width", this.inputDOM.element_width  );
	$( this.inputDOM.htmlElement ).css("height", this.inputDOM.element_height );

	this.contenedor.addChild( this.inputDOM );
	
	this.marc = new createjs.Shape();
	this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(-3, this.Y, 181, 25, 4);
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(-3, this.Y, 181, 25, 4);
	//this.fons.graphics.beginFill("#fde8f2").drawRoundRect(-5, 0, this.texto.getMeasuredWidth() + 10 , 25, 4);
		
	
	this.fonsTotal = new createjs.Shape();
	this.fonsTotal.graphics.beginFill("#777777").drawRoundRect(0, 0, /*width*/Main.stage_width  , /*height*/Main.stage_height, 4);
	this.fonsTotal.alpha = 0.2;
	this.contenedor.addChild( this.fonsTotal ) ;
	
	this.contenedor.addChild( this.fons );
	this.contenedor.addChild( this.marc );
	this.contenedor.addChild( this.texto );
	
	this.contenedor.on("mousedown", this.pressHandler, this);

}

ParaulaEditItem.prototype.pressHandler = function(){
	Main.stage.removeChild(this.contenedor);
	$( this.inputDOM.htmlElement ).css("display", "none");
	Main.setFocus(false);
	Motor.currentPalabra.setTexto(this.inputDOM.htmlElement.value);
}

ParaulaEditItem.prototype.activar = function()
{
	this.fonsTotal.x = -this.contenedor.x;
	this.fonsTotal.y = -this.contenedor.y;
	
	$( this.inputDOM.htmlElement ).css("display", "inline");
	Main.setFocus(this.inputDOM.htmlElement);
}

function ParaulaItem( index, paraula, paraulaCorrecte)
{
	this.Y = ( Main.navegador.indexOf("Firefox") >=0 )? -6 : -4;
	this.contenedor = new createjs.Container();
	this.textoCorrecto = paraulaCorrecte;
	this.textInicial = paraula;
	this.id  = index;
	this.correcte = false;
	this.parent = null;
	this.changed = false;
	this.toCorrect = false;
	
	this.texto = new createjs.Text();
    this.texto.text = paraula;
    this.texto.font = (Contenedor.datosXML.plataforma.grado == 1)? "18px Arial" : "16px Arial" ;
	//this.texto.fontSize = 18;
	this.texto.color = "#0D3158";

	this.contenedor.addChild( this.texto );
	
	this.marc = new createjs.Shape();
	//this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(0.5).drawRoundRect(-5, -5, this.texto.getMeasuredWidth() + 10 , 25, 4);
	
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fde8c2").drawRoundRect(-3, this.Y, this.texto.getMeasuredWidth() + 6 , 25, 4);
	//this.fons.graphics.beginFill("#fde8f2").drawRoundRect(-5, 0, this.texto.getMeasuredWidth() + 10 , 25, 4);

	this.contenedor.addChild( this.fons );
	this.contenedor.addChild( this.marc );
	this.contenedor.addChild( this.texto );

	this.contenedor.on("mousedown", this.pressHandler, this);
	this.contenedor.on("rollover", this.overHandler, this);
	this.contenedor.on("rollout", this.outHandler, this);
	//this.desactivar();

}

ParaulaItem.prototype.overHandler = function()
{
	if( !this.changed ) this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(-3, this.Y, this.texto.getMeasuredWidth() + 6 , 25, 4);
	document.body.style.cursor='pointer'; 
}

ParaulaItem.prototype.outHandler = function()
{
	if( !this.changed ) this.marc.graphics.clear();
	document.body.style.cursor='default';
	//this.setTexto("Holitatatata");
}

ParaulaItem.prototype.setTexto = function(_texto){

	if(this.textInicial != _texto) this.changed = true;
	else this.changed = false;
	
	this.texto.text = _texto;
	
	if(this.changed)
	{
		this.fons.graphics.clear();
		this.fons.graphics.beginFill("#fff").drawRoundRect(-3, this.Y, this.texto.getMeasuredWidth() + 6 , 25, 4);
		this.marc.graphics.clear();
		this.marc.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(-3,this.Y, this.texto.getMeasuredWidth() + 6 , 25, 4);
	}
	else{
		this.fons.graphics.clear();
		this.fons.graphics.beginFill("#fde8c2").drawRoundRect(-3, this.Y, this.texto.getMeasuredWidth() + 6 , 25, 4);
		this.marc.graphics.clear();
	}
	
	Motor.refrescarPalabras();
}
ParaulaItem.prototype.pressHandler = function(){
	Motor.currentPalabra = this;
	var paraulaEdit = new ParaulaEditItem();
	//debugger;
	if(this.contenedor.parent.x  +  this.contenedor.x + 181 < Main.stage_width )
	{
		paraulaEdit.contenedor.x = this.contenedor.parent.x  +  this.contenedor.x;
	}
	else
	{
		paraulaEdit.contenedor.x = Main.stage_width - 181 - 25;
	}
	
	paraulaEdit.contenedor.y = Motor.contenedor.y + this.contenedor.parent.y  + this.contenedor.y;
	
	paraulaEdit.inputDOM.htmlElement.value= this.texto.text;
	paraulaEdit.activar();
	
	Motor.paraulaEdit = paraulaEdit;
	
	Main.stage.addChild(paraulaEdit.contenedor);
}
ParaulaItem.prototype.final = function(){
	for( key in Motor.audios)
	{
		if(Motor.audios[key].id == this.id[5])
		{
			Motor.audios[key].bt.bt.gotoAndStop("normal");
		}
	}
}
ParaulaItem.prototype.desactivar = function()
{
	this.contenedor.removeAllEventListeners();
}
ParaulaItem.prototype.activar = function()
{
	
	if( !this.contenedor.hasEventListener("mousedown") )
	{
	    this.contenedor.on("mousedown", this.pressHandler, this);
	   	this.contenedor.on("rollover", this.overHandler, this);
	    this.contenedor.on("rollout", this.outHandler, this);
	}
}
ParaulaItem.prototype.setCorreccio = function( correcio )
{
	this.texto.text = correcio;
	this.marc.graphics.clear();
	this.fons.graphics.clear();
	this.fons.graphics.beginFill("#fde8c2").drawRoundRect(-3, this.Y, this.texto.getMeasuredWidth() + 6 , 25, 4);
}
ParaulaItem.prototype.clear = function(){
	this.marc.graphics.clear();
	this.fons.graphics.clear();
	this.fons.graphics.beginFill("#fde8c2").drawRoundRect(-3, this.Y, this.texto.getMeasuredWidth() + 6 , 25, 4);
}
ParaulaItem.prototype.error = function(){
	this.marc.graphics.clear();
	this.fons.graphics.clear();
	this.fons.graphics.beginFill("#fff").drawRoundRect(-3, this.Y, this.texto.getMeasuredWidth() + 6 , 25, 4);
	this.marc.graphics.beginStroke("#E1001A").setStrokeStyle(2).drawRoundRect(-3, this.Y, this.texto.getMeasuredWidth() + 6 , 25, 4);
	this.correcte = false;
}

ParaulaItem.prototype.correct = function(){
	this.marc.graphics.clear();
	this.fons.graphics.clear();
	this.fons.graphics.beginFill("#fff").drawRoundRect(-3, this.Y, this.texto.getMeasuredWidth() + 6 , 25, 4);
	this.marc.graphics.beginStroke("#41A62A").setStrokeStyle(2).drawRoundRect(-3, this.Y, this.texto.getMeasuredWidth() + 6 , 25, 4);
	this.correcte = true;
}
