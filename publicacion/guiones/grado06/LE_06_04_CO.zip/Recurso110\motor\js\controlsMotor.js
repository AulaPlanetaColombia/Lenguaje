function TextInputBox( index, grand)
{

	this.contenedor = new createjs.Container();
//	console.log(index);
	this.id  = index;
	this.correcte = false;
	//this.textCorrecte = resposta.text;
	
	this.fonsInput = new createjs.Shape();
	this.fonsInput.graphics.beginFill("#fff").drawRoundRect(0, 0, Motor.RESP_WIDTH, Motor.RESP_HEIGHT , 5);
	
	this.marcInput  = new createjs.Shape();
	this.marcInput.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, Motor.RESP_WIDTH, Motor.RESP_HEIGHT , 5);
	
	this.areaText = new createjs.Container();
	this.areaText.x = 0;
	this.areaText.y = 0;

	this.areaText.addChild( this.fonsInput );
	this.areaText.addChild( this.marcInput );
	
	//$('<input type="text" id="input'+index+'"/>').appendTo($("#mediaHolder"));
	var $input = $('<input type="text" id="input'+index+'"  class="input"/>');
    //$input.tabindex = i+1;

	$("#mediaHolder").append($input);
	
	//$input.css("width","275px");
	//$input.css("height","95px");
	this.inputDOM = new createjs.DOMElementCustom($input.attr("id"), this.contenedor);
	
	this.inputDOM.grandParent = grand;
	this.inputDOM.element_x = 4;
	this.inputDOM.element_y = 3;
	this.inputDOM.element_width = Motor.RESP_WIDTH-8;
	this.inputDOM.element_height = Motor.RESP_HEIGHT-5;
	this.inputDOM.fontsize = (Contenedor.datosXML.plataforma.grado == 1)? 16 : 14 ;
	
	this.inputDOM.x = this.inputDOM.element_x ;
	this.inputDOM.y = this.inputDOM.element_y ;
	$(this.inputDOM.htmlElement).css("width",this.inputDOM.element_width);
	$(this.inputDOM.htmlElement).css("height",this.inputDOM.element_height );
	
	this.contenedor.addChild( this.areaText );
	this.contenedor.addChild( this.inputDOM );
	
	
	var index = Main.navegador.split(' ')[0].indexOf("IE");
    var mobil = Main.mobil;
	if(index > -1 && mobil =="Tablet"){
       $input.focusout(function(event){ $("body").focus(); });
       $(this.inputDOM.htmlElement).click(this.select);
    }
}

TextInputBox.prototype.select = function(){
	$(this).blur().focus();
}
TextInputBox.prototype.desactivar = function()
{
	$(this.inputDOM.htmlElement).prop('readonly', true);
}
TextInputBox.prototype.activar = function()
{
	$(this.inputDOM.htmlElement).prop('readonly', false);
}

TextInputBox.prototype.clear = function(){

	this.marcInput.graphics.clear();
	this.marcInput.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, Motor.RESP_WIDTH, Motor.RESP_HEIGHT , 5);
}
TextInputBox.prototype.removeError = function(){

	if(!this.correcte){
		this.marcInput.graphics.clear();
		this.marcInput.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, Motor.RESP_WIDTH, Motor.RESP_HEIGHT , 5);
	}
}

TextInputBox.prototype.error = function(){
	this.marcInput.graphics.clear();
	this.marcInput.graphics.beginStroke("#E1001A").setStrokeStyle(2).drawRoundRect(0, 0, Motor.RESP_WIDTH, Motor.RESP_HEIGHT , 5);
	this.correcte = false;
}

TextInputBox.prototype.correct = function(){

	this.marcInput.graphics.clear();
	this.marcInput.graphics.beginStroke("#41A62A").setStrokeStyle(2).drawRoundRect(0, 0, Motor.RESP_WIDTH, Motor.RESP_HEIGHT , 5);
	this.correcte = true;
}

function BaseResposta(_index, _width, _height, _radius) {
  
  this.resposta  = null;
  this.index = _index;
  this.width = _width;
  this.height = _height;
  this.radius = _radius;
  this.pregunta = null;
  
  this.base = new createjs.Shape();
  
  this.contenedor = new createjs.Container();
  this.dibuixa();
}

BaseResposta.prototype.setReposta = function(_resposta){
  this.resposta = _resposta;
  this.resposta.index = this.index;
  this.resposta.base = this;
  //this.contenedor.addChild( this.resposta.contenedor );
}

BaseResposta.prototype.dibuixa = function() {
  
  this.base.graphics.beginFill("#fde8c2").drawRoundRect(0, 0, this.width, this.height, this.radius);
  this.base.graphics.beginStroke("#f8B334").drawRoundRect(0, 0, this.width, this.height, this.radius);
  this.base.mouseEnabled = false;
  this.contenedor.addChild( this.base );
  
}
function Pregunta(i, pregunta, numcat, height){
  	this.texte = pregunta;
  	this.index = i;
  	this.id = i;
  	this.contenedors = new Array();
  	
  	this.contenedor = new createjs.Container();
  	this.contenedor.y = Motor.INITIAL_Y +5 ;
  	this.contenedor.x =  75;
  	this.text = "";
  	var marge = 0;
	if( Motor.datosXML.sonido == "" ){
		marge = -25;
	}
		
  	var respuestas = pregunta.trim().split("[*]");
	var acumWidth = 0;
	this.acumHeight= height;
  	for(key in respuestas)
	{

	  	var palabras = respuestas[key].trim().split(" ");
	  	for( key2 in palabras){
	  		//vamos añadiendo palabra por palabra en cada linea correspondiente
			this.text = new createjs.RichText();	
			this.text.font = (Contenedor.datosXML.plataforma.grado == 1)? "17px Arial" : "15px Arial" ;
			this.text.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 17 : 15;
			this.text.color = "#0D3158";
			this.text.text = palabras[key2] + " ";
			this.text.lineWidth = 800;
			this.text.lineHeight = 25;
			this.text.mouseEnabled = false;
			
			if( this.text.lineWidth >  acumWidth + this.text.getMeasuredWidth() ){
				// misma linea
				this.text.y = this.acumHeight ;
				this.text.x =  25 + acumWidth + marge ;;
				acumWidth += this.text.getMeasuredWidth();
			}else{
				// cambio de linea
				acumWidth = this.text.getMeasuredWidth(); 
				this.text.y = this.acumHeight + 35;
				this.text.x = 25 + marge ;
				this.acumHeight += 35;
			}
			this.contenedor.addChild( this.text );
		}

		if( key < respuestas.length - 1 )
		{
			// añadimos el cuadro de texto
			if( this.text.lineWidth < acumWidth + 210 )
			{
				this.acumHeight += 35;
				acumWidth = 0; 
			}
			var inici = new TextInputBox( i.toString() + key.toString(), this.contenedor );
			inici.contenedor.x = acumWidth + 25 + marge ;
	        inici.contenedor.y = this.acumHeight-4;
	        acumWidth += 210;
	        
			this.contenedor.addChild( inici.contenedor );
			this.contenedors.push( inici );
		}
	}
	this.currentIndex = 0;
}
Pregunta.prototype.getHeight = function()
{
	return  this.acumHeight;
}
Pregunta.prototype.addElement = function(element, delay ) {
	
	if(this.currentIndex < this.contenedors.length)
	{
		//this.contenedors[this.currentIndex].pregunta = this;
		Motor.contenedor.setChildIndex ( element.contenedor,  Motor.contenedor.getNumChildren ()  );
		// coordenades del element desti
		var xfi = this.contenedor.x + this.contenedors[this.currentIndex].contenedor.x + 1;
		var yfi = this.contenedor.y + this.contenedors[this.currentIndex].contenedor.y + 1;

		// coloquem l'element origen a la casella de l'element destí
		this.contenedors[this.currentIndex].setReposta(element); 		 
		createjs.Tween.get(element.contenedor).wait(delay).to({x: xfi, y: yfi}, 250, createjs.Ease.circOut);
	
		this.currentIndex++;
		return true;
	}
	return false;

}
Pregunta.prototype.removeElement = function(element, resituar ) {
	
	if( this.currentIndex > 0 )
	{
		var key="";
		var trobat = false
		for( key in this.contenedors )
		{
			if( this.contenedors[key].resposta == element )
			{
				trobat= true;
				break;
			}
		}
		
		if(trobat)
		{
			this.contenedors[key].resposta = null;
			this.currentIndex--;
			
			for(var i = parseInt(key)+1; i < this.contenedors.length; i++)
			{
				if( this.contenedors[i].resposta != null )
				{
					this.contenedors[i-1].setElement( this.contenedors[i].resposta );
					this.contenedors[i-1].pregunta = this;
					
					this.contenedors[i].resposta = null;
					
					var xfi = this.contenedor.x + this.contenedors[i-1].contenedor.x + 1;
					var yfi = this.contenedor.y + this.contenedors[i-1].contenedor.y + 1;
					
					// coloquem l'element origen a la casella de l'element destí
					if( resituar ) createjs.Tween.get(this.contenedors[i-1].element.contenedor).to({x: xfi, y: yfi}, 150, createjs.Ease.circOut);
				}
			}
		}
	}
}

function BotoAudio( index) {
	
  	this.width = 58;
  	this.height = 58;
  	this.index = index;

	var _imgLoaded = new Image(); 
	_imgLoaded.src = pppPreloader.from("module", 'motor/images/btnAudio.png');
//	_imgLoaded.name = 'tancar';

	var data = {
	    images: [_imgLoaded],
	    frames: { width: 58, height: 58},
	    animations: { normal: [0], hover: [2], play:{ frames: [2,3,4,5,6,7,8,9] , next: "play", speed: 0.5}}
	};
	var spriteSheet = new createjs.SpriteSheet(data);
	this.bt = new createjs.Sprite(spriteSheet);
	
	// the code block in this helper.addEventListener (It works with button.addEventListener)
	
	this.bt.on("mouseover", function(evt){ if( $('#audio0')[0].paused)  this.bt.gotoAndStop("hover");},this);
	this.bt.on("mouseout", function(evt){ if($('#audio0')[0].paused) this.bt.gotoAndStop("normal");},this);
	this.bt.on("mouseover", function(evt){ document.body.style.cursor='pointer'; });
	this.bt.on("mouseout", function(evt){ document.body.style.cursor='default'; });
	//this.bt.on("mousedown", this.masInfoHandler);
	
	this.bt.x = 0;
	this.bt.y = 0;
	this.bt.gotoAndStop("normal");
 }
