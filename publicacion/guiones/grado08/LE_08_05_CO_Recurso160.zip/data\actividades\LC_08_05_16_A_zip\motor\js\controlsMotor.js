function BaseResposta(_index, _width, _height, _radius) {
  
  this.resposta  = null;
  this.index = _index;
  this.width = _width;
  this.height = _height;
  this.radius = _radius;
  
  this.base = new createjs.Shape();
  
  this.contenedor = new createjs.Container();
  this.dibuixa();
}

BaseResposta.prototype.setReposta = function(_resposta){
  this.resposta = _resposta;
  this.resposta.index = this.index;
  //this.contenedor.addChild( this.resposta.contenedor );
}

BaseResposta.prototype.dibuixa = function() {
  
  this.base.graphics.beginFill("#fde8c2").drawRoundRect(0, 0, this.width, this.height, this.radius);
  this.base.graphics.beginStroke("#f8B334").drawRoundRect(0, 0, this.width, this.height, this.radius);
  this.base.mouseEnabled = false;
  this.contenedor.addChild( this.base );
  
}

function Resposta(_texte, _width, _height, _radius) {
	this.width = _width;
  	this.height = _height;
  	this.radius = _radius;
  	this.texte = _texte;
  	this.index = 0;
  	this.idResposta = -1;
  	this.error = false;
  	
  	this.correccio = new createjs.Shape();
  	
  	this.fons = new createjs.Shape();	
	this.text = new createjs.RichText();	
	this.contenedor = new createjs.Container();
  	this.dibuixa();
}

Resposta.prototype.lightResponse = function(){
	this.fons.graphics.clear();
	this.fons.graphics.beginFill("#f8B334").drawRoundRect(0, 0, this.width, this.height, this.radius);
	this.fons.shadow = new createjs.Shadow("#777", 4, 4, 10);
}
Resposta.prototype.unlightResponse = function(){
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, this.width, this.height, this.radius);
	this.fons.shadow = null;
}
Resposta.prototype.erronia = function(){
	this.error = true;
	this.correccio.graphics.beginStroke("#E1001A").setStrokeStyle(3).drawRoundRect(-2, -2, this.width + 4, this.height + 4, this.radius);
	this.contenedor.addChild( this.correccio );
}
Resposta.prototype.correcte = function(){
	this.error = false
	this.correccio.graphics.beginStroke("#41A62A").setStrokeStyle(3).drawRoundRect(-2, -2, this.width + 4, this.height + 4, this.radius);
	this.contenedor.addChild( this.correccio );
}
Resposta.prototype.removeError = function(){
	if(this.error) this.contenedor.removeChild( this.correccio );
}
Resposta.prototype.dibuixa = function() {
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, this.width, this.height, this.radius);
	
	this.text.font = (Contenedor.datosXML.plataforma.grado == 1)? "16px Arial" : "14px Arial";
	this.text.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 16 : 14;
	this.text.color = "#0D3158";
	this.text.text = this.texte ;
	this.text.x = 8;
	this.text.y = 3 ;
	this.text.lineWidth = 305;
	this.text.lineHeight = 22;
	this.text.mouseEnabled = false;
	
	this.contenedor.addChild( this.fons );
	this.contenedor.addChild( this.text );
}


function Pregunta(_texte, _width, _height) {
	this.width = _width;
  	this.height = _height;
  	this.texte = _texte;
  	this.index = 0;
  	this.id = -1;
  	
  	this.fons = new createjs.Shape();	
	this.text = new createjs.RichText();	
	this.contenedor = new createjs.Container();
  	this.dibuixa();
}

Pregunta.prototype.dibuixa = function() {
	this.fons.graphics.beginFill("#fff");
	this.fons = Utils.arrowRect(this.fons, 0, 0, 305, 35);
	
	this.text.font = (Contenedor.datosXML.plataforma.grado == 1)? "17px Arial" : "15px Arial";
	this.text.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 17 : 15;
	this.text.color = "#0D3158";
	this.text.text = this.texte ;
	this.text.x = 8;
	this.text.y = 8 ;
	//this.text.lineWidth = 305;
	//this.text.lineHeight = 22;
	this.text.mouseEnabled = false;
	
	this.text.mask = new createjs.Shape();
	this.text.mask.graphics.beginFill("#fff").drawRoundRect(0, 0, 280, 30, 1);
	this.text.mask.x = 8;
	this.text.mask.y = 8 ;
	
	this.contenedor.addChild( this.fons );
	this.contenedor.addChild( this.text );
}

function TextInputBox(resposta,  index)
{

	this.contenedor = new createjs.Container();
//	console.log(index);
	this.id  = index;
	this.correcte = false;
	this.textCorrecte = resposta.text;
	
	//debugger;
	this.contesta = new createjs.RichText();
    this.contesta.text =  "";
    this.contesta.font = (Contenedor.datosXML.plataforma.grado == 1)? "16px Arial" : "14px Arial";
	this.contesta.fontSize = (Contenedor.datosXML.plataforma.grado == 1)? 16 : 14;
	this.contesta.color = "#E1001A";
	this.contesta.x = 2;
	this.contesta.y = 35;
	this.contesta.mouseEnabled = false;
	
	this.fonsInput = new createjs.Shape();
	this.fonsInput.graphics.beginFill("#fff").drawRoundRect(0, 0, 295, 35, 5);
	
	this.marcInput  = new createjs.Shape();
	this.marcInput .graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 295, 35, 5);
	
	this.areaText = new createjs.Container();
	this.areaText.x = 0;
	this.areaText.y = 0;

	this.areaText.addChild( this.fonsInput );
	this.areaText.addChild( this.marcInput );
	
	//$('<input type="text" id="input'+index+'"/>').appendTo($("#mediaHolder"));
	var $input = $('<input type="text" id="input_'+ index +'" class="input"/>');
    //$input.tabindex = i+1;

	$("#mediaHolder").append($input);

	this.inputDOM = new createjs.DOMElementCustom($input.attr("id"), this.contenedor);
	
	this.inputDOM.grandParent = Motor.contenedor;
	this.inputDOM.element_x = 5;
	this.inputDOM.element_y = 5;
	this.inputDOM.element_width = 285;
	this.inputDOM.element_height = 25;
	this.inputDOM.fontsize = (Contenedor.datosXML.plataforma.grado == 1)? 16 : 14;
	this.inputDOM.mouseEnabled = false;
	
	this.inputDOM.x = this.inputDOM.element_x ;
	this.inputDOM.y = this.inputDOM.element_y ;
	$(this.inputDOM.htmlElement).css("width",this.inputDOM.element_width);
	$(this.inputDOM.htmlElement).css("height",this.inputDOM.element_height );
	
	this.contenedor.addChild( this.areaText );
	this.contenedor.addChild( this.inputDOM );
	this.contenedor.addChild( this.contesta );
	
	//this.inputDOM.on("mousedown", this.select, this);
	var index = Main.navegador.split(' ')[0].indexOf("IE");
    var mobil = Main.mobil;
	if(index > -1 && mobil =="Tablet"){
        $input.focusout(function(event){ $("body").focus(); });
        $(this.inputDOM.htmlElement).click(this.select);
    }
	
}

TextInputBox.prototype.select = function(){

	$(this).blur().focus();
}
TextInputBox.prototype.final= function(){
	for( key in Motor.audios)
	{
		if(Motor.audios[key].id == this.id[5])
		{
			Motor.audios[key].bt.bt.gotoAndStop("normal");
		}
	}
}
TextInputBox.prototype.desactivar = function()
{
	$(this.inputDOM.htmlElement).prop('readonly', true);
}
TextInputBox.prototype.activar = function()
{
	$(this.inputDOM.htmlElement).prop('readonly', false);
}
TextInputBox.prototype.setCorreccio = function(  )
{
	this.contesta.text = this.textCorrecte;
}
TextInputBox.prototype.clear = function(){

	this.marcInput.graphics.clear();
	this.marcInput.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 295, 35, 5);
}
TextInputBox.prototype.removeError = function(){

	if(!this.correcte){
		this.marcInput.graphics.clear();
		this.marcInput.graphics.beginStroke("#F8B334").setStrokeStyle(1).drawRoundRect(0, 0, 295, 35, 5);
	}
}

TextInputBox.prototype.error = function(){

	this.marcInput.graphics.beginStroke("#E1001A").setStrokeStyle(2).drawRoundRect(0, 0, 295, 35, 5);
	this.correcte = false;
}

TextInputBox.prototype.correct = function(){

	this.marcInput.graphics.beginStroke("#41A62A").setStrokeStyle(2).drawRoundRect(0, 0, 295, 35, 5);
	this.correcte = true;
}

function Imagen(  ){	    
	    // get imagen
    this.contenedor = new createjs.Container();
    
    this.zoom = new createjs.Bitmap(pppPreloader.from("module", 'motor/images/ico_zoom.png'));
	this.zoom.x = 285;
	this.zoom.y = 435;
	this.zoom.on("mouseover", function(evt){ document.body.style.cursor='pointer'; });
	this.zoom.on("mouseout", function(evt){ document.body.style.cursor='default'; });
	this.zoom.on("click", this.zooming , this);
	
    var img = new Image();
    var objeto = this;
	img.onload = function () {
	   	objeto.imagen = new createjs.Bitmap(this);
		objeto.imagen.x = 25;
		objeto.imagen.y = 175;
		//escalem imatges
		objeto.imagen.scaleX =  300 / this.width;
		objeto.imagen.scaleY =  300 / this.height;

		//mascara de cantonades arrodonides
		objeto.imagen.mask = new createjs.Shape();
		objeto.imagen.mask.graphics.beginFill("#fff").drawRoundRect(0, 0, 300, 300, 10);
		objeto.imagen.mask.x = 25;
	 	objeto.imagen.mask.y = 175;
		
		objeto.contenedor.addChild( objeto.imagen);

		// boton de ampliacion
		if( Motor.datosXML.ampliacion != "")
		{
			objeto.contenedor.addChild( objeto.zoom );
			objeto.imagen.on("click", objeto.zooming , objeto);
			objeto.imagen.on("mouseover", function(evt){ document.body.style.cursor='pointer'; });
			objeto.imagen.on("mouseout", function(evt){ document.body.style.cursor='default'; });
		}
	};
	img.src = pppPreloader.from("data", Motor.IMG + Motor.datosXML.imagen);//Motor.IMG + Motor.datosXML.imagen;
	
	// imagen ampliada
	if( Motor.datosXML.ampliacion !=  "")
	{
	    this.ampliacion = new Ampliacion();
	    this.ampliacion.contenedor.x = 0;
		this.ampliacion.contenedor.y = 0;
		this.ampliacion.contenedor.alpha = 0;
		Main.stage.addChild( this.ampliacion.contenedor);
	}
}
Imagen.prototype.zooming = function(evt){
	if( evt.primary ){
		Main.stage.setChildIndex ( this.ampliacion.contenedor,  Main.stage.getNumChildren () - 1 );
		this.ampliacion.contenedor.visible = true;
		Motor.hideDomObjects();
		createjs.Tween.get(this.ampliacion.contenedor).to({alpha:1}, 500, createjs.Ease.circOut);
	}
}

function Ampliacion()
{
	this.fons = new createjs.Shape();
	this.fons.graphics.beginFill("#fff").drawRoundRect(0, 0, Main.stage_width, Main.stage_height, 5);
	this.fons.alpha = 0.60;
	
	this.contenedor = new createjs.Container();
	this.contenedor.addChild(this.fons);
	
	var img = new Image();
	var amplia = this;
	
	this.imagen = "";
	img.onload = function () {

	   	amplia.imagen = new createjs.Bitmap(this);
		
		
		amplia.imagen.scaleX =  500 / this.height;
		amplia.imagen.scaleY =  500 / this.height;
		
		amplia.imagen.x = (Main.stage_width - (this.width * 500 / this.height))/2;
		amplia.imagen.y = 50;
		
		//mascara de cantonades arrodonides
		amplia.imagen.mask = new createjs.Shape();
		amplia.imagen.mask.graphics.beginFill("#fff").drawRoundRect(0, 0, 500, this.height * 500 / this.width, 10);
		amplia.imagen.mask.x = (Main.stage_width - (this.width * 500 / this.height))/2;
	 	amplia.imagen.mask.y = 50;
		
		amplia.contenedor.addChild( amplia.imagen);
	};
	
	img.src = pppPreloader.from("data", Motor.IMG + Motor.datosXML.ampliacion);//Motor.IMG + Motor.datosXML.ampliacion;
		
	
	this.contenedor.on("click", this.tancar);
	this.contenedor.on("mouseover", function(evt){ document.body.style.cursor='pointer'; });
	this.contenedor.on("mouseout", function(evt){ document.body.style.cursor='default'; });
}
Ampliacion.prototype.tancar= function(evt){
	if( evt.primary ){
		createjs.Tween.get(this).to({alpha:0}, 500, createjs.Ease.circOut).call(function(){ Motor.showDomObjects(); });
	}
}
