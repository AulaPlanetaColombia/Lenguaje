(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
        titulo1(this, txt['titol']);



        this.btn_imatge = new lib.btn_imatge();
        this.btn_imatge.setTransform(473.1, 338.9, 1, 1, 0, 0, 0, 211.3, 187.5);
        new cjs.ButtonHelper(this.btn_imatge, 0, 1, 2, false, new lib.btn_imatge(), 3);

        this.btn_imatge.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.siguiente, this.btn_imatge);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 1, 0);
        titulo2(this, txt['titol_01']);

        var html = createDiv(txt['p1_01'], "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
        html.style.zIndex = -1;
        this.oraciones = new cjs.DOMElement(html);
        this.oraciones.setTransform(90, -452);

        this.txt_selecciona = new cjs.Text(txt['txt_selecciona'], "16px Arial");
        this.txt_selecciona.textAlign = "center";
        this.txt_selecciona.lineHeight = 18;
        this.txt_selecciona.lineWidth = 322;
        this.txt_selecciona.setTransform(490, 559.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCCCCC").s().p("A46CbIAAk1MAx1AAAIAAE1g");
        this.shape.setTransform(491.1, 568.1, 1.028, 1);

        this.btn_correcto_1_03 = new lib.btn_incorrecto_1_01();
        this.btn_correcto_1_03.setTransform(474.1, 480.7, 1.264, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_correcto_1_03, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_1_02 = new lib.btn_incorrecto_1_01();
        this.btn_correcto_1_02.setTransform(474.1, 400.9, 1.346, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_correcto_1_02, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_incorrecto_1_02 = new lib.btn_incorrecto_1_01();
        this.btn_incorrecto_1_02.setTransform(473.2, 321.9, 0.836, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_incorrecto_1_02, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_1_01 = new lib.btn_incorrecto_1_01();
        this.btn_correcto_1_01.setTransform(474.1, 243.5, 1.645, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_correcto_1_01, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_incorrecto_1_01 = new lib.btn_incorrecto_1_01();
        this.btn_incorrecto_1_01.setTransform(473.2, 166.5, 1, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_incorrecto_1_01, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_1_01.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto(txt['txt_popup_correcto_1_01']);
            this.parent.addChild(this.parent.popup);
        });
        this.btn_correcto_1_02.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto(txt['txt_popup_correcto_1_02']);
            this.parent.addChild(this.parent.popup);
        });
        this.btn_correcto_1_03.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto(txt['txt_popup_correcto_1_03']);
            this.parent.addChild(this.parent.popup);
        });
        this.btn_incorrecto_1_01.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_incorrecto(txt['txt_popup_incorrecto_1_01']);
            this.parent.addChild(this.parent.popup);
        });

        this.btn_incorrecto_1_02.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_incorrecto(txt['txt_popup_incorrecto_1_02']);
            this.parent.addChild(this.parent.popup);
        });


        this.informacion.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.informacion = new lib.popup_info_01(txt['txt_popup_info_01']);
            this.parent.addChild(this.parent.informacion);
        });

        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.siguiente, this.home, this.oraciones, this.informacion, this.btn_incorrecto_1_01, this.btn_correcto_1_01, this.btn_incorrecto_1_02, this.btn_correcto_1_02, this.btn_correcto_1_03, this.shape, this.txt_selecciona);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 1, 0);
        titulo2(this, txt['titol_02']);

        var html = createDiv(txt['p2_01'], "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
        html.style.zIndex = -1;
        this.oraciones = new cjs.DOMElement(html);
        this.oraciones.setTransform(90, -452);

        this.txt_selecciona = new cjs.Text(txt['txt_selecciona'], "16px Arial");
        this.txt_selecciona.textAlign = "center";
        this.txt_selecciona.lineHeight = 18;
        this.txt_selecciona.lineWidth = 322;
        this.txt_selecciona.setTransform(490, 559.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCCCCC").s().p("A46CbIAAk1MAx1AAAIAAE1g");
        this.shape.setTransform(491.1, 568.1, 1.028, 1);

        this.btn_incorrecto_2_02 = new lib.btn_incorrecto_1_01();
        this.btn_incorrecto_2_02.setTransform(477, 326.6, 1.264, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_incorrecto_2_02, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_incorrecto_2_01 = new lib.btn_incorrecto_1_01();
        this.btn_incorrecto_2_01.setTransform(477, 246.9, 1.346, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_incorrecto_2_01, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_2_01 = new lib.btn_incorrecto_1_01();
        this.btn_correcto_2_01.setTransform(479.8, 165, 1.645, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_correcto_2_01, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_2_01.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto2(txt['txt_popup_correcto_2_01']);
            this.parent.addChild(this.parent.popup);
        });

        this.btn_incorrecto_2_01.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_incorrecto(txt['txt_popup_incorrecto_1_01']);
            this.parent.addChild(this.parent.popup);
        });

        this.btn_incorrecto_2_02.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_incorrecto(txt['txt_popup_incorrecto_1_02']);
            this.parent.addChild(this.parent.popup);
        });


        this.informacion.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.informacion = new lib.popup_info_01(txt['txt_popup_info_02']);
            this.parent.addChild(this.parent.informacion);
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior, this.home, this.oraciones, this.informacion, this.btn_incorrecto_2_01, this.btn_correcto_2_01, this.btn_incorrecto_2_02, this.shape, this.txt_selecciona);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 1, 0);
        titulo2(this, txt['titol_03']);

        var html = createDiv(txt['p3_01'], "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
        html.style.zIndex = -1;
        this.oraciones = new cjs.DOMElement(html);
        this.oraciones.setTransform(90, -452);

        this.txt_selecciona = new cjs.Text(txt['txt_selecciona'], "16px Arial");
        this.txt_selecciona.textAlign = "center";
        this.txt_selecciona.lineHeight = 18;
        this.txt_selecciona.lineWidth = 322;
        this.txt_selecciona.setTransform(490, 559.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCCCCC").s().p("A46CbIAAk1MAx1AAAIAAE1g");
        this.shape.setTransform(491.1, 568.1, 1.028, 1);

        this.btn_correcto_3_02 = new lib.btn_incorrecto_1_01();
        this.btn_correcto_3_02.setTransform(475.1, 245.7, 1.264, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_correcto_3_02, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_3_01 = new lib.btn_incorrecto_1_01();
        this.btn_correcto_3_01.setTransform(475.1, 166, 1.346, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_correcto_3_01, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_3_01.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto3_1(txt['txt_popup_correcto_3_01']);
            this.parent.addChild(this.parent.popup);
        });

        this.btn_correcto_3_02.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto3_2(txt['txt_popup_correcto_3_02']);
            this.parent.addChild(this.parent.popup);
        });




        this.informacion.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.informacion = new lib.popup_info_01(txt['txt_popup_info_03']);
            this.parent.addChild(this.parent.informacion);
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior, this.home, this.oraciones, this.informacion, this.btn_correcto_3_01, this.btn_correcto_3_02, this.shape, this.txt_selecciona);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 1, 0);
        titulo2(this, txt['titol_04']);

        var html = createDiv(txt['p4_01'], "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
        html.style.zIndex = -1;
        this.oraciones = new cjs.DOMElement(html);
        this.oraciones.setTransform(90, -452);

        this.txt_selecciona = new cjs.Text(txt['txt_selecciona'], "16px Arial");
        this.txt_selecciona.textAlign = "center";
        this.txt_selecciona.lineHeight = 18;
        this.txt_selecciona.lineWidth = 322;
        this.txt_selecciona.setTransform(490, 559.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCCCCC").s().p("A46CbIAAk1MAx1AAAIAAE1g");
        this.shape.setTransform(491.1, 568.1, 1.028, 1);

        this.btn_correcto_4_05 = new lib.btn_incorrecto_1_01();
        this.btn_correcto_4_05.setTransform(474.8, 497.9, 1.67, 1.68, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_correcto_4_05, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_4_04 = new lib.btn_incorrecto_1_01();
        this.btn_correcto_4_04.setTransform(474.8, 404.8, 1.437, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_correcto_4_04, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_4_03 = new lib.btn_incorrecto_1_01();
        this.btn_correcto_4_03.setTransform(474.8, 325.1, 1.17, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_correcto_4_03, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_4_02 = new lib.btn_incorrecto_1_01();
        this.btn_correcto_4_02.setTransform(474.8, 248.7, 1.343, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_correcto_4_02, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_4_01 = new lib.btn_incorrecto_1_01();
        this.btn_correcto_4_01.setTransform(474.8, 169, 1.453, 1, 0, 0, 0, 222.6, 17.5);
        new cjs.ButtonHelper(this.btn_correcto_4_01, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_4_01.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto4(txt['txt_popup_correcto_4_01']);
            this.parent.addChild(this.parent.popup);
        });

        this.btn_correcto_4_02.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto4(txt['txt_popup_correcto_4_02']);
            this.parent.addChild(this.parent.popup);
        });
        this.btn_correcto_4_03.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto4(txt['txt_popup_correcto_4_03']);
            this.parent.addChild(this.parent.popup);
        });
        this.btn_correcto_4_04.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto4(txt['txt_popup_correcto_4_04']);
            this.parent.addChild(this.parent.popup);
        });
        this.btn_correcto_4_05.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto4(txt['txt_popup_correcto_4_05']);
            this.parent.addChild(this.parent.popup);
        });





        this.informacion.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.informacion = new lib.popup_info_04(txt['txt_popup_info_04'],txt['info4_01'],txt['info4_02']);
            this.parent.addChild(this.parent.informacion);
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior, this.home, this.oraciones, this.informacion,this.btn_correcto_4_01,this.btn_correcto_4_02,this.btn_correcto_4_03,this.btn_correcto_4_04,this.btn_correcto_4_05, this.shape, this.txt_selecciona);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 1, 0);
        titulo2(this, txt['titol_05']);

        var html = createDiv(txt['p5_01'], "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
        html.style.zIndex = -1;
        this.oraciones = new cjs.DOMElement(html);
        this.oraciones.setTransform(90, -452);

        this.txt_selecciona = new cjs.Text(txt['txt_selecciona'], "16px Arial");
        this.txt_selecciona.textAlign = "center";
        this.txt_selecciona.lineHeight = 18;
        this.txt_selecciona.lineWidth = 322;
        this.txt_selecciona.setTransform(490, 559.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCCCCC").s().p("A46CbIAAk1MAx1AAAIAAE1g");
        this.shape.setTransform(491.1, 568.1, 1.028, 1);

       this.btn_correcto_5_03 = new lib.btn_incorrecto_1_01();
	this.btn_correcto_5_03.setTransform(476.6,322.1,1.404,1,0,0,0,222.6,17.5);
	new cjs.ButtonHelper(this.btn_correcto_5_03, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

	this.btn_correcto_5_02 = new lib.btn_incorrecto_1_01();
	this.btn_correcto_5_02.setTransform(476.5,245.7,1,1,0,0,0,222.6,17.5);
	new cjs.ButtonHelper(this.btn_correcto_5_02, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

	this.btn_correcto_5_01 = new lib.btn_incorrecto_1_01();
	this.btn_correcto_5_01.setTransform(476.5,166,0.974,1,0,0,0,222.6,17.5);
	new cjs.ButtonHelper(this.btn_correcto_5_01, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_5_01.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto5(txt['txt_popup_correcto_5_01']);
            this.parent.addChild(this.parent.popup);
        });

        this.btn_correcto_5_02.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto5(txt['txt_popup_correcto_5_02']);
            this.parent.addChild(this.parent.popup);
        });
        this.btn_correcto_5_03.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto5(txt['txt_popup_correcto_5_03']);
            this.parent.addChild(this.parent.popup);
        });
       

        this.informacion.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.informacion = new lib.popup_info_01(txt['txt_popup_info_05']);
            this.parent.addChild(this.parent.informacion);
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior, this.home, this.oraciones, this.informacion,this.btn_correcto_5_01,this.btn_correcto_5_02,this.btn_correcto_5_03, this.shape, this.txt_selecciona);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 1, 0);
        titulo2(this, txt['titol_06']);

        var html = createDiv(txt['p6_01'], "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
        html.style.zIndex = -1;
        this.oraciones = new cjs.DOMElement(html);
        this.oraciones.setTransform(90, -452);

        this.txt_selecciona = new cjs.Text(txt['txt_selecciona'], "16px Arial");
        this.txt_selecciona.textAlign = "center";
        this.txt_selecciona.lineHeight = 18;
        this.txt_selecciona.lineWidth = 322;
        this.txt_selecciona.setTransform(490, 559.9);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#CCCCCC").s().p("A46CbIAAk1MAx1AAAIAAE1g");
        this.shape.setTransform(491.1, 568.1, 1.028, 1);

      this.btn_correcto_6_02 = new lib.btn_incorrecto_1_01();
	this.btn_correcto_6_02.setTransform(479,322.1,1.404,1,0,0,0,222.6,17.5);
	new cjs.ButtonHelper(this.btn_correcto_6_02, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

	this.btn_correcto_6_01 = new lib.btn_incorrecto_1_01();
	this.btn_correcto_6_01.setTransform(479,245.7,1,1,0,0,0,222.6,17.5);
	new cjs.ButtonHelper(this.btn_correcto_6_01, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

	this.btn_incorrecto_6_01 = new lib.btn_incorrecto_1_01();
	this.btn_incorrecto_6_01.setTransform(479,166,0.974,1,0,0,0,222.6,17.5);
	new cjs.ButtonHelper(this.btn_incorrecto_6_01, 0, 1, 2, false, new lib.btn_incorrecto_1_01(), 3);

        this.btn_correcto_6_01.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto6_1(txt['txt_popup_correcto_6_01']);
            this.parent.addChild(this.parent.popup);
        });

        this.btn_correcto_6_02.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_correcto6_2(txt['txt_popup_correcto_6_02']);
            this.parent.addChild(this.parent.popup);
        });
        this.btn_incorrecto_6_01.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.popup = new lib.popup_incorrecto(txt['txt_popup_incorrecto_6_01']);
            this.parent.addChild(this.parent.popup);
        });
       

        this.informacion.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.informacion = new lib.popup_info_01(txt['txt_popup_info_06']);
            this.parent.addChild(this.parent.informacion);
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior, this.home, this.oraciones, this.informacion,this.btn_incorrecto_6_01,this.btn_correcto_6_01,this.btn_correcto_6_02, this.shape, this.txt_selecciona);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame8 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 1, 0);
        titulo2(this, txt['titol_07']);

        var html = createDiv(txt['p7_01'], "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
        html.style.zIndex = -1;
        this.oraciones = new cjs.DOMElement(html);
        this.oraciones.setTransform(90, -452);


        this.informacion.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.informacion = new lib.popup_info_07(txt['txt_popup_info_07']);
            this.parent.addChild(this.parent.informacion);
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame9());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.addChild(this.logo, this.titulo, this.siguiente, this.anterior, this.home, this.oraciones, this.informacion,this.btn_incorrecto_6_01,this.btn_correcto_6_01,this.btn_correcto_6_02, this.shape, this.txt_selecciona);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
(lib.frame9 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 1, 0);
        titulo2(this, txt['titol_08']);

        var html = createDiv(txt['p8_01'], "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
        html.style.zIndex = -1;
        this.oraciones = new cjs.DOMElement(html);
        this.oraciones.setTransform(90, -452);


	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(5.5,2,1).p("AyGAAMAkNAAA");
	this.shape_8.setTransform(523.6,418.3,0.992,1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(5.5,2,1).p("AGrh5ItUDz");
	this.shape_9.setTransform(363.3,405.3,0.952,1,0,0,180);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(5.5,2,1).p("AGrh5ItUDz");
	this.shape_10.setTransform(448.9,405.5,0.959,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(5.5,2,1).p("ALpAAI3RAA");
	this.shape_11.setTransform(715.5,323.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(5.5,2,1).p("AENAAIoZAA");
	this.shape_12.setTransform(819.1,290);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#000000").ss(5.5,2,1).p("Ak9AAIJ7AA");
	this.shape_13.setTransform(456.5,289.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(5.5,2,1).p("AuTAAIcnAA");
	this.shape_14.setTransform(230.1,323.6,0.993,1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(5.5,2,1).p("An3AAIPuAA");
	this.shape_15.setTransform(271.4,287.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(5.5,2,1).p("AAAm0IAANp");
	this.shape_16.setTransform(639.5,350.7,1,2.654);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(5.5,2,1).p("AAAm0IAANp");
	this.shape_17.setTransform(221,259.5,1,0.626);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(5.5,2,1).p("AAAm0IAANp");
	this.shape_18.setTransform(424.7,259.5,1,0.626);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(5.5,2,1).p("AAAm0IAANp");
	this.shape_19.setTransform(490.5,312.2,1,1.831);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(5.5,2,1).p("AAAm0IAANp");
	this.shape_20.setTransform(846,259.5,1,0.626);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(5.5,2,1).p("AAAm0IAANp");
	this.shape_21.setTransform(790,277);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(5.5,2,1).p("AAAm0IAANp");
	this.shape_22.setTransform(321.8,312.2,1,1.83);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(5.5,2,1).p("AAAm0IAANp");
	this.shape_23.setTransform(139.1,277);

        this.informacion.on("click", function (evt) {
            if (popupon)
                return;
            popupon = true;
            this.parent.informacion = new lib.popup_info_08(txt['txt_popup_info_08']);
            this.parent.addChild(this.parent.informacion);
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
       
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        this.addChild(this.logo, this.titulo, this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8, this.anterior, this.home, this.oraciones, this.informacion,this.btn_incorrecto_6_01,this.btn_correcto_6_01,this.btn_correcto_6_02, this.shape, this.txt_selecciona);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        html.style.zIndex = -1;
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130 + ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
      function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }
    (lib.popup_info_01 = function (texto) {
        this.initialize();
        basicos(this, 1, 0, 0, 0, 1);

        // Blanco
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhKNAvgMAAAhe/MCUbAAAMAAABe/g");
        this.shape.setTransform(475, 304);
        var html = createDiv(texto, "Verdana", "20px", '770px', '100px', "20px", "185px", "left");
        this.txt_popup_info_01 = new cjs.DOMElement(html);
        this.txt_popup_info_01.setTransform(90, -452);
        this.cerrar.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });

        this.addChild(this.shape, this.logo, this.cerrar, this.txt_popup_info_01);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.Icona_ok = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#0B6635", "#95C030"], [0, 1], 34.5, 77.7, -16.7, -68.8).s().p("ApNImQhWg8hWgzIhFgnIg/kOIAKAAQCVAUD6CeQB9BPBfBLQAhogGXnoQCAiZCWiAQBLhBAyghIE7E3QpsF1kSKEQhVDKgpDNQgVBmgDA+QiljQkSjAg");
        this.shape.setTransform(97.9, 103.7, 0.5, 0.5);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(53.3, 56.2, 89.4, 95.1);

 (lib.popup_info_04 = function (texto,texto2,texto3) {
        this.initialize();
        basicos(this, 1, 0, 0, 0, 1);

        // Blanco
        this.shape0 = new cjs.Shape();
        this.shape0.graphics.f("#FFFFFF").s().p("EhKNAvgMAAAhe/MCUbAAAMAAABe/g");
        this.shape0.setTransform(475, 304);
        var html = createDiv(texto, "Verdana", "20px", '770px', '100px', "20px", "185px", "left");
        this.txt_popup_info_01 = new cjs.DOMElement(html);
        this.txt_popup_info_01.setTransform(90, -452);
        
          var html = createDiv(texto2, "Verdana", "20px", '400px', '100px', "20px", "185px", "right");
          html.style.lineHeight="134%";
        this.txt_popup_info_02 = new cjs.DOMElement(html);
        this.txt_popup_info_02.setTransform(20, -352);
        
          var html = createDiv(texto3, "Verdana", "20px", '400px', '100px', "20px", "185px", "left");
          html.style.lineHeight="134%";
        this.txt_popup_info_03 = new cjs.DOMElement(html);
        this.txt_popup_info_03.setTransform(540, -352);
        
        this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,2,1).p("AAqAAIhTg7IAAB4g");
	this.shape.setTransform(508.7,487.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Agpg7IBTA7IhTA8g");
	this.shape_1.setTransform(508.7,487.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AlrAAILXAA");
	this.shape_2.setTransform(475.6,487.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,2,1).p("AhBAAICDhLIAACXg");
	this.shape_3.setTransform(508.7,432.5,0.64,0.8,0,0,180);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhBAAICDhLIAACXg");
	this.shape_4.setTransform(508.7,432.5,0.64,0.8,0,0,180);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,1,1).p("AlrAAILXAA");
	this.shape_5.setTransform(476.5,433);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(2,2,1).p("AhBAAICDhLIAACXg");
	this.shape_6.setTransform(508.7,380.9,0.64,0.8,0,0,180);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhBAAICDhLIAACXg");
	this.shape_7.setTransform(508.7,380.9,0.64,0.8,0,0,180);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(2,1,1).p("AlrAAILXAA");
	this.shape_8.setTransform(476.5,380.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(2,2,1).p("AhBAAICDhLIAACXg");
	this.shape_9.setTransform(508.7,328.9,0.64,0.8,0,0,180);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AhBAAICDhLIAACXg");
	this.shape_10.setTransform(508.7,328.9,0.64,0.8,0,0,180);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#000000").ss(2,1,1).p("AlrAAILXAA");
	this.shape_11.setTransform(476.5,328.7);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(2,2,1).p("AhBAAICDhLIAACXg");
	this.shape_12.setTransform(508.7,276.4,0.64,0.8,0,0,180);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AhBAAICDhLIAACXg");
	this.shape_13.setTransform(508.7,276.4,0.64,0.8,0,0,180);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(2,1,1).p("AlrAAILXAA");
	this.shape_14.setTransform(476.5,276.1);
        
        this.cerrar.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });

        this.addChild(this.shape0, this.logo, this.cerrar, this.txt_popup_info_01,this.txt_popup_info_02,this.txt_popup_info_03,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.Icona_ok = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#0B6635", "#95C030"], [0, 1], 34.5, 77.7, -16.7, -68.8).s().p("ApNImQhWg8hWgzIhFgnIg/kOIAKAAQCVAUD6CeQB9BPBfBLQAhogGXnoQCAiZCWiAQBLhBAyghIE7E3QpsF1kSKEQhVDKgpDNQgVBmgDA+QiljQkSjAg");
        this.shape.setTransform(97.9, 103.7, 0.5, 0.5);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(53.3, 56.2, 89.4, 95.1);
(lib.popup_info_07 = function (texto) {
        this.initialize();
        basicos(this, 1, 0, 0, 0, 1);

        // Blanco
        this.shape0 = new cjs.Shape();
        this.shape0.graphics.f("#FFFFFF").s().p("EhKNAvgMAAAhe/MCUbAAAMAAABe/g");
        this.shape0.setTransform(475, 304);
        
      var html = createDiv(texto, "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
        this.oraciones = new cjs.DOMElement(html);
        this.oraciones.setTransform(90, -452);
        
          this.animacion=new lib.popup_info_07_anim();
        this.animacion.setTransform(0,5);
        this.cerrar.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });

        this.addChild(this.shape0, this.logo, this.cerrar, this.oraciones,this.animacion);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    
    (lib.popup_info_07_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	
	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Eg8mABNIAAiZMB5NAAAIAACZg");
	var mask_graphics_1 = new cjs.Graphics().p("Eg8mABeIAAi7MB5NAAAIAAC7g");
	var mask_graphics_2 = new cjs.Graphics().p("Eg8mABwIAAjfMB5NAAAIAADfg");
	var mask_graphics_3 = new cjs.Graphics().p("Eg8mACBIAAkBMB5NAAAIAAEBg");
	var mask_graphics_4 = new cjs.Graphics().p("Eg8mACTIAAklMB5NAAAIAAElg");
	var mask_graphics_5 = new cjs.Graphics().p("Eg8mACkIAAlHMB5NAAAIAAFHg");
	var mask_graphics_6 = new cjs.Graphics().p("Eg8mAC2IAAlrMB5NAAAIAAFrg");
	var mask_graphics_7 = new cjs.Graphics().p("Eg8mADHIAAmNMB5NAAAIAAGNg");
	var mask_graphics_8 = new cjs.Graphics().p("Eg8mADZIAAmxMB5NAAAIAAGxg");
	var mask_graphics_9 = new cjs.Graphics().p("Eg8mADqIAAnTMB5NAAAIAAHTg");
	var mask_graphics_10 = new cjs.Graphics().p("Eg8mAD8IAAn3MB5NAAAIAAH3g");
	var mask_graphics_11 = new cjs.Graphics().p("Eg8mAENIAAoZMB5NAAAIAAIZg");
	var mask_graphics_12 = new cjs.Graphics().p("Eg8mAEfIAAo9MB5NAAAIAAI9g");
	var mask_graphics_13 = new cjs.Graphics().p("Eg8mAEwIAApfMB5NAAAIAAJfg");
	var mask_graphics_14 = new cjs.Graphics().p("Eg8mAFCIAAqDMB5NAAAIAAKDg");
	var mask_graphics_15 = new cjs.Graphics().p("Eg8mAFTIAAqlMB5NAAAIAAKlg");
	var mask_graphics_16 = new cjs.Graphics().p("Eg8mAFlIAArJMB5NAAAIAALJg");
	var mask_graphics_17 = new cjs.Graphics().p("Eg8mAF2IAArrMB5NAAAIAALrg");
	var mask_graphics_18 = new cjs.Graphics().p("Eg8mAGIIAAsPMB5NAAAIAAMPg");
	var mask_graphics_19 = new cjs.Graphics().p("Eg8mAGaIAAszMB5NAAAIAAMzg");
	var mask_graphics_20 = new cjs.Graphics().p("Eg8mAGrIAAtVMB5NAAAIAANVg");
	var mask_graphics_21 = new cjs.Graphics().p("Eg8mAG9IAAt5MB5NAAAIAAN5g");
	var mask_graphics_22 = new cjs.Graphics().p("Eg8mAHOIAAubMB5NAAAIAAObg");
	var mask_graphics_23 = new cjs.Graphics().p("Eg8mAHgIAAu/MB5NAAAIAAO/g");
	var mask_graphics_24 = new cjs.Graphics().p("Eg8mAHxIAAvhMB5NAAAIAAPhg");
	var mask_graphics_25 = new cjs.Graphics().p("Eg8mAIDIAAwFMB5NAAAIAAQFg");
	var mask_graphics_26 = new cjs.Graphics().p("Eg8mAIUIAAwnMB5NAAAIAAQng");
	var mask_graphics_27 = new cjs.Graphics().p("Eg8mAImIAAxLMB5NAAAIAARLg");
	var mask_graphics_28 = new cjs.Graphics().p("Eg8mAI3IAAxtMB5NAAAIAARtg");
	var mask_graphics_29 = new cjs.Graphics().p("Eg8mAJJIAAyRMB5NAAAIAASRg");
	var mask_graphics_30 = new cjs.Graphics().p("Eg8mAJaIAAyzMB5NAAAIAASzg");
	var mask_graphics_31 = new cjs.Graphics().p("Eg8mAJsIAAzXMB5NAAAIAATXg");
	var mask_graphics_32 = new cjs.Graphics().p("Eg8mAJ9IAAz5MB5NAAAIAAT5g");
	var mask_graphics_33 = new cjs.Graphics().p("Eg8mAKPIAA0dMB5NAAAIAAUdg");
	var mask_graphics_34 = new cjs.Graphics().p("Eg8mAKgIAA0/MB5NAAAIAAU/g");
	var mask_graphics_35 = new cjs.Graphics().p("Eg8mAKyIAA1jMB5NAAAIAAVjg");
	var mask_graphics_36 = new cjs.Graphics().p("Eg8mALDIAA2FMB5NAAAIAAWFg");
	var mask_graphics_37 = new cjs.Graphics().p("Eg8mALVIAA2pMB5NAAAIAAWpg");
	var mask_graphics_38 = new cjs.Graphics().p("Eg8mALmIAA3LMB5NAAAIAAXLg");
	var mask_graphics_39 = new cjs.Graphics().p("Eg8mAL4IAA3vMB5NAAAIAAXvg");
	var mask_graphics_40 = new cjs.Graphics().p("Eg8mAMJIAA4RMB5NAAAIAAYRg");
	var mask_graphics_41 = new cjs.Graphics().p("Eg8mAMbIAA41MB5NAAAIAAY1g");
	var mask_graphics_42 = new cjs.Graphics().p("Eg8mAMsIAA5XMB5NAAAIAAZXg");
	var mask_graphics_43 = new cjs.Graphics().p("Eg8mAM+IAA57MB5NAAAIAAZ7g");
	var mask_graphics_44 = new cjs.Graphics().p("Eg8mANPIAA6dMB5NAAAIAAadg");
	var mask_graphics_45 = new cjs.Graphics().p("Eg8mANhIAA7BMB5NAAAIAAbBg");
	var mask_graphics_46 = new cjs.Graphics().p("Eg8mANyIAA7jMB5NAAAIAAbjg");
	var mask_graphics_47 = new cjs.Graphics().p("Eg8mAOEIAA8HMB5NAAAIAAcHg");
	var mask_graphics_48 = new cjs.Graphics().p("Eg8mAOVIAA8pMB5NAAAIAAcpg");
	var mask_graphics_49 = new cjs.Graphics().p("Eg8mAOnIAA9NMB5NAAAIAAdNg");
	var mask_graphics_50 = new cjs.Graphics().p("Eg8mAO4IAA9vMB5NAAAIAAdvg");
	var mask_graphics_51 = new cjs.Graphics().p("Eg8mAPKIAA+TMB5NAAAIAAeTg");
	var mask_graphics_52 = new cjs.Graphics().p("Eg8mAPbIAA+1MB5NAAAIAAe1g");
	var mask_graphics_53 = new cjs.Graphics().p("Eg8mAPtIAA/ZMB5NAAAIAAfZg");
	var mask_graphics_54 = new cjs.Graphics().p("Eg8mAP+IAA/7MB5NAAAIAAf7g");
	var mask_graphics_55 = new cjs.Graphics().p("Eg8mAQQMAAAggfMB5NAAAMAAAAgfg");
	var mask_graphics_56 = new cjs.Graphics().p("Eg8mAQhMAAAghBMB5NAAAMAAAAhBg");
	var mask_graphics_57 = new cjs.Graphics().p("Eg8mAQzMAAAghlMB5NAAAMAAAAhlg");
	var mask_graphics_58 = new cjs.Graphics().p("Eg8mARFMAAAgiJMB5NAAAMAAAAiJg");
	var mask_graphics_59 = new cjs.Graphics().p("Eg8mARWMAAAgirMB5NAAAMAAAAirg");
	var mask_graphics_60 = new cjs.Graphics().p("Eg8mARoMAAAgjPMB5NAAAMAAAAjPg");
	var mask_graphics_61 = new cjs.Graphics().p("Eg8mAR5MAAAgjxMB5NAAAMAAAAjxg");
	var mask_graphics_62 = new cjs.Graphics().p("Eg8mASLMAAAgkVMB5NAAAMAAAAkVg");
	var mask_graphics_63 = new cjs.Graphics().p("Eg8mAScMAAAgk3MB5NAAAMAAAAk3g");
	var mask_graphics_64 = new cjs.Graphics().p("Eg8mASuMAAAglbMB5NAAAMAAAAlbg");
	var mask_graphics_65 = new cjs.Graphics().p("Eg8mAS/MAAAgl9MB5NAAAMAAAAl9g");
	var mask_graphics_66 = new cjs.Graphics().p("Eg8mATRMAAAgmhMB5NAAAMAAAAmhg");
	var mask_graphics_67 = new cjs.Graphics().p("Eg8mATiMAAAgnDMB5NAAAMAAAAnDg");
	var mask_graphics_68 = new cjs.Graphics().p("Eg8mAT0MAAAgnnMB5NAAAMAAAAnng");
	var mask_graphics_69 = new cjs.Graphics().p("Eg8mAUFMAAAgoJMB5NAAAMAAAAoJg");
	var mask_graphics_70 = new cjs.Graphics().p("Eg8mAUXMAAAgotMB5NAAAMAAAAotg");
	var mask_graphics_71 = new cjs.Graphics().p("Eg8mAUoMAAAgpPMB5NAAAMAAAApPg");
	var mask_graphics_72 = new cjs.Graphics().p("Eg8mAU6MAAAgpzMB5NAAAMAAAApzg");
	var mask_graphics_73 = new cjs.Graphics().p("Eg8mAVLMAAAgqVMB5NAAAMAAAAqVg");
	var mask_graphics_74 = new cjs.Graphics().p("Eg8mAVdMAAAgq5MB5NAAAMAAAAq5g");
	var mask_graphics_75 = new cjs.Graphics().p("Eg8mAVuMAAAgrbMB5NAAAMAAAArbg");
	var mask_graphics_76 = new cjs.Graphics().p("Eg8mAWAMAAAgr/MB5NAAAMAAAAr/g");
	var mask_graphics_77 = new cjs.Graphics().p("Eg8mAWRMAAAgshMB5NAAAMAAAAshg");
	var mask_graphics_78 = new cjs.Graphics().p("Eg8mAWjMAAAgtFMB5NAAAMAAAAtFg");
	var mask_graphics_79 = new cjs.Graphics().p("Eg8mAW0MAAAgtnMB5NAAAMAAAAtng");
	var mask_graphics_80 = new cjs.Graphics().p("Eg8mAXGMAAAguLMB5NAAAMAAAAuLg");
	var mask_graphics_81 = new cjs.Graphics().p("Eg8mAXXMAAAgutMB5NAAAMAAAAutg");
	var mask_graphics_82 = new cjs.Graphics().p("Eg8mAXpMAAAgvRMB5NAAAMAAAAvRg");
	var mask_graphics_83 = new cjs.Graphics().p("Eg8mAX6MAAAgvzMB5NAAAMAAAAvzg");
	var mask_graphics_84 = new cjs.Graphics().p("Eg8mAYMMAAAgwXMB5NAAAMAAAAwXg");
	var mask_graphics_85 = new cjs.Graphics().p("Eg8mAYdMAAAgw5MB5NAAAMAAAAw5g");
	var mask_graphics_86 = new cjs.Graphics().p("Eg8mAYvMAAAgxdMB5NAAAMAAAAxdg");
	var mask_graphics_87 = new cjs.Graphics().p("Eg8mAZAMAAAgx/MB5NAAAMAAAAx/g");
	var mask_graphics_88 = new cjs.Graphics().p("Eg8mAZSMAAAgyjMB5NAAAMAAAAyjg");
	var mask_graphics_89 = new cjs.Graphics().p("Eg8mAZjMAAAgzFMB5NAAAMAAAAzFg");
	var mask_graphics_90 = new cjs.Graphics().p("Eg8mAZ1MAAAgzpMB5NAAAMAAAAzpg");
	var mask_graphics_91 = new cjs.Graphics().p("Eg8mAaGMAAAg0LMB5NAAAMAAAA0Lg");
	var mask_graphics_92 = new cjs.Graphics().p("Eg8mAaYMAAAg0vMB5NAAAMAAAA0vg");
	var mask_graphics_93 = new cjs.Graphics().p("Eg8mAapMAAAg1RMB5NAAAMAAAA1Rg");
	var mask_graphics_94 = new cjs.Graphics().p("Eg1iAlMMAAAg11MB5NAAAMAAAA11g");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:478.4,y:139.1}).wait(1).to({graphics:mask_graphics_1,x:478.4,y:140.8}).wait(1).to({graphics:mask_graphics_2,x:478.4,y:142.6}).wait(1).to({graphics:mask_graphics_3,x:478.4,y:144.3}).wait(1).to({graphics:mask_graphics_4,x:478.4,y:146.1}).wait(1).to({graphics:mask_graphics_5,x:478.4,y:147.8}).wait(1).to({graphics:mask_graphics_6,x:478.4,y:149.6}).wait(1).to({graphics:mask_graphics_7,x:478.4,y:151.3}).wait(1).to({graphics:mask_graphics_8,x:478.4,y:153.1}).wait(1).to({graphics:mask_graphics_9,x:478.4,y:154.8}).wait(1).to({graphics:mask_graphics_10,x:478.4,y:156.6}).wait(1).to({graphics:mask_graphics_11,x:478.4,y:158.3}).wait(1).to({graphics:mask_graphics_12,x:478.4,y:160.1}).wait(1).to({graphics:mask_graphics_13,x:478.4,y:161.8}).wait(1).to({graphics:mask_graphics_14,x:478.4,y:163.6}).wait(1).to({graphics:mask_graphics_15,x:478.4,y:165.3}).wait(1).to({graphics:mask_graphics_16,x:478.4,y:167.1}).wait(1).to({graphics:mask_graphics_17,x:478.4,y:168.8}).wait(1).to({graphics:mask_graphics_18,x:478.4,y:170.6}).wait(1).to({graphics:mask_graphics_19,x:478.4,y:172.4}).wait(1).to({graphics:mask_graphics_20,x:478.4,y:174.1}).wait(1).to({graphics:mask_graphics_21,x:478.4,y:175.9}).wait(1).to({graphics:mask_graphics_22,x:478.4,y:177.6}).wait(1).to({graphics:mask_graphics_23,x:478.4,y:179.4}).wait(1).to({graphics:mask_graphics_24,x:478.4,y:181.1}).wait(1).to({graphics:mask_graphics_25,x:478.4,y:182.9}).wait(1).to({graphics:mask_graphics_26,x:478.4,y:184.6}).wait(1).to({graphics:mask_graphics_27,x:478.4,y:186.4}).wait(1).to({graphics:mask_graphics_28,x:478.4,y:188.1}).wait(1).to({graphics:mask_graphics_29,x:478.4,y:189.9}).wait(1).to({graphics:mask_graphics_30,x:478.4,y:191.6}).wait(1).to({graphics:mask_graphics_31,x:478.4,y:193.4}).wait(1).to({graphics:mask_graphics_32,x:478.4,y:195.1}).wait(1).to({graphics:mask_graphics_33,x:478.4,y:196.9}).wait(1).to({graphics:mask_graphics_34,x:478.4,y:198.6}).wait(1).to({graphics:mask_graphics_35,x:478.4,y:200.4}).wait(1).to({graphics:mask_graphics_36,x:478.4,y:202.1}).wait(1).to({graphics:mask_graphics_37,x:478.4,y:203.9}).wait(1).to({graphics:mask_graphics_38,x:478.4,y:205.6}).wait(1).to({graphics:mask_graphics_39,x:478.4,y:207.4}).wait(1).to({graphics:mask_graphics_40,x:478.4,y:209.1}).wait(1).to({graphics:mask_graphics_41,x:478.4,y:210.9}).wait(1).to({graphics:mask_graphics_42,x:478.4,y:212.6}).wait(1).to({graphics:mask_graphics_43,x:478.4,y:214.4}).wait(1).to({graphics:mask_graphics_44,x:478.4,y:216.1}).wait(1).to({graphics:mask_graphics_45,x:478.4,y:217.9}).wait(1).to({graphics:mask_graphics_46,x:478.4,y:219.6}).wait(1).to({graphics:mask_graphics_47,x:478.4,y:221.4}).wait(1).to({graphics:mask_graphics_48,x:478.4,y:223.1}).wait(1).to({graphics:mask_graphics_49,x:478.4,y:224.9}).wait(1).to({graphics:mask_graphics_50,x:478.4,y:226.6}).wait(1).to({graphics:mask_graphics_51,x:478.4,y:228.4}).wait(1).to({graphics:mask_graphics_52,x:478.4,y:230.1}).wait(1).to({graphics:mask_graphics_53,x:478.4,y:231.9}).wait(1).to({graphics:mask_graphics_54,x:478.4,y:233.6}).wait(1).to({graphics:mask_graphics_55,x:478.4,y:235.4}).wait(1).to({graphics:mask_graphics_56,x:478.4,y:237.1}).wait(1).to({graphics:mask_graphics_57,x:478.4,y:238.9}).wait(1).to({graphics:mask_graphics_58,x:478.4,y:240.7}).wait(1).to({graphics:mask_graphics_59,x:478.4,y:242.4}).wait(1).to({graphics:mask_graphics_60,x:478.4,y:244.2}).wait(1).to({graphics:mask_graphics_61,x:478.4,y:245.9}).wait(1).to({graphics:mask_graphics_62,x:478.4,y:247.7}).wait(1).to({graphics:mask_graphics_63,x:478.4,y:249.4}).wait(1).to({graphics:mask_graphics_64,x:478.4,y:251.2}).wait(1).to({graphics:mask_graphics_65,x:478.4,y:252.9}).wait(1).to({graphics:mask_graphics_66,x:478.4,y:254.7}).wait(1).to({graphics:mask_graphics_67,x:478.4,y:256.4}).wait(1).to({graphics:mask_graphics_68,x:478.4,y:258.2}).wait(1).to({graphics:mask_graphics_69,x:478.4,y:259.9}).wait(1).to({graphics:mask_graphics_70,x:478.4,y:261.7}).wait(1).to({graphics:mask_graphics_71,x:478.4,y:263.4}).wait(1).to({graphics:mask_graphics_72,x:478.4,y:265.2}).wait(1).to({graphics:mask_graphics_73,x:478.4,y:266.9}).wait(1).to({graphics:mask_graphics_74,x:478.4,y:268.7}).wait(1).to({graphics:mask_graphics_75,x:478.4,y:270.4}).wait(1).to({graphics:mask_graphics_76,x:478.4,y:272.2}).wait(1).to({graphics:mask_graphics_77,x:478.4,y:273.9}).wait(1).to({graphics:mask_graphics_78,x:478.4,y:275.7}).wait(1).to({graphics:mask_graphics_79,x:478.4,y:277.4}).wait(1).to({graphics:mask_graphics_80,x:478.4,y:279.2}).wait(1).to({graphics:mask_graphics_81,x:478.4,y:280.9}).wait(1).to({graphics:mask_graphics_82,x:478.4,y:282.7}).wait(1).to({graphics:mask_graphics_83,x:478.4,y:284.4}).wait(1).to({graphics:mask_graphics_84,x:478.4,y:286.2}).wait(1).to({graphics:mask_graphics_85,x:478.4,y:287.9}).wait(1).to({graphics:mask_graphics_86,x:478.4,y:289.7}).wait(1).to({graphics:mask_graphics_87,x:478.4,y:291.4}).wait(1).to({graphics:mask_graphics_88,x:478.4,y:293.2}).wait(1).to({graphics:mask_graphics_89,x:478.4,y:294.9}).wait(1).to({graphics:mask_graphics_90,x:478.4,y:296.7}).wait(1).to({graphics:mask_graphics_91,x:478.4,y:298.4}).wait(1).to({graphics:mask_graphics_92,x:478.4,y:300.2}).wait(1).to({graphics:mask_graphics_93,x:478.4,y:301.9}).wait(1).to({graphics:mask_graphics_94,x:433.2,y:238}).wait(1));

	// Capa 6
	this.text = new cjs.Text("N", "17px Verdana", "#208E5E");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.lineWidth = 129;
	this.text.setTransform(459.8,448.9);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#208E5E").ss(6,1,1).p("AqdAAIU7AA");
	this.shape.setTransform(465.5,433.9,1,2.236,0,-63.3,0);

	this.text_1 = new cjs.Text("CAtr (SAdj)", "17px Verdana", "#208E5E");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 19;
	this.text_1.lineWidth = 63;
	this.text_1.setTransform(758.2,370.1);

	this.text_2 = new cjs.Text("N", "17px Verdana", "#208E5E");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 19;
	this.text_2.lineWidth = 35;
	this.text_2.setTransform(699.8,370.1);

	this.text_3 = new cjs.Text("CC (SAdv)", "17px Verdana", "#208E5E");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 19;
	this.text_3.lineWidth = 63;
	this.text_3.setTransform(639.7,370.1);

	this.text_4 = new cjs.Text("CC (SAdv)", "17px Verdana", "#208E5E");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 19;
	this.text_4.lineWidth = 63;
	this.text_4.setTransform(577.1,370.1);

	this.info7_03 = new cjs.Text("Sujeto", "17px Verdana", "#B30218");
	this.info7_03.lineHeight = 19;
	this.info7_03.lineWidth = 58;
	this.info7_03.setTransform(332.9,369.6);

	this.text_5 = new cjs.Text("CD (SN)", "17px Verdana", "#208E5E");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 19;
	this.text_5.lineWidth = 46;
	this.text_5.setTransform(306.2,370.1);

	this.info7_04 = new cjs.Text("SV Predicado", "17px Verdana", "#208E5E");
	this.info7_04.textAlign = "right";
	this.info7_04.lineHeight = 19;
	this.info7_04.lineWidth = 129;
	this.info7_04.setTransform(524.4,369.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#208E5E").ss(6,1,1).p("A7EAAMA2JAAA");
	this.shape_1.setTransform(760.2,354.3,0.135,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#208E5E").ss(6,1,1).p("A7EAAMA2JAAA");
	this.shape_2.setTransform(701.7,354.3,0.104,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#208E5E").ss(6,1,1).p("A7EAAMA2JAAA");
	this.shape_3.setTransform(641.6,354.3,0.104,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#208E5E").ss(6,1,1).p("A7EAAMA2JAAA");
	this.shape_4.setTransform(579,354.3,0.104,1);

	this.text_6 = new cjs.Text("Ø", "17px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 19;
	this.text_6.lineWidth = 37;
	this.text_6.setTransform(361.5,339.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#208E5E").ss(6,1,1).p("AqdAAIU7AA");
	this.shape_5.setTransform(465.5,354.3,1,2.236,0,-63.3,0);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#208E5E").ss(6,1,1).p("AjcAAIG5AA");
	this.shape_6.setTransform(310.1,354.3,1,2.236,0,-63.3,0);

	this.text_7 = new cjs.Text("Esp", "17px Verdana", "#B30218");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 19;
	this.text_7.lineWidth = 46;
	this.text_7.setTransform(187.9,303.2);

	this.text_8 = new cjs.Text("N", "17px Verdana", "#B30218");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 19;
	this.text_8.lineWidth = 62;
	this.text_8.setTransform(250.2,303.2);

	this.text_9 = new cjs.Text("CN (O Sub Adj)", "17px Verdana", "#B30218");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 19;
	this.text_9.lineWidth = 226;
	this.text_9.setTransform(407.2,303.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#B30218").ss(6,1,1).p("A7EAAMA2JAAA");
	this.shape_7.setTransform(189.9,290.7,0.09,1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#B30218").ss(6,1,1).p("A7EAAMA2JAAA");
	this.shape_8.setTransform(252.3,290.7,0.18,1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#B30218").ss(6,1,1).p("A7EAAMA2JAAA");
	this.shape_9.setTransform(408.9,290.7,0.651,1);

	this.info7_02 = new cjs.Text("SV Predicado", "17px Verdana", "#208E5E");
	this.info7_02.textAlign = "center";
	this.info7_02.lineHeight = 19;
	this.info7_02.lineWidth = 214;
	this.info7_02.setTransform(668.9,239.9);

	this.info7_01 = new cjs.Text("SN Sujeto", "17px Verdana", "#B30218");
	this.info7_01.textAlign = "center";
	this.info7_01.lineHeight = 19;
	this.info7_01.lineWidth = 346;
	this.info7_01.setTransform(345.6,239.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#208E5E").ss(6,1,1).p("A7EAAMA2JAAA");
	this.shape_10.setTransform(670.7,227.4,0.618,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#B30218").ss(6,1,1).p("A7EAAMA2JAAA");
	this.shape_11.setTransform(347.4,227.4);

	this.text_10 = new cjs.Text("Adj", "17px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 19;
	this.text_10.lineWidth = 40;
	this.text_10.setTransform(743.8,189.9);

	this.text_11 = new cjs.Text("V", "17px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 19;
	this.text_11.lineWidth = 40;
	this.text_11.setTransform(685.3,189.9);

	this.text_12 = new cjs.Text("Adv", "17px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 19;
	this.text_12.lineWidth = 40;
	this.text_12.setTransform(630.2,189.9);

	this.text_13 = new cjs.Text("Adv", "17px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 19;
	this.text_13.lineWidth = 40;
	this.text_13.setTransform(578.4,189.9);

	this.text_14 = new cjs.Text("V", "17px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 19;
	this.text_14.lineWidth = 133;
	this.text_14.setTransform(449.1,191.9);

	this.text_15 = new cjs.Text("Pron", "17px Verdana");
	this.text_15.textAlign = "center";
	this.text_15.lineHeight = 19;
	this.text_15.lineWidth = 40;
	this.text_15.setTransform(318.4,189.9);

	this.text_16 = new cjs.Text("N", "17px Verdana");
	this.text_16.textAlign = "center";
	this.text_16.lineHeight = 19;
	this.text_16.lineWidth = 40;
	this.text_16.setTransform(242.2,189.9);

	this.text_17 = new cjs.Text("Det", "17px Verdana");
	this.text_17.textAlign = "center";
	this.text_17.lineHeight = 19;
	this.text_17.lineWidth = 40;
	this.text_17.setTransform(182.9,189.9);

	

	

	this.text.mask = this.shape.mask = this.text_1.mask = this.text_2.mask = this.text_3.mask = this.text_4.mask = this.info7_03.mask = this.text_5.mask = this.info7_04.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.text_6.mask = this.shape_5.mask = this.shape_6.mask = this.text_7.mask = this.text_8.mask = this.text_9.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.info7_02.mask = this.info7_01.mask = this.shape_10.mask = this.shape_11.mask = this.text_10.mask = this.text_11.mask = this.text_12.mask = this.text_13.mask = this.text_14.mask = this.text_15.mask = this.text_16.mask = this.text_17.mask =  mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_17},{t:this.text_16},{t:this.text_15},{t:this.text_14},{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.shape_11},{t:this.shape_10},{t:this.info7_01},{t:this.info7_02},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.shape_6},{t:this.shape_5},{t:this.text_6},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.info7_04},{t:this.text_5},{t:this.info7_03},{t:this.text_4},{t:this.text_3},{t:this.text_2},{t:this.text_1},{t:this.shape},{t:this.text}]}).wait(95));

	// Blanco
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("Eg8mABNIAAiZMB5NAAAIAACZg");
	this.shape_20.setTransform(478.4,139.1);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Eg8mABeIAAi7MB5NAAAIAAC7g");
	this.shape_21.setTransform(478.4,140.8);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Eg8mABwIAAjfMB5NAAAIAADfg");
	this.shape_22.setTransform(478.4,142.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("Eg8mACBIAAkBMB5NAAAIAAEBg");
	this.shape_23.setTransform(478.4,144.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Eg8mACTIAAklMB5NAAAIAAElg");
	this.shape_24.setTransform(478.4,146.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("Eg8mACkIAAlHMB5NAAAIAAFHg");
	this.shape_25.setTransform(478.4,147.8);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("Eg8mAC2IAAlrMB5NAAAIAAFrg");
	this.shape_26.setTransform(478.4,149.6);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("Eg8mADHIAAmNMB5NAAAIAAGNg");
	this.shape_27.setTransform(478.4,151.3);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("Eg8mADZIAAmxMB5NAAAIAAGxg");
	this.shape_28.setTransform(478.4,153.1);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("Eg8mADqIAAnTMB5NAAAIAAHTg");
	this.shape_29.setTransform(478.4,154.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("Eg8mAD8IAAn3MB5NAAAIAAH3g");
	this.shape_30.setTransform(478.4,156.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("Eg8mAENIAAoZMB5NAAAIAAIZg");
	this.shape_31.setTransform(478.4,158.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("Eg8mAEfIAAo9MB5NAAAIAAI9g");
	this.shape_32.setTransform(478.4,160.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("Eg8mAEwIAApfMB5NAAAIAAJfg");
	this.shape_33.setTransform(478.4,161.8);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("Eg8mAFCIAAqDMB5NAAAIAAKDg");
	this.shape_34.setTransform(478.4,163.6);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("Eg8mAFTIAAqlMB5NAAAIAAKlg");
	this.shape_35.setTransform(478.4,165.3);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("Eg8mAFlIAArJMB5NAAAIAALJg");
	this.shape_36.setTransform(478.4,167.1);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("Eg8mAF2IAArrMB5NAAAIAALrg");
	this.shape_37.setTransform(478.4,168.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("Eg8mAGIIAAsPMB5NAAAIAAMPg");
	this.shape_38.setTransform(478.4,170.6);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("Eg8mAGaIAAszMB5NAAAIAAMzg");
	this.shape_39.setTransform(478.4,172.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("Eg8mAGrIAAtVMB5NAAAIAANVg");
	this.shape_40.setTransform(478.4,174.1);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("Eg8mAG9IAAt5MB5NAAAIAAN5g");
	this.shape_41.setTransform(478.4,175.9);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("Eg8mAHOIAAubMB5NAAAIAAObg");
	this.shape_42.setTransform(478.4,177.6);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("Eg8mAHgIAAu/MB5NAAAIAAO/g");
	this.shape_43.setTransform(478.4,179.4);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("Eg8mAHxIAAvhMB5NAAAIAAPhg");
	this.shape_44.setTransform(478.4,181.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("Eg8mAIDIAAwFMB5NAAAIAAQFg");
	this.shape_45.setTransform(478.4,182.9);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("Eg8mAIUIAAwnMB5NAAAIAAQng");
	this.shape_46.setTransform(478.4,184.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("Eg8mAImIAAxLMB5NAAAIAARLg");
	this.shape_47.setTransform(478.4,186.4);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("Eg8mAI3IAAxtMB5NAAAIAARtg");
	this.shape_48.setTransform(478.4,188.1);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("Eg8mAJJIAAyRMB5NAAAIAASRg");
	this.shape_49.setTransform(478.4,189.9);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("Eg8mAJaIAAyzMB5NAAAIAASzg");
	this.shape_50.setTransform(478.4,191.6);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("Eg8mAJsIAAzXMB5NAAAIAATXg");
	this.shape_51.setTransform(478.4,193.4);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("Eg8mAJ9IAAz5MB5NAAAIAAT5g");
	this.shape_52.setTransform(478.4,195.1);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("Eg8mAKPIAA0dMB5NAAAIAAUdg");
	this.shape_53.setTransform(478.4,196.9);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("Eg8mAKgIAA0/MB5NAAAIAAU/g");
	this.shape_54.setTransform(478.4,198.6);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("Eg8mAKyIAA1jMB5NAAAIAAVjg");
	this.shape_55.setTransform(478.4,200.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("Eg8mALDIAA2FMB5NAAAIAAWFg");
	this.shape_56.setTransform(478.4,202.1);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("Eg8mALVIAA2pMB5NAAAIAAWpg");
	this.shape_57.setTransform(478.4,203.9);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("Eg8mALmIAA3LMB5NAAAIAAXLg");
	this.shape_58.setTransform(478.4,205.6);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("Eg8mAL4IAA3vMB5NAAAIAAXvg");
	this.shape_59.setTransform(478.4,207.4);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("Eg8mAMJIAA4RMB5NAAAIAAYRg");
	this.shape_60.setTransform(478.4,209.1);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("Eg8mAMbIAA41MB5NAAAIAAY1g");
	this.shape_61.setTransform(478.4,210.9);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("Eg8mAMsIAA5XMB5NAAAIAAZXg");
	this.shape_62.setTransform(478.4,212.6);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("Eg8mAM+IAA57MB5NAAAIAAZ7g");
	this.shape_63.setTransform(478.4,214.4);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("Eg8mANPIAA6dMB5NAAAIAAadg");
	this.shape_64.setTransform(478.4,216.1);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("Eg8mANhIAA7BMB5NAAAIAAbBg");
	this.shape_65.setTransform(478.4,217.9);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("Eg8mANyIAA7jMB5NAAAIAAbjg");
	this.shape_66.setTransform(478.4,219.6);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("Eg8mAOEIAA8HMB5NAAAIAAcHg");
	this.shape_67.setTransform(478.4,221.4);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("Eg8mAOVIAA8pMB5NAAAIAAcpg");
	this.shape_68.setTransform(478.4,223.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("Eg8mAOnIAA9NMB5NAAAIAAdNg");
	this.shape_69.setTransform(478.4,224.9);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("Eg8mAO4IAA9vMB5NAAAIAAdvg");
	this.shape_70.setTransform(478.4,226.6);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("Eg8mAPKIAA+TMB5NAAAIAAeTg");
	this.shape_71.setTransform(478.4,228.4);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("Eg8mAPbIAA+1MB5NAAAIAAe1g");
	this.shape_72.setTransform(478.4,230.1);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("Eg8mAPtIAA/ZMB5NAAAIAAfZg");
	this.shape_73.setTransform(478.4,231.9);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("Eg8mAP+IAA/7MB5NAAAIAAf7g");
	this.shape_74.setTransform(478.4,233.6);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("Eg8mAQQMAAAggfMB5NAAAMAAAAgfg");
	this.shape_75.setTransform(478.4,235.4);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("Eg8mAQhMAAAghBMB5NAAAMAAAAhBg");
	this.shape_76.setTransform(478.4,237.1);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("Eg8mAQzMAAAghlMB5NAAAMAAAAhlg");
	this.shape_77.setTransform(478.4,238.9);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("Eg8mARFMAAAgiJMB5NAAAMAAAAiJg");
	this.shape_78.setTransform(478.4,240.7);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("Eg8mARWMAAAgirMB5NAAAMAAAAirg");
	this.shape_79.setTransform(478.4,242.4);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("Eg8mARoMAAAgjPMB5NAAAMAAAAjPg");
	this.shape_80.setTransform(478.4,244.2);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("Eg8mAR5MAAAgjxMB5NAAAMAAAAjxg");
	this.shape_81.setTransform(478.4,245.9);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("Eg8mASLMAAAgkVMB5NAAAMAAAAkVg");
	this.shape_82.setTransform(478.4,247.7);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("Eg8mAScMAAAgk3MB5NAAAMAAAAk3g");
	this.shape_83.setTransform(478.4,249.4);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("Eg8mASuMAAAglbMB5NAAAMAAAAlbg");
	this.shape_84.setTransform(478.4,251.2);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("Eg8mAS/MAAAgl9MB5NAAAMAAAAl9g");
	this.shape_85.setTransform(478.4,252.9);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("Eg8mATRMAAAgmhMB5NAAAMAAAAmhg");
	this.shape_86.setTransform(478.4,254.7);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("Eg8mATiMAAAgnDMB5NAAAMAAAAnDg");
	this.shape_87.setTransform(478.4,256.4);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("Eg8mAT0MAAAgnnMB5NAAAMAAAAnng");
	this.shape_88.setTransform(478.4,258.2);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("Eg8mAUFMAAAgoJMB5NAAAMAAAAoJg");
	this.shape_89.setTransform(478.4,259.9);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("Eg8mAUXMAAAgotMB5NAAAMAAAAotg");
	this.shape_90.setTransform(478.4,261.7);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("Eg8mAUoMAAAgpPMB5NAAAMAAAApPg");
	this.shape_91.setTransform(478.4,263.4);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("Eg8mAU6MAAAgpzMB5NAAAMAAAApzg");
	this.shape_92.setTransform(478.4,265.2);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("Eg8mAVLMAAAgqVMB5NAAAMAAAAqVg");
	this.shape_93.setTransform(478.4,266.9);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("Eg8mAVdMAAAgq5MB5NAAAMAAAAq5g");
	this.shape_94.setTransform(478.4,268.7);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("Eg8mAVuMAAAgrbMB5NAAAMAAAArbg");
	this.shape_95.setTransform(478.4,270.4);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("Eg8mAWAMAAAgr/MB5NAAAMAAAAr/g");
	this.shape_96.setTransform(478.4,272.2);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("Eg8mAWRMAAAgshMB5NAAAMAAAAshg");
	this.shape_97.setTransform(478.4,273.9);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("Eg8mAWjMAAAgtFMB5NAAAMAAAAtFg");
	this.shape_98.setTransform(478.4,275.7);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("Eg8mAW0MAAAgtnMB5NAAAMAAAAtng");
	this.shape_99.setTransform(478.4,277.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("Eg8mAXGMAAAguLMB5NAAAMAAAAuLg");
	this.shape_100.setTransform(478.4,279.2);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("Eg8mAXXMAAAgutMB5NAAAMAAAAutg");
	this.shape_101.setTransform(478.4,280.9);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("Eg8mAXpMAAAgvRMB5NAAAMAAAAvRg");
	this.shape_102.setTransform(478.4,282.7);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("Eg8mAX6MAAAgvzMB5NAAAMAAAAvzg");
	this.shape_103.setTransform(478.4,284.4);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("Eg8mAYMMAAAgwXMB5NAAAMAAAAwXg");
	this.shape_104.setTransform(478.4,286.2);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("Eg8mAYdMAAAgw5MB5NAAAMAAAAw5g");
	this.shape_105.setTransform(478.4,287.9);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("Eg8mAYvMAAAgxdMB5NAAAMAAAAxdg");
	this.shape_106.setTransform(478.4,289.7);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("Eg8mAZAMAAAgx/MB5NAAAMAAAAx/g");
	this.shape_107.setTransform(478.4,291.4);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("Eg8mAZSMAAAgyjMB5NAAAMAAAAyjg");
	this.shape_108.setTransform(478.4,293.2);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("Eg8mAZjMAAAgzFMB5NAAAMAAAAzFg");
	this.shape_109.setTransform(478.4,294.9);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("Eg8mAZ1MAAAgzpMB5NAAAMAAAAzpg");
	this.shape_110.setTransform(478.4,296.7);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("Eg8mAaGMAAAg0LMB5NAAAMAAAA0Lg");
	this.shape_111.setTransform(478.4,298.4);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("Eg8mAaYMAAAg0vMB5NAAAMAAAA0vg");
	this.shape_112.setTransform(478.4,300.2);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("Eg8mAapMAAAg1RMB5NAAAMAAAA1Rg");
	this.shape_113.setTransform(478.4,301.9);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("Eg8mAa7MAAAg11MB5NAAAMAAAA11g");
	this.shape_114.setTransform(478.4,303.3,1,1,0,0,0,0,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_20}]}).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).wait(100000));

	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);

(lib.popup_info_08 = function (texto) {
        this.initialize();
        basicos(this, 1, 0, 0, 0, 1);

        // Blanco
        this.shape0 = new cjs.Shape();
        this.shape0.graphics.f("#FFFFFF").s().p("EhKNAvgMAAAhe/MCUbAAAMAAABe/g");
        this.shape0.setTransform(475, 304);
        
      var html = createDiv(texto, "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
        this.oraciones = new cjs.DOMElement(html);
        this.oraciones.setTransform(90, -452);
        
          this.animacion=new lib.popup_info_08_anim();
        this.animacion.setTransform(0,5);
        this.cerrar.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });

        this.addChild(this.shape0, this.logo, this.cerrar, this.oraciones,this.animacion);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    
(lib.popup_info_08_anim = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("Eg8mABNIAAiZMB5NAAAIAACZg");
	var mask_graphics_1 = new cjs.Graphics().p("Eg8mABhIAAjBMB5NAAAIAADBg");
	var mask_graphics_2 = new cjs.Graphics().p("Eg8mAB0IAAjnMB5NAAAIAADng");
	var mask_graphics_3 = new cjs.Graphics().p("Eg8mACIIAAkPMB5NAAAIAAEPg");
	var mask_graphics_4 = new cjs.Graphics().p("Eg8mACcIAAk3MB5NAAAIAAE3g");
	var mask_graphics_5 = new cjs.Graphics().p("Eg8mACwIAAlfMB5NAAAIAAFfg");
	var mask_graphics_6 = new cjs.Graphics().p("Eg8mADDIAAmFMB5NAAAIAAGFg");
	var mask_graphics_7 = new cjs.Graphics().p("Eg8mADXIAAmtMB5NAAAIAAGtg");
	var mask_graphics_8 = new cjs.Graphics().p("Eg8mADrIAAnVMB5NAAAIAAHVg");
	var mask_graphics_9 = new cjs.Graphics().p("Eg8mAD/IAAn9MB5NAAAIAAH9g");
	var mask_graphics_10 = new cjs.Graphics().p("Eg8mAESIAAojMB5NAAAIAAIjg");
	var mask_graphics_11 = new cjs.Graphics().p("Eg8mAEmIAApLMB5NAAAIAAJLg");
	var mask_graphics_12 = new cjs.Graphics().p("Eg8mAE6IAApzMB5NAAAIAAJzg");
	var mask_graphics_13 = new cjs.Graphics().p("Eg8mAFOIAAqbMB5NAAAIAAKbg");
	var mask_graphics_14 = new cjs.Graphics().p("Eg8mAFhIAArBMB5NAAAIAALBg");
	var mask_graphics_15 = new cjs.Graphics().p("Eg8mAF1IAArpMB5NAAAIAALpg");
	var mask_graphics_16 = new cjs.Graphics().p("Eg8mAGJIAAsRMB5NAAAIAAMRg");
	var mask_graphics_17 = new cjs.Graphics().p("Eg8mAGdIAAs5MB5NAAAIAAM5g");
	var mask_graphics_18 = new cjs.Graphics().p("Eg8mAGxIAAthMB5NAAAIAANhg");
	var mask_graphics_19 = new cjs.Graphics().p("Eg8mAHEIAAuHMB5NAAAIAAOHg");
	var mask_graphics_20 = new cjs.Graphics().p("Eg8mAHYIAAuvMB5NAAAIAAOvg");
	var mask_graphics_21 = new cjs.Graphics().p("Eg8mAHsIAAvXMB5NAAAIAAPXg");
	var mask_graphics_22 = new cjs.Graphics().p("Eg8mAIAIAAv/MB5NAAAIAAP/g");
	var mask_graphics_23 = new cjs.Graphics().p("Eg8mAITIAAwlMB5NAAAIAAQlg");
	var mask_graphics_24 = new cjs.Graphics().p("Eg8mAInIAAxNMB5NAAAIAARNg");
	var mask_graphics_25 = new cjs.Graphics().p("Eg8mAI7IAAx1MB5NAAAIAAR1g");
	var mask_graphics_26 = new cjs.Graphics().p("Eg8mAJPIAAydMB5NAAAIAASdg");
	var mask_graphics_27 = new cjs.Graphics().p("Eg8mAJiIAAzDMB5NAAAIAATDg");
	var mask_graphics_28 = new cjs.Graphics().p("Eg8mAJ2IAAzrMB5NAAAIAATrg");
	var mask_graphics_29 = new cjs.Graphics().p("Eg8mAKKIAA0TMB5NAAAIAAUTg");
	var mask_graphics_30 = new cjs.Graphics().p("Eg8mAKeIAA07MB5NAAAIAAU7g");
	var mask_graphics_31 = new cjs.Graphics().p("Eg8mAKxIAA1hMB5NAAAIAAVhg");
	var mask_graphics_32 = new cjs.Graphics().p("Eg8mALFIAA2JMB5NAAAIAAWJg");
	var mask_graphics_33 = new cjs.Graphics().p("Eg8mALZIAA2xMB5NAAAIAAWxg");
	var mask_graphics_34 = new cjs.Graphics().p("Eg8mALtIAA3ZMB5NAAAIAAXZg");
	var mask_graphics_35 = new cjs.Graphics().p("Eg8mAMBIAA4BMB5NAAAIAAYBg");
	var mask_graphics_36 = new cjs.Graphics().p("Eg8mAMUIAA4nMB5NAAAIAAYng");
	var mask_graphics_37 = new cjs.Graphics().p("Eg8mAMoIAA5PMB5NAAAIAAZPg");
	var mask_graphics_38 = new cjs.Graphics().p("Eg8mAM8IAA53MB5NAAAIAAZ3g");
	var mask_graphics_39 = new cjs.Graphics().p("Eg8mANQIAA6fMB5NAAAIAAafg");
	var mask_graphics_40 = new cjs.Graphics().p("Eg8mANjIAA7FMB5NAAAIAAbFg");
	var mask_graphics_41 = new cjs.Graphics().p("Eg8mAN3IAA7tMB5NAAAIAAbtg");
	var mask_graphics_42 = new cjs.Graphics().p("Eg8mAOLIAA8VMB5NAAAIAAcVg");
	var mask_graphics_43 = new cjs.Graphics().p("Eg8mAOfIAA89MB5NAAAIAAc9g");
	var mask_graphics_44 = new cjs.Graphics().p("Eg8mAOyIAA9jMB5NAAAIAAdjg");
	var mask_graphics_45 = new cjs.Graphics().p("Eg8mAPGIAA+LMB5NAAAIAAeLg");
	var mask_graphics_46 = new cjs.Graphics().p("Eg8mAPaIAA+zMB5NAAAIAAezg");
	var mask_graphics_47 = new cjs.Graphics().p("Eg8mAPuIAA/bMB5NAAAIAAfbg");
	var mask_graphics_48 = new cjs.Graphics().p("Eg8mAQCMAAAggDMB5NAAAMAAAAgDg");
	var mask_graphics_49 = new cjs.Graphics().p("Eg8mAQVMAAAggpMB5NAAAMAAAAgpg");
	var mask_graphics_50 = new cjs.Graphics().p("Eg8mAQpMAAAghRMB5NAAAMAAAAhRg");
	var mask_graphics_51 = new cjs.Graphics().p("Eg8mAQ9MAAAgh5MB5NAAAMAAAAh5g");
	var mask_graphics_52 = new cjs.Graphics().p("Eg8mARRMAAAgihMB5NAAAMAAAAihg");
	var mask_graphics_53 = new cjs.Graphics().p("Eg8mARkMAAAgjHMB5NAAAMAAAAjHg");
	var mask_graphics_54 = new cjs.Graphics().p("Eg8mAR4MAAAgjvMB5NAAAMAAAAjvg");
	var mask_graphics_55 = new cjs.Graphics().p("Eg8mASMMAAAgkXMB5NAAAMAAAAkXg");
	var mask_graphics_56 = new cjs.Graphics().p("Eg8mASgMAAAgk/MB5NAAAMAAAAk/g");
	var mask_graphics_57 = new cjs.Graphics().p("Eg8mASzMAAAgllMB5NAAAMAAAAllg");
	var mask_graphics_58 = new cjs.Graphics().p("Eg8mATHMAAAgmNMB5NAAAMAAAAmNg");
	var mask_graphics_59 = new cjs.Graphics().p("Eg8mATbMAAAgm1MB5NAAAMAAAAm1g");
	var mask_graphics_60 = new cjs.Graphics().p("Eg8mATvMAAAgndMB5NAAAMAAAAndg");
	var mask_graphics_61 = new cjs.Graphics().p("Eg8mAUCMAAAgoDMB5NAAAMAAAAoDg");
	var mask_graphics_62 = new cjs.Graphics().p("Eg8mAUWMAAAgorMB5NAAAMAAAAorg");
	var mask_graphics_63 = new cjs.Graphics().p("Eg8mAUqMAAAgpTMB5NAAAMAAAApTg");
	var mask_graphics_64 = new cjs.Graphics().p("Eg8mAU+MAAAgp7MB5NAAAMAAAAp7g");
	var mask_graphics_65 = new cjs.Graphics().p("Eg8mAVSMAAAgqjMB5NAAAMAAAAqjg");
	var mask_graphics_66 = new cjs.Graphics().p("Eg8mAVlMAAAgrJMB5NAAAMAAAArJg");
	var mask_graphics_67 = new cjs.Graphics().p("Eg8mAV5MAAAgrxMB5NAAAMAAAArxg");
	var mask_graphics_68 = new cjs.Graphics().p("Eg8mAWNMAAAgsZMB5NAAAMAAAAsZg");
	var mask_graphics_69 = new cjs.Graphics().p("Eg8mAWhMAAAgtBMB5NAAAMAAAAtBg");
	var mask_graphics_70 = new cjs.Graphics().p("Eg8mAW0MAAAgtnMB5NAAAMAAAAtng");
	var mask_graphics_71 = new cjs.Graphics().p("Eg8mAXIMAAAguPMB5NAAAMAAAAuPg");
	var mask_graphics_72 = new cjs.Graphics().p("Eg8mAXcMAAAgu3MB5NAAAMAAAAu3g");
	var mask_graphics_73 = new cjs.Graphics().p("Eg8mAXwMAAAgvfMB5NAAAMAAAAvfg");
	var mask_graphics_74 = new cjs.Graphics().p("Eg8mAYDMAAAgwFMB5NAAAMAAAAwFg");
	var mask_graphics_75 = new cjs.Graphics().p("Eg8mAYXMAAAgwtMB5NAAAMAAAAwtg");
	var mask_graphics_76 = new cjs.Graphics().p("Eg8mAYrMAAAgxVMB5NAAAMAAAAxVg");
	var mask_graphics_77 = new cjs.Graphics().p("Eg8mAY/MAAAgx9MB5NAAAMAAAAx9g");
	var mask_graphics_78 = new cjs.Graphics().p("Eg8mAZSMAAAgyjMB5NAAAMAAAAyjg");
	var mask_graphics_79 = new cjs.Graphics().p("Eg8mAZmMAAAgzLMB5NAAAMAAAAzLg");
	var mask_graphics_80 = new cjs.Graphics().p("Eg8mAZ6MAAAgzzMB5NAAAMAAAAzzg");
	var mask_graphics_81 = new cjs.Graphics().p("Eg8mAaOMAAAg0bMB5NAAAMAAAA0bg");
	var mask_graphics_82 = new cjs.Graphics().p("Eg8mAaiMAAAg1DMB5NAAAMAAAA1Dg");
	var mask_graphics_83 = new cjs.Graphics().p("Eg8mAa1MAAAg1pMB5NAAAMAAAA1pg");
	var mask_graphics_84 = new cjs.Graphics().p("Eg8mAbJMAAAg2RMB5NAAAMAAAA2Rg");
	var mask_graphics_85 = new cjs.Graphics().p("Eg8mAbdMAAAg25MB5NAAAMAAAA25g");
	var mask_graphics_86 = new cjs.Graphics().p("Eg8mAbxMAAAg3hMB5NAAAMAAAA3hg");
	var mask_graphics_87 = new cjs.Graphics().p("Eg8mAcEMAAAg4HMB5NAAAMAAAA4Hg");
	var mask_graphics_88 = new cjs.Graphics().p("Eg8mAcYMAAAg4vMB5NAAAMAAAA4vg");
	var mask_graphics_89 = new cjs.Graphics().p("Eg8mAcsMAAAg5XMB5NAAAMAAAA5Xg");
	var mask_graphics_90 = new cjs.Graphics().p("Eg8mAdAMAAAg5/MB5NAAAMAAAA5/g");
	var mask_graphics_91 = new cjs.Graphics().p("Eg8mAdTMAAAg6lMB5NAAAMAAAA6lg");
	var mask_graphics_92 = new cjs.Graphics().p("Eg8mAdnMAAAg7NMB5NAAAMAAAA7Ng");
	var mask_graphics_93 = new cjs.Graphics().p("Eg8mAd7MAAAg71MB5NAAAMAAAA71g");
	var mask_graphics_94 = new cjs.Graphics().p("Eg1iAogMAAAg8dMB5NAAAMAAAA8dg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:478.4,y:139.1}).wait(1).to({graphics:mask_graphics_1,x:478.4,y:141.1}).wait(1).to({graphics:mask_graphics_2,x:478.4,y:143}).wait(1).to({graphics:mask_graphics_3,x:478.4,y:145}).wait(1).to({graphics:mask_graphics_4,x:478.4,y:147}).wait(1).to({graphics:mask_graphics_5,x:478.4,y:149}).wait(1).to({graphics:mask_graphics_6,x:478.4,y:150.9}).wait(1).to({graphics:mask_graphics_7,x:478.4,y:152.9}).wait(1).to({graphics:mask_graphics_8,x:478.4,y:154.9}).wait(1).to({graphics:mask_graphics_9,x:478.4,y:156.9}).wait(1).to({graphics:mask_graphics_10,x:478.4,y:158.9}).wait(1).to({graphics:mask_graphics_11,x:478.4,y:160.8}).wait(1).to({graphics:mask_graphics_12,x:478.4,y:162.8}).wait(1).to({graphics:mask_graphics_13,x:478.4,y:164.8}).wait(1).to({graphics:mask_graphics_14,x:478.4,y:166.8}).wait(1).to({graphics:mask_graphics_15,x:478.4,y:168.7}).wait(1).to({graphics:mask_graphics_16,x:478.4,y:170.7}).wait(1).to({graphics:mask_graphics_17,x:478.4,y:172.7}).wait(1).to({graphics:mask_graphics_18,x:478.4,y:174.7}).wait(1).to({graphics:mask_graphics_19,x:478.4,y:176.7}).wait(1).to({graphics:mask_graphics_20,x:478.4,y:178.6}).wait(1).to({graphics:mask_graphics_21,x:478.4,y:180.6}).wait(1).to({graphics:mask_graphics_22,x:478.4,y:182.6}).wait(1).to({graphics:mask_graphics_23,x:478.4,y:184.6}).wait(1).to({graphics:mask_graphics_24,x:478.4,y:186.5}).wait(1).to({graphics:mask_graphics_25,x:478.4,y:188.5}).wait(1).to({graphics:mask_graphics_26,x:478.4,y:190.5}).wait(1).to({graphics:mask_graphics_27,x:478.4,y:192.5}).wait(1).to({graphics:mask_graphics_28,x:478.4,y:194.4}).wait(1).to({graphics:mask_graphics_29,x:478.4,y:196.4}).wait(1).to({graphics:mask_graphics_30,x:478.4,y:198.4}).wait(1).to({graphics:mask_graphics_31,x:478.4,y:200.4}).wait(1).to({graphics:mask_graphics_32,x:478.4,y:202.4}).wait(1).to({graphics:mask_graphics_33,x:478.4,y:204.3}).wait(1).to({graphics:mask_graphics_34,x:478.4,y:206.3}).wait(1).to({graphics:mask_graphics_35,x:478.4,y:208.3}).wait(1).to({graphics:mask_graphics_36,x:478.4,y:210.3}).wait(1).to({graphics:mask_graphics_37,x:478.4,y:212.2}).wait(1).to({graphics:mask_graphics_38,x:478.4,y:214.2}).wait(1).to({graphics:mask_graphics_39,x:478.4,y:216.2}).wait(1).to({graphics:mask_graphics_40,x:478.4,y:218.2}).wait(1).to({graphics:mask_graphics_41,x:478.4,y:220.2}).wait(1).to({graphics:mask_graphics_42,x:478.4,y:222.1}).wait(1).to({graphics:mask_graphics_43,x:478.4,y:224.1}).wait(1).to({graphics:mask_graphics_44,x:478.4,y:226.1}).wait(1).to({graphics:mask_graphics_45,x:478.4,y:228.1}).wait(1).to({graphics:mask_graphics_46,x:478.4,y:230}).wait(1).to({graphics:mask_graphics_47,x:478.4,y:232}).wait(1).to({graphics:mask_graphics_48,x:478.4,y:234}).wait(1).to({graphics:mask_graphics_49,x:478.4,y:236}).wait(1).to({graphics:mask_graphics_50,x:478.4,y:238}).wait(1).to({graphics:mask_graphics_51,x:478.4,y:239.9}).wait(1).to({graphics:mask_graphics_52,x:478.4,y:241.9}).wait(1).to({graphics:mask_graphics_53,x:478.4,y:243.9}).wait(1).to({graphics:mask_graphics_54,x:478.4,y:245.9}).wait(1).to({graphics:mask_graphics_55,x:478.4,y:247.8}).wait(1).to({graphics:mask_graphics_56,x:478.4,y:249.8}).wait(1).to({graphics:mask_graphics_57,x:478.4,y:251.8}).wait(1).to({graphics:mask_graphics_58,x:478.4,y:253.8}).wait(1).to({graphics:mask_graphics_59,x:478.4,y:255.8}).wait(1).to({graphics:mask_graphics_60,x:478.4,y:257.7}).wait(1).to({graphics:mask_graphics_61,x:478.4,y:259.7}).wait(1).to({graphics:mask_graphics_62,x:478.4,y:261.7}).wait(1).to({graphics:mask_graphics_63,x:478.4,y:263.7}).wait(1).to({graphics:mask_graphics_64,x:478.4,y:265.6}).wait(1).to({graphics:mask_graphics_65,x:478.4,y:267.6}).wait(1).to({graphics:mask_graphics_66,x:478.4,y:269.6}).wait(1).to({graphics:mask_graphics_67,x:478.4,y:271.6}).wait(1).to({graphics:mask_graphics_68,x:478.4,y:273.6}).wait(1).to({graphics:mask_graphics_69,x:478.4,y:275.5}).wait(1).to({graphics:mask_graphics_70,x:478.4,y:277.5}).wait(1).to({graphics:mask_graphics_71,x:478.4,y:279.5}).wait(1).to({graphics:mask_graphics_72,x:478.4,y:281.5}).wait(1).to({graphics:mask_graphics_73,x:478.4,y:283.4}).wait(1).to({graphics:mask_graphics_74,x:478.4,y:285.4}).wait(1).to({graphics:mask_graphics_75,x:478.4,y:287.4}).wait(1).to({graphics:mask_graphics_76,x:478.4,y:289.4}).wait(1).to({graphics:mask_graphics_77,x:478.4,y:291.4}).wait(1).to({graphics:mask_graphics_78,x:478.4,y:293.3}).wait(1).to({graphics:mask_graphics_79,x:478.4,y:295.3}).wait(1).to({graphics:mask_graphics_80,x:478.4,y:297.3}).wait(1).to({graphics:mask_graphics_81,x:478.4,y:299.3}).wait(1).to({graphics:mask_graphics_82,x:478.4,y:301.2}).wait(1).to({graphics:mask_graphics_83,x:478.4,y:303.2}).wait(1).to({graphics:mask_graphics_84,x:478.4,y:305.2}).wait(1).to({graphics:mask_graphics_85,x:478.4,y:307.2}).wait(1).to({graphics:mask_graphics_86,x:478.4,y:309.2}).wait(1).to({graphics:mask_graphics_87,x:478.4,y:311.1}).wait(1).to({graphics:mask_graphics_88,x:478.4,y:313.1}).wait(1).to({graphics:mask_graphics_89,x:478.4,y:315.1}).wait(1).to({graphics:mask_graphics_90,x:478.4,y:317.1}).wait(1).to({graphics:mask_graphics_91,x:478.4,y:319}).wait(1).to({graphics:mask_graphics_92,x:478.4,y:321}).wait(1).to({graphics:mask_graphics_93,x:478.4,y:323}).wait(1).to({graphics:mask_graphics_94,x:433.2,y:259.3}).wait(1));

	// Capa 6
	this.info8_04 = new cjs.Text("O Impersonal eventual", "17px Verdana", "#243186");
	this.info8_04.textAlign = "center";
	this.info8_04.lineHeight = 19;
	this.info8_04.lineWidth = 209;
	this.info8_04.setTransform(631,478.3);


	this.text = new cjs.Text("SN", "17px Verdana", "#7E117D");
	this.text.textAlign = "center";
	this.text.lineHeight = 19;
	this.text.lineWidth = 31;
	this.text.setTransform(838.4,297.2);

	this.textb = new cjs.Text("\nCD", "17px Verdana", "#243186");
	this.textb.textAlign = "center";
	this.textb.lineHeight = 19;
	this.textb.lineWidth = 31;
	this.textb.setTransform(838.4,297.2);

    this.text_1 = new cjs.Text("SN\n", "17px Verdana", "#7E117D");
	this.text_1.lineHeight = 19;
	this.text_1.lineWidth = 110;
	this.text_1.setTransform(703.1,334.8);
    this.text_1b = new cjs.Text("\nO Sub Sust", "17px Verdana", "#243186");
	this.text_1b.lineHeight = 19;
	this.text_1b.lineWidth = 110;
	this.text_1b.setTransform(703.1,334.8);

	this.info8_03 = new cjs.Text("SV", "17px Verdana", "#7E117D");
	this.info8_03.lineHeight = 19;
	this.info8_03.lineWidth = 172;
	this.info8_03.setTransform(640.8,397.1);
	this.info8_03b = new cjs.Text("\nPredicado", "17px Verdana", "#243186");
	this.info8_03b.lineHeight = 19;
	this.info8_03b.lineWidth = 172;
	this.info8_03b.setTransform(640.8,397.1);

	this.text_2 = new cjs.Text("Ø", "17px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 19;
	this.text_2.lineWidth = 17;
	this.text_2.setTransform(203.2,274.6);

	this.text_3 = new cjs.Text("Esp", "17px Verdana", "#243186");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 19;
	this.text_3.lineWidth = 37;
	this.text_3.setTransform(417.1,299.1);

	this.text_4 = new cjs.Text("CC", "17px Verdana", "#7E117D");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 19;
	this.text_4.lineWidth = 93;
	this.text_4.setTransform(396.2,434.2);
this.text_4b = new cjs.Text("\nO Sub Adv", "17px Verdana", "#243186");
	this.text_4b.textAlign = "center";
	this.text_4b.lineHeight = 19;
	this.text_4b.lineWidth = 93;
	this.text_4b.setTransform(396.2,434.2);
	this.info8_02 = new cjs.Text("SN", "17px Verdana", "#7E117D");
	this.info8_02.lineHeight = 19;
	this.info8_02.lineWidth = 93;
	this.info8_02.setTransform(493.2,353);
	this.info8_02b = new cjs.Text("\nSujeto", "17px Verdana", "#243186");
	this.info8_02b.lineHeight = 19;
	this.info8_02b.lineWidth = 93;
	this.info8_02b.setTransform(493.2,353);

	this.info8_01 = new cjs.Text("SV", "17px Verdana", "#7E117D");
	this.info8_01.textAlign = "right";
	this.info8_01.lineHeight = 19;
	this.info8_01.lineWidth = 93;
	this.info8_01.setTransform(301.9,353);
this.info8_01b = new cjs.Text("\nPredicado", "17px Verdana", "#243186");
	this.info8_01b.textAlign = "right";
	this.info8_01b.lineHeight = 19;
	this.info8_01b.lineWidth = 93;
	this.info8_01b.setTransform(301.9,353);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#334BEF").ss(6,2,1).p("AyGAAMAkNAAA");
	this.shape.setTransform(516.8,420.9,0.992,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#334BEF").ss(6,2,1).p("AGrh5ItUDz");
	this.shape_1.setTransform(356.4,407.9,0.952,1,0,0,180);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#334BEF").ss(6,2,1).p("AGrh5ItUDz");
	this.shape_2.setTransform(442,408.1,0.959,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#334BEF").ss(6,2,1).p("ALpAAI3RAA");
	this.shape_3.setTransform(708.6,326.2);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#334BEF").ss(6,2,1).p("AENAAIoZAA");
	this.shape_4.setTransform(812.2,292.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#334BEF").ss(6,2,1).p("Ak9AAIJ7AA");
	this.shape_5.setTransform(449.7,291.9);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#334BEF").ss(6,2,1).p("AuTAAIcnAA");
	this.shape_6.setTransform(223.2,326.2,0.993,1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#334BEF").ss(6,2,1).p("An3AAIPuAA");
	this.shape_7.setTransform(264.6,289.8);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#334BEF").ss(6,2,1).p("AAAm0IAANp");
	this.shape_8.setTransform(632.7,353.3,1,2.654);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#334BEF").ss(6,2,1).p("AAAm0IAANp");
	this.shape_9.setTransform(214.2,262.1,1,0.626);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#334BEF").ss(6,2,1).p("AAAm0IAANp");
	this.shape_10.setTransform(417.8,262.1,1,0.626);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f().s("#334BEF").ss(6,2,1).p("AAAm0IAANp");
	this.shape_11.setTransform(483.6,314.8,1,1.831);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#334BEF").ss(6,2,1).p("AAAm0IAANp");
	this.shape_12.setTransform(839.2,262.1,1,0.626);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f().s("#334BEF").ss(6,2,1).p("AAAm0IAANp");
	this.shape_13.setTransform(783.2,279.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#334BEF").ss(6,2,1).p("AAAm0IAANp");
	this.shape_14.setTransform(315,314.8,1,1.83);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#334BEF").ss(6,2,1).p("AAAm0IAANp");
	this.shape_15.setTransform(132.3,279.6);

	this.text_5 = new cjs.Text("Pron", "17px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 19;
	this.text_5.lineWidth = 40;
	this.text_5.setTransform(835,195.3);

	this.text_6 = new cjs.Text("V", "17px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 19;
	this.text_6.lineWidth = 74;
	this.text_6.setTransform(779.8,195.3);

	this.text_7 = new cjs.Text("SAdv", "17px Verdana", "#7E117D");
	this.text_7.lineHeight = 19;
	this.text_7.lineWidth = 51;
	this.text_7.setTransform(106,343.4);


this.text_7b = new cjs.Text("\nCC", "17px Verdana", "#243186");
	this.text_7b.lineHeight = 19;
	this.text_7b.lineWidth = 51;
	this.text_7b.setTransform(106,343.4);

	this.text_8 = new cjs.Text("V", "17px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 19;
	this.text_8.lineWidth = 141;
	this.text_8.setTransform(630.3,195.3);

	this.text_9 = new cjs.Text("Adv", "17px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 19;
	this.text_9.lineWidth = 40;
	this.text_9.setTransform(130.5,195.3);

	this.text_10 = new cjs.Text("V", "17px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 19;
	this.text_10.lineWidth = 124;
	this.text_10.setTransform(314,195.3);

	this.text_11 = new cjs.Text("Pron", "17px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 19;
	this.text_11.lineWidth = 40;
	this.text_11.setTransform(210,195.3);

	this.text_12 = new cjs.Text("N", "17px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 19;
	this.text_12.lineWidth = 53;
	this.text_12.setTransform(480.9,195.3);

	this.text_13 = new cjs.Text("Det", "17px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 19;
	this.text_13.lineWidth = 31;
	this.text_13.setTransform(415.8,195.3);

	
	

	this.info8_04.mask = this.textb.mask=this.text.mask = this.text_1.mask = this.info8_03.mask = this.text_2.mask = this.text_3.mask = this.text_4.mask = this.info8_02.mask = this.info8_01.mask = this.shape.mask = this.shape_1.mask = this.shape_2.mask = this.shape_3.mask = this.shape_4.mask = this.shape_5.mask = this.shape_6.mask = this.shape_7.mask = this.shape_8.mask = this.shape_9.mask = this.shape_10.mask = this.shape_11.mask = this.shape_12.mask = this.shape_13.mask = this.shape_14.mask = this.shape_15.mask = this.text_5.mask = this.text_6.mask = this.text_7.mask= this.text_7b.mask =  this.text_8.mask=this.text_1b.mask = this.text_9.mask = this.text_10.mask = this.text_11.mask = this.text_12.mask = this.text_13.mask=this.info8_03b.mask=this.info8_01b.mask=this.info8_02b.mask=this.text_4b.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_13},{t:this.text_12},{t:this.text_11},{t:this.text_10},{t:this.text_9},{t:this.text_8},{t:this.text_7},{t:this.text_7b},{t:this.text_6},{t:this.text_5},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.info8_01b},{t:this.info8_02b},{t:this.info8_01},{t:this.info8_02},{t:this.text_4},{t:this.text_4b},{t:this.text_3},{t:this.text_2},{t:this.info8_03},{t:this.info8_03b},{t:this.textb},{t:this.text_1},{t:this.text_1b},{t:this.text},{t:this.info8_04}]}).wait(95));

	// Blanco
	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("Eg8mABNIAAiZMB5NAAAIAACZg");
	this.shape_24.setTransform(478.4,139.1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("Eg8mABhIAAjBMB5NAAAIAADBg");
	this.shape_25.setTransform(478.4,141.1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("Eg8mAB0IAAjnMB5NAAAIAADng");
	this.shape_26.setTransform(478.4,143);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("Eg8mACIIAAkPMB5NAAAIAAEPg");
	this.shape_27.setTransform(478.4,145);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("Eg8mACcIAAk3MB5NAAAIAAE3g");
	this.shape_28.setTransform(478.4,147);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("Eg8mACwIAAlfMB5NAAAIAAFfg");
	this.shape_29.setTransform(478.4,149);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("Eg8mADDIAAmFMB5NAAAIAAGFg");
	this.shape_30.setTransform(478.4,150.9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("Eg8mADXIAAmtMB5NAAAIAAGtg");
	this.shape_31.setTransform(478.4,152.9);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("Eg8mADrIAAnVMB5NAAAIAAHVg");
	this.shape_32.setTransform(478.4,154.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("Eg8mAD/IAAn9MB5NAAAIAAH9g");
	this.shape_33.setTransform(478.4,156.9);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("Eg8mAETIAAolMB5NAAAIAAIlg");
	this.shape_34.setTransform(478.4,158.9);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("Eg8mAEmIAApLMB5NAAAIAAJLg");
	this.shape_35.setTransform(478.4,160.8);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("Eg8mAE6IAApzMB5NAAAIAAJzg");
	this.shape_36.setTransform(478.4,162.8);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("Eg8mAFOIAAqbMB5NAAAIAAKbg");
	this.shape_37.setTransform(478.4,164.8);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("Eg8mAFiIAArDMB5NAAAIAALDg");
	this.shape_38.setTransform(478.4,166.8);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("Eg8mAF1IAArpMB5NAAAIAALpg");
	this.shape_39.setTransform(478.4,168.7);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("Eg8mAGJIAAsRMB5NAAAIAAMRg");
	this.shape_40.setTransform(478.4,170.7);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("Eg8mAGdIAAs5MB5NAAAIAAM5g");
	this.shape_41.setTransform(478.4,172.7);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("Eg8mAGxIAAthMB5NAAAIAANhg");
	this.shape_42.setTransform(478.4,174.7);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("Eg8mAHFIAAuJMB5NAAAIAAOJg");
	this.shape_43.setTransform(478.4,176.7);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("Eg8mAHYIAAuvMB5NAAAIAAOvg");
	this.shape_44.setTransform(478.4,178.6);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("Eg8mAHsIAAvXMB5NAAAIAAPXg");
	this.shape_45.setTransform(478.4,180.6);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("Eg8mAIAIAAv/MB5NAAAIAAP/g");
	this.shape_46.setTransform(478.4,182.6);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("Eg8mAIUIAAwnMB5NAAAIAAQng");
	this.shape_47.setTransform(478.4,184.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("Eg8mAInIAAxNMB5NAAAIAARNg");
	this.shape_48.setTransform(478.4,186.5);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("Eg8mAI7IAAx1MB5NAAAIAAR1g");
	this.shape_49.setTransform(478.4,188.5);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("Eg8mAJPIAAydMB5NAAAIAASdg");
	this.shape_50.setTransform(478.4,190.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("Eg8mAJjIAAzFMB5NAAAIAATFg");
	this.shape_51.setTransform(478.4,192.5);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("Eg8mAJ2IAAzrMB5NAAAIAATrg");
	this.shape_52.setTransform(478.4,194.4);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("Eg8mAKKIAA0TMB5NAAAIAAUTg");
	this.shape_53.setTransform(478.4,196.4);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("Eg8mAKeIAA07MB5NAAAIAAU7g");
	this.shape_54.setTransform(478.4,198.4);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("Eg8mAKyIAA1jMB5NAAAIAAVjg");
	this.shape_55.setTransform(478.4,200.4);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("Eg8mALGIAA2LMB5NAAAIAAWLg");
	this.shape_56.setTransform(478.4,202.4);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#FFFFFF").s().p("Eg8mALZIAA2xMB5NAAAIAAWxg");
	this.shape_57.setTransform(478.4,204.3);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#FFFFFF").s().p("Eg8mALtIAA3ZMB5NAAAIAAXZg");
	this.shape_58.setTransform(478.4,206.3);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#FFFFFF").s().p("Eg8mAMBIAA4BMB5NAAAIAAYBg");
	this.shape_59.setTransform(478.4,208.3);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#FFFFFF").s().p("Eg8mAMVIAA4pMB5NAAAIAAYpg");
	this.shape_60.setTransform(478.4,210.3);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#FFFFFF").s().p("Eg8mAMoIAA5PMB5NAAAIAAZPg");
	this.shape_61.setTransform(478.4,212.2);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#FFFFFF").s().p("Eg8mAM8IAA53MB5NAAAIAAZ3g");
	this.shape_62.setTransform(478.4,214.2);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#FFFFFF").s().p("Eg8mANQIAA6fMB5NAAAIAAafg");
	this.shape_63.setTransform(478.4,216.2);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#FFFFFF").s().p("Eg8mANkIAA7HMB5NAAAIAAbHg");
	this.shape_64.setTransform(478.4,218.2);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#FFFFFF").s().p("Eg8mAN4IAA7vMB5NAAAIAAbvg");
	this.shape_65.setTransform(478.4,220.2);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#FFFFFF").s().p("Eg8mAOLIAA8VMB5NAAAIAAcVg");
	this.shape_66.setTransform(478.4,222.1);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#FFFFFF").s().p("Eg8mAOfIAA89MB5NAAAIAAc9g");
	this.shape_67.setTransform(478.4,224.1);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#FFFFFF").s().p("Eg8mAOzIAA9lMB5NAAAIAAdlg");
	this.shape_68.setTransform(478.4,226.1);

	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("Eg8mAPHIAA+NMB5NAAAIAAeNg");
	this.shape_69.setTransform(478.4,228.1);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#FFFFFF").s().p("Eg8mAPaIAA+zMB5NAAAIAAezg");
	this.shape_70.setTransform(478.4,230);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("Eg8mAPuIAA/bMB5NAAAIAAfbg");
	this.shape_71.setTransform(478.4,232);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#FFFFFF").s().p("Eg8mAQCMAAAggDMB5NAAAMAAAAgDg");
	this.shape_72.setTransform(478.4,234);

	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("Eg8mAQWMAAAggrMB5NAAAMAAAAgrg");
	this.shape_73.setTransform(478.4,236);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#FFFFFF").s().p("Eg8mAQqMAAAghTMB5NAAAMAAAAhTg");
	this.shape_74.setTransform(478.4,238);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("Eg8mAQ9MAAAgh5MB5NAAAMAAAAh5g");
	this.shape_75.setTransform(478.4,239.9);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("Eg8mARRMAAAgihMB5NAAAMAAAAihg");
	this.shape_76.setTransform(478.4,241.9);

	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#FFFFFF").s().p("Eg8mARlMAAAgjJMB5NAAAMAAAAjJg");
	this.shape_77.setTransform(478.4,243.9);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#FFFFFF").s().p("Eg8mAR5MAAAgjxMB5NAAAMAAAAjxg");
	this.shape_78.setTransform(478.4,245.9);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#FFFFFF").s().p("Eg8mASMMAAAgkXMB5NAAAMAAAAkXg");
	this.shape_79.setTransform(478.4,247.8);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#FFFFFF").s().p("Eg8mASgMAAAgk/MB5NAAAMAAAAk/g");
	this.shape_80.setTransform(478.4,249.8);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#FFFFFF").s().p("Eg8mAS0MAAAglnMB5NAAAMAAAAlng");
	this.shape_81.setTransform(478.4,251.8);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#FFFFFF").s().p("Eg8mATIMAAAgmPMB5NAAAMAAAAmPg");
	this.shape_82.setTransform(478.4,253.8);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#FFFFFF").s().p("Eg8mATcMAAAgm3MB5NAAAMAAAAm3g");
	this.shape_83.setTransform(478.4,255.8);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#FFFFFF").s().p("Eg8mATvMAAAgndMB5NAAAMAAAAndg");
	this.shape_84.setTransform(478.4,257.7);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#FFFFFF").s().p("Eg8mAUDMAAAgoFMB5NAAAMAAAAoFg");
	this.shape_85.setTransform(478.4,259.7);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#FFFFFF").s().p("Eg8mAUXMAAAgotMB5NAAAMAAAAotg");
	this.shape_86.setTransform(478.4,261.7);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#FFFFFF").s().p("Eg8mAUrMAAAgpVMB5NAAAMAAAApVg");
	this.shape_87.setTransform(478.4,263.7);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#FFFFFF").s().p("Eg8mAU+MAAAgp7MB5NAAAMAAAAp7g");
	this.shape_88.setTransform(478.4,265.6);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#FFFFFF").s().p("Eg8mAVSMAAAgqjMB5NAAAMAAAAqjg");
	this.shape_89.setTransform(478.4,267.6);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#FFFFFF").s().p("Eg8mAVmMAAAgrLMB5NAAAMAAAArLg");
	this.shape_90.setTransform(478.4,269.6);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#FFFFFF").s().p("Eg8mAV6MAAAgrzMB5NAAAMAAAArzg");
	this.shape_91.setTransform(478.4,271.6);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#FFFFFF").s().p("Eg8mAWOMAAAgsbMB5NAAAMAAAAsbg");
	this.shape_92.setTransform(478.4,273.6);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#FFFFFF").s().p("Eg8mAWhMAAAgtBMB5NAAAMAAAAtBg");
	this.shape_93.setTransform(478.4,275.5);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#FFFFFF").s().p("Eg8mAW1MAAAgtpMB5NAAAMAAAAtpg");
	this.shape_94.setTransform(478.4,277.5);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#FFFFFF").s().p("Eg8mAXJMAAAguRMB5NAAAMAAAAuRg");
	this.shape_95.setTransform(478.4,279.5);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f("#FFFFFF").s().p("Eg8mAXdMAAAgu5MB5NAAAMAAAAu5g");
	this.shape_96.setTransform(478.4,281.5);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("Eg8mAXwMAAAgvfMB5NAAAMAAAAvfg");
	this.shape_97.setTransform(478.4,283.4);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#FFFFFF").s().p("Eg8mAYEMAAAgwHMB5NAAAMAAAAwHg");
	this.shape_98.setTransform(478.4,285.4);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#FFFFFF").s().p("Eg8mAYYMAAAgwvMB5NAAAMAAAAwvg");
	this.shape_99.setTransform(478.4,287.4);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#FFFFFF").s().p("Eg8mAYsMAAAgxXMB5NAAAMAAAAxXg");
	this.shape_100.setTransform(478.4,289.4);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#FFFFFF").s().p("Eg8mAZAMAAAgx/MB5NAAAMAAAAx/g");
	this.shape_101.setTransform(478.4,291.4);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#FFFFFF").s().p("Eg8mAZTMAAAgylMB5NAAAMAAAAylg");
	this.shape_102.setTransform(478.4,293.3);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#FFFFFF").s().p("Eg8mAZnMAAAgzNMB5NAAAMAAAAzNg");
	this.shape_103.setTransform(478.4,295.3);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#FFFFFF").s().p("Eg8mAZ7MAAAgz1MB5NAAAMAAAAz1g");
	this.shape_104.setTransform(478.4,297.3);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#FFFFFF").s().p("Eg8mAaPMAAAg0dMB5NAAAMAAAA0dg");
	this.shape_105.setTransform(478.4,299.3);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#FFFFFF").s().p("Eg8mAaiMAAAg1DMB5NAAAMAAAA1Dg");
	this.shape_106.setTransform(478.4,301.2);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#FFFFFF").s().p("Eg8mAa2MAAAg1rMB5NAAAMAAAA1rg");
	this.shape_107.setTransform(478.4,303.2);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#FFFFFF").s().p("Eg8mAbKMAAAg2TMB5NAAAMAAAA2Tg");
	this.shape_108.setTransform(478.4,305.2);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#FFFFFF").s().p("Eg8mAbeMAAAg27MB5NAAAMAAAA27g");
	this.shape_109.setTransform(478.4,307.2);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#FFFFFF").s().p("Eg8mAbyMAAAg3jMB5NAAAMAAAA3jg");
	this.shape_110.setTransform(478.4,309.2);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#FFFFFF").s().p("Eg8mAcFMAAAg4JMB5NAAAMAAAA4Jg");
	this.shape_111.setTransform(478.4,311.1);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#FFFFFF").s().p("Eg8mAcZMAAAg4xMB5NAAAMAAAA4xg");
	this.shape_112.setTransform(478.4,313.1);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#FFFFFF").s().p("Eg8mActMAAAg5ZMB5NAAAMAAAA5Zg");
	this.shape_113.setTransform(478.4,315.1);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#FFFFFF").s().p("Eg8mAdBMAAAg6BMB5NAAAMAAAA6Bg");
	this.shape_114.setTransform(478.4,317.1);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#FFFFFF").s().p("Eg8mAdUMAAAg6nMB5NAAAMAAAA6ng");
	this.shape_115.setTransform(478.4,319);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#FFFFFF").s().p("Eg8mAdoMAAAg7PMB5NAAAMAAAA7Pg");
	this.shape_116.setTransform(478.4,321);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#FFFFFF").s().p("Eg8mAd8MAAAg73MB5NAAAMAAAA73g");
	this.shape_117.setTransform(478.4,323);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#FFFFFF").s().p("Eg8mAa7MAAAg11MB5NAAAMAAAA11g");
	this.shape_118.setTransform(478.4,324.5,1,1.123,0,0,0,0,-0.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24}]}).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[{t:this.shape_29}]},1).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[{t:this.shape_40}]},1).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[{t:this.shape_49}]},1).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[{t:this.shape_60}]},1).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[{t:this.shape_69}]},1).to({state:[{t:this.shape_70}]},1).to({state:[{t:this.shape_71}]},1).to({state:[{t:this.shape_72}]},1).to({state:[{t:this.shape_73}]},1).to({state:[{t:this.shape_74}]},1).to({state:[{t:this.shape_75}]},1).to({state:[{t:this.shape_76}]},1).to({state:[{t:this.shape_77}]},1).to({state:[{t:this.shape_78}]},1).to({state:[{t:this.shape_79}]},1).to({state:[{t:this.shape_80}]},1).to({state:[{t:this.shape_81}]},1).to({state:[{t:this.shape_82}]},1).to({state:[{t:this.shape_83}]},1).to({state:[{t:this.shape_84}]},1).to({state:[{t:this.shape_85}]},1).to({state:[{t:this.shape_86}]},1).to({state:[{t:this.shape_87}]},1).to({state:[{t:this.shape_88}]},1).to({state:[{t:this.shape_89}]},1).to({state:[{t:this.shape_90}]},1).to({state:[{t:this.shape_91}]},1).to({state:[{t:this.shape_92}]},1).to({state:[{t:this.shape_93}]},1).to({state:[{t:this.shape_94}]},1).to({state:[{t:this.shape_95}]},1).to({state:[{t:this.shape_96}]},1).to({state:[{t:this.shape_97}]},1).to({state:[{t:this.shape_98}]},1).to({state:[{t:this.shape_99}]},1).to({state:[{t:this.shape_100}]},1).to({state:[{t:this.shape_101}]},1).to({state:[{t:this.shape_102}]},1).to({state:[{t:this.shape_103}]},1).to({state:[{t:this.shape_104}]},1).to({state:[{t:this.shape_105}]},1).to({state:[{t:this.shape_106}]},1).to({state:[{t:this.shape_107}]},1).to({state:[{t:this.shape_108}]},1).to({state:[{t:this.shape_109}]},1).to({state:[{t:this.shape_110}]},1).to({state:[{t:this.shape_111}]},1).to({state:[{t:this.shape_112}]},1).to({state:[{t:this.shape_113}]},1).to({state:[{t:this.shape_114}]},1).to({state:[{t:this.shape_115}]},1).to({state:[{t:this.shape_116}]},1).to({state:[{t:this.shape_117}]},1).to({state:[{t:this.shape_118}]},1).wait(10000));

	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);
(lib.mc_pastillaBlanca = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Eg9mAGgIAAs/MB7NAAAIAAM/g");
	this.shape.setTransform(394.4,41.7);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,788.8,83.3);



    (lib.Icona_ok = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#0B6635", "#95C030"], [0, 1], 34.5, 77.7, -16.7, -68.8).s().p("ApNImQhWg8hWgzIhFgnIg/kOIAKAAQCVAUD6CeQB9BPBfBLQAhogGXnoQCAiZCWiAQBLhBAyghIE7E3QpsF1kSKEQhVDKgpDNQgVBmgDA+QiljQkSjAg");
        this.shape.setTransform(97.9, 103.7, 0.5, 0.5);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(53.3, 56.2, 89.4, 95.1);


    (lib.Icona_Error = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#F09122", "#DF081F"], [0, 1], 22.6, 52.5, -22, -52.8).s().p("AEVG3IlKlxIjbFxQg1gdgvglQhehKAhglIECkIIjbjkQARhAAZg6QAzh1AmAdIDYFRIEWkqIBGAlQBBArgbAfIkXEXIF/EWQgbA4gjAxQg0BLghAAQgKAAgJgIg");
        this.shape.setTransform(102.6, 102.6, 1, 1, 0, 0, 0, 0.8, -0.3);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(57.5, 58.2, 88.7, 89.5);

    (lib.popup_correcto = function (texto) {
        this.initialize();

        // Capa 1
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(774, 220.3, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });
        this.instance = new lib.Icona_ok();
        this.instance.setTransform(227.7, 269.2, 0.658, 0.658, 0, 0, 0, 101.8, 102.9);
        this.instance.shadow = new cjs.Shadow("rgba(0,0,0,1)", 2, 2, 2);

        var html = createDiv(texto, "Verdana", "20px", '400px', '100px', "20px", "185px", "left");
        this.texto = new cjs.DOMElement(html);
        this.texto.setTransform(300, -365);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-317.75, -91, 635.5, 182, 10);
        this.shape.setTransform(473.9, 297.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(255,255,255,0.694)").s().p("EhEzArZMAAAhWxMCJnAAAMAAABWxg");
        this.shape_1.setTransform(475, 304, 1.078, 1.094);

        this.addChild(this.shape_1, this.shape, this.texto, this.instance, this.btn_salir);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

    (lib.popup_correcto2 = function (texto) {
        this.initialize();

        // Capa 1
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(869.4, 220.3, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });
        this.instance = new lib.Icona_ok();
        this.instance.setTransform(126.9, 269.2, 0.658, 0.658, 0, 0, 0, 101.8, 102.9);
        this.instance.shadow = new cjs.Shadow("rgba(0,0,0,1)", 2, 2, 2);
     
        /*this.text = new cjs.Text("Nexo", "18px Verdana", "#EF542E");
        this.text.textAlign = "left";
        this.text.lineHeight = 22;
        this.text.lineWidth = 61;
        this.text.setTransform(660, 325);

        this.text_1 = new cjs.Text("O2", "18px Verdana", "#EF542E");
        this.text_1.lineHeight = 22;
        this.text_1.lineWidth = 37;
        this.text_1.setTransform(750, 325);

        this.text_2 = new cjs.Text("O1", "18px Verdana", "#EF542E");
        this.text_2.lineHeight = 22;
        this.text_2.lineWidth = 26;
        this.text_2.setTransform(400, 325);*/

    
        var html = createDiv(texto, "Verdana", "18px", '820px', '100px', "20px", "185px", "left");
        this.texto = new cjs.DOMElement(html);
        this.texto.setTransform(180, -365);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-317.75, -91, 635.5, 182, 10);
        this.shape.setTransform(473.9, 297.5, 1.3);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(255,255,255,0.694)").s().p("EhEzArZMAAAhWxMCJnAAAMAAABWxg");
        this.shape_1.setTransform(475, 304, 1.078, 1.094);

        this.addChild(this.shape_1, this.shape, this.text_2, this.texto,this.text_1, this.instance, this.btn_salir, this.shape_2, this.shape_1b, this.text, this.shape3);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

    (lib.popup_correcto3_1 = function (texto) {
        this.initialize();

        // Capa 1
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(796.3, 207.4, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });


      /*this.text = new cjs.Text("O2", "20px Verdana", "#2C8BB0");
        this.text.lineHeight = 22;
        this.text.setTransform(607.8, 337.9);

        this.text_1 = new cjs.Text("O1", "20px Verdana", "#2C8BB0");
        this.text_1.lineHeight = 22;
        this.text_1.setTransform(307.6, 337.9);

        this.shape3 = new cjs.Shape();
        this.shape3.graphics.f().s("#2C8BB0").ss(2, 1, 1).p("A18AAMAr5AAA");
        this.shape3.setTransform(615.1, 330, 1.05, 1);

        this.shape_1b = new cjs.Shape();
        this.shape_1b.graphics.f().s("#2C8BB0").ss(2, 1, 1).p("A18AAMAr5AAA");
        this.shape_1b.setTransform(320.9, 330);*/

        var html = createDiv(texto, "Verdana", "20px", '620px', '100px', "20px", "185px", "left");
        this.texto = new cjs.DOMElement(html);
        this.texto.setTransform(180, -395);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-317.75, -91, 635.5, 182, 10);
        this.shape.setTransform(473.9, 307.5, 1.1, 1.3);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(255,255,255,0.694)").s().p("EhEzArZMAAAhWxMCJnAAAMAAABWxg");
        this.shape_1.setTransform(475, 304, 1.078, 1.094);

        this.addChild(this.shape_1, this.shape, this.texto, this.instance, this.btn_salir, this.shape_1b, this.text_1, this.text, this.shape3);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

    (lib.popup_correcto3_2 = function (texto) {
        this.initialize();

        // Capa 1
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(796.3, 207.4, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });
       /* this.text = new cjs.Text("O2", "20px Verdana", "#208E5E");
        this.text.lineHeight = 22;
        this.text.setTransform(561.9, 359);

        this.text_1 = new cjs.Text("O1", "20px Verdana", "#208E5E");
        this.text_1.lineHeight = 22;
        this.text_1.setTransform(285, 359);

        this.shape3 = new cjs.Shape();
        this.shape3.graphics.f().s("#208E5E").ss(2, 1, 1).p("A18AAMAr5AAA");
        this.shape3.setTransform(583.5, 351.1, 1.155, 1);

        this.shape_1b = new cjs.Shape();
        this.shape_1b.graphics.f().s("#208E5E").ss(2, 1, 1).p("A18AAMAr5AAA");
        this.shape_1b.setTransform(301.1, 351.1, 0.8, 1);*/

        var html = createDiv(texto, "Verdana", "20px", '620px', '100px', "20px", "185px", "left");
        this.texto = new cjs.DOMElement(html);
        this.texto.setTransform(190, -385);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-317.75, -91, 635.5, 182, 10);
        this.shape.setTransform(473.9, 307.5, 1.1, 1.3);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(255,255,255,0.694)").s().p("EhEzArZMAAAhWxMCJnAAAMAAABWxg");
        this.shape_1.setTransform(475, 304, 1.078, 1.094);

        this.addChild(this.shape_1, this.shape, this.texto, this.instance, this.btn_salir, this.shape_1b, this.text_1, this.text, this.shape3);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

(lib.popup_correcto4 = function (texto) {
        this.initialize();

        // Capa 1
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(834.7,212.1,0.8,0.8);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });
 
        var html = createDiv(texto, "Verdana", "20px", '700px', '100px', "20px", "185px", "left");
        this.texto = new cjs.DOMElement(html);
        this.texto.setTransform(150, -385);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-317.75, -91, 635.5, 182, 10);
        this.shape.setTransform(473.9, 297.5,1.2,1.2);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(255,255,255,0.694)").s().p("EhEzArZMAAAhWxMCJnAAAMAAABWxg");
        this.shape_1.setTransform(475, 304, 1.078, 1.094);

        this.addChild(this.shape_1, this.shape, this.texto,  this.btn_salir);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

(lib.popup_correcto5 = function (texto) {
        this.initialize();

        // Capa 1
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(761.7,169.2,0.8,0.8);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });
 
        var html = createDiv(texto, "Verdana", "20px", '700px', '100px', "20px", "185px", "center");
        this.texto = new cjs.DOMElement(html);
        this.texto.setTransform(120, -405);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-317.75, -91, 635.5, 182, 10);
        this.shape.setTransform(473.9, 297.5,1,1.6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(255,255,255,0.694)").s().p("EhEzArZMAAAhWxMCJnAAAMAAABWxg");
        this.shape_1.setTransform(475, 304, 1.078, 1.094);

        this.addChild(this.shape_1, this.shape, this.texto,  this.btn_salir);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

(lib.popup_correcto6_1 = function (texto) {
        this.initialize();

        // Capa 1
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(761.7,169.2,0.8,0.8);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });
    
	this.instance = new lib.Icona_ok();
	this.instance.setTransform(227,200,0.658,0.658,0,0,0,101.8,102.9);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,1)",2,2,2);
        var html = createDiv(texto, "Verdana", "20px", '700px', '100px', "20px", "185px", "left");
        this.texto = new cjs.DOMElement(html);
        this.texto.setTransform(280, -395);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-317.75, -91, 635.5, 182, 10);
        this.shape.setTransform(473.9, 297.5,1,1.6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(255,255,255,0.694)").s().p("EhEzArZMAAAhWxMCJnAAAMAAABWxg");
        this.shape_1.setTransform(475, 304, 1.078, 1.094);

        this.addChild(this.shape_1, this.shape, this.texto,this.shape1_1,this.shape1, this.instance,this.btn_salir);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
(lib.popup_correcto6_2 = function (texto) {
        this.initialize();

        // Capa 1
        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(761.7,169.2,0.8,0.8);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });
		/*this.shape1 = new cjs.Shape();
		this.shape1.graphics.f().s("#A03ED7").ss(2,1,1).p("AjeAAIG9AA");
		this.shape1.setTransform(340,380,4.083,1);
	
		this.shape1_1 = new cjs.Shape();
		this.shape1_1.graphics.f().s("#A03ED7").ss(2,1,1).p("AjeAAIG9AA");
		this.shape1_1.setTransform(295,310,1.629,1);*/
	
		this.instance = new lib.Icona_ok();
		this.instance.setTransform(227,200,0.658,0.658,0,0,0,101.8,102.9);
		this.instance.shadow = new cjs.Shadow("rgba(0,0,0,1)",2,2,2);
	
        var html = createDiv(texto, "Verdana", "18px", '950px', '100px', "20px", "185px", "left");
        this.texto = new cjs.DOMElement(html);
        this.texto.setTransform(250, -395);
        
        

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-317.75, -91, 635.5, 182, 10);
        this.shape.setTransform(473.9, 297.5,1,1.6);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(255,255,255,0.694)").s().p("EhEzArZMAAAhWxMCJnAAAMAAABWxg");
        this.shape_1.setTransform(475, 304, 1.078, 1.094);

        this.addChild(this.shape_1, this.shape, this.texto,this.shape1_1,this.shape1, this.instance,this.btn_salir);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

    (lib.popup_incorrecto = function (texto) {
        this.initialize();

        // Capa 3
        this.txt_popup_incorrecto_1_01 = new cjs.Text(texto, "20px Arial");
        this.txt_popup_incorrecto_1_01.textAlign = "left";
        this.txt_popup_incorrecto_1_01.lineHeight = 22;
        this.txt_popup_incorrecto_1_01.lineWidth = 457;
        this.txt_popup_incorrecto_1_01.setTransform(375, 284.2);

        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(690.6, 232.7, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });
        this.instance = new lib.Icona_Error();
        this.instance.setTransform(306.1, 277.4, 0.658, 0.658, 0, 0, 0, 101.8, 102.9);
        this.instance.shadow = new cjs.Shadow("rgba(0,0,0,1)", 2, 2, 2);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-232.6, -101.75, 465.2, 203.5, 10);
        this.shape.setTransform(475.4, 319.7);

        // Capa 1
        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(255,255,255,0.694)").s().p("EhEzArZMAAAhWxMCJnAAAMAAABWxg");
        this.shape_1.setTransform(475, 304, 1.078, 1.094);

        this.addChild(this.shape_1, this.shape, this.instance, this.btn_salir, this.txt_popup_incorrecto_1_01);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

    (lib.btn_incorrecto_1_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("EgiwACvIAAlcMBFhAAAIAAFcg");
        this.shape.setTransform(222.6, 17.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(0,255,255,0.502)").s().p("EgiwACvIAAlcMBFhAAAIAAFcg");
        this.shape_1.setTransform(222.6, 17.5);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 1).to({state: []}, 1).to({state: [{t: this.shape_1}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);

    (lib.Thinkstock_87509919 = function () {
        this.initialize(img.Thinkstock_87509919);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1478, 750);


    (lib.btn_imatge = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.instance = new lib.Thinkstock_87509919();
        this.instance.setTransform(-159.9, 0, 0.5, 0.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("Eg9sAeqMAAAg9TMB7ZAAAMAAAA9Tg");
        this.shape.setTransform(208.8, 187);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}]}).to({state: [{t: this.instance}, {t: this.shape}]}, 1).to({state: [{t: this.instance}]}, 1).to({state: [{t: this.instance}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-159.9, 0, 739, 375);

    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}