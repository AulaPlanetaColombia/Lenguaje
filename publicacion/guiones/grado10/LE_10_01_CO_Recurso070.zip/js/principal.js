(function (lib, img, cjs, txt) {


    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
    
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 0,0,0,0,0);
        titulo1(this, txt['titulo']);
    this.btn_04 = new lib.btn_04();
	this.btn_04.setTransform(704,440.4,1,1,0,0,0,125,92);
	new cjs.ButtonHelper(this.btn_04, 0, 1, 2, false, new lib.btn_04(), 3);

	this.btn_03 = new lib.btn_03();
	this.btn_03.setTransform(297,440.4,1,1,0,0,0,125,92);
	new cjs.ButtonHelper(this.btn_03, 0, 1, 2, false, new lib.btn_03(), 3);

	this.btn_02 = new lib.btn_02();
	this.btn_02.setTransform(704,249.9,1,1,0,0,0,125,92.5);
	new cjs.ButtonHelper(this.btn_02, 0, 1, 2, false, new lib.btn_02(), 3);

	this.btn_01 = new lib.btn_01();
	this.btn_01.setTransform(297,249.9,1,1,0,0,0,125,92.5);
	new cjs.ButtonHelper(this.btn_01, 0, 1, 2, false, new lib.btn_01(), 3);

	this.text = new cjs.Text(txt['txt_selecciona'], "bold 16px Verdana");
	this.text.lineHeight = 18;
	this.text.setTransform(395.6,558+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("A01B6IAAjzMApsAAAIAADzg");
	this.shape.setTransform(500.8,570.3);

        this.btn_01.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.btn_02.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.btn_03.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.btn_04.on("click", function (evt) {
            putStage(new lib.frame4_1());
        });

	this.addChild(this.titulo,this.shape,this.text,this.btn_01,this.btn_02,this.btn_03,this.btn_04,this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
      (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,1,0);
        titulo2(this, txt['titulo1_1']);

	this.instance_1 = new lib.mc_Intro();
	this.instance_1.setTransform(479,327.4,1,1,0,0,0,331.5,60.3);
        
        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info1']);
            this.parent.addChild(this.parent.informacion);
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1_2());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.titulo,this.instance_1,this.informacion,this.siguiente,this.home,this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
     (lib.frame1_2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,1,0);
        titulo2(this, txt['titulo1_1']);

	this.btn_13 = new lib.btn_ampliar();
	this.btn_13.setTransform(662.5,444.2,0.6,0.6);
	new cjs.ButtonHelper(this.btn_13, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text = new cjs.Text("Siglo XIII  \nEl mester de clerecía\n ", "12px Verdana");
	this.text.textAlign = "right";
	this.text.lineHeight = 11;
	this.text.lineWidth = 257;
	this.text.setTransform(645.3,437.5);
  var html = createDiv(txt['hito_alme_4'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(645-230, 437-613);
	this.btn_12 = new lib.btn_ampliar();
	this.btn_12.setTransform(614.3,235,0.6,0.6);
	new cjs.ButtonHelper(this.btn_12, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_1 = new cjs.Text("Siglo XII \nLos cantares de gesta", "12px Verdana");
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 210;
	this.text_1.setTransform(626.5,226.7);
 var html = createDiv(txt['hito_alme_3'], "Verdana", "12px", '190px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(626, 226-613);
	this.btn_11 = new lib.btn_ampliar();
	this.btn_11.setTransform(346.3,427.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_11, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_2 = new cjs.Text("1130 \nLa Escuela de \nTraductores de Toledo", "12px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 11;
	this.text_2.lineWidth = 257;
	this.text_2.setTransform(329.2,420.7);
 var html = createDiv(txt['hito_alme_2'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(329-230, 420-613);
	this.btn_10 = new lib.btn_ampliar();
	this.btn_10.setTransform(248.2,236.4,0.6,0.6);
	new cjs.ButtonHelper(this.btn_10, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_3 = new cjs.Text("Alrededor del siglo  XI \nLas jarchas ", "12px Verdana");
	this.text_3.lineHeight = 14;
	this.text_3.lineWidth = 210;
	this.text_3.setTransform(260.4,228.2);
 var html = createDiv(txt['hito_alme_1'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(260, 228-613);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AAAn8IAAP5");
	this.shape.setTransform(660.8,382.5);
        this.shape = new lib.Mapadebits1();
	this.shape.setTransform(660.9,382.5-50);
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(660.9,330.6,1.046,1,-179.9);
	

	this.shape_2 = new cjs.Shape();
	this.shape_2  = new lib.Mapadebits1();
	this.shape_2.setTransform(614.5,291.6-50);
        this.shape_2 = new lib.Mapadebits1();
	this.shape_2.setTransform(614.5,291.6-50,1,.85);
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(614.9,329.4,1.047,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4  = new lib.Mapadebits1();
  this.shape_4 = new lib.Mapadebits1();
	this.shape_4.setTransform(345.4,362.5-50);
	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_5.setTransform(345.8,306.3,1.046,1,0,-179.9,180);

	this.shape_6 = new cjs.Shape();
	this.shape_6  = new lib.Mapadebits1();
	  this.shape_6 = new lib.Mapadebits1();
this.shape_6.setTransform(246.5,291.5-50,1,.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_7.setTransform(246.9,329.2,1.047,1);


	this.instance_1 = new lib.mc_anonima();
	this.instance_1.setTransform(492.1,329.9,1,1,0,0,0,331.5,60.3);

	 this.btn_10.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_1_1']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_11.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_1_2']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_12.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_1_3'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_13.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_1_4'],1.4);
            this.parent.addChild(this.parent.popup);
        });
        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info1']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1_1());
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1_3());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.titulo,this.siguiente,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_3,this.btn_10,this.text_2,this.btn_11,this.text_1,this.btn_12,this.text,this.btn_13,this.logo,this.anterior,this.informacion,this.home);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

   (lib.frame1_3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,1,0);
        titulo2(this, txt['titulo1_1']);

	this.btn_20 = new lib.btn_ampliar();
	this.btn_20.setTransform(832.8,163,0.6,0.6);
	new cjs.ButtonHelper(this.btn_20, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text = new cjs.Text("Siglo XIV-XVI \nEl romancero viejo", "12px Verdana");
	this.text.textAlign = "right";
	this.text.lineHeight = 11;
	this.text.lineWidth = 257;
	this.text.setTransform(814.7,155.4);
 var html = createDiv(txt['hito_bame_7'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(814-230, 155-613);
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AACllIgDLL");
		  this.shape = new lib.Mapadebits1();
this.shape.setTransform(644.7,265.8-50,1,.85);

	this.btn_18 = new lib.btn_ampliar();
	this.btn_18.setTransform(645,221.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_18, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_1 = new cjs.Text("1330-1335\nEl Conde Lucanor, \ndon Juan Manuel", "12px Verdana");
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 250;
	this.text_1.setTransform(656.4,211.3);
 var html = createDiv(txt['hito_bame_5'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(656, 211-613);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(644.9,304.3,1.047,1);

	this.text_2 = new cjs.Text("Alrededor del 1270 \nGeneral y Gran Historia, Alfonso X el Sabio", "12px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 14;
	this.text_2.lineWidth = 210;
	this.text_2.setTransform(318.8,417.4);
 var html = createDiv(txt['hito_bame_2'], "Verdana", "12px", '190px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(318-190, 417-613);

	this.btn_19 = new lib.btn_ampliar();
	this.btn_19.setTransform(757,450.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_19, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_3 = new cjs.Text("Siglo XIII-XIV \nLas cantigas de amor, \nde amigo y de escarnio  ", "12px Verdana");
	this.text_3.textAlign = "right";
	this.text_3.lineHeight = 11;
	this.text_3.lineWidth = 257;
	this.text_3.setTransform(739.8,443.8);
 var html = createDiv(txt['hito_bame_6'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(739-230, 443-613);

	this.btn_16 = new lib.btn_ampliar();
	this.btn_16.setTransform(429.5,186.4,0.6,0.6);
	new cjs.ButtonHelper(this.btn_16, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_4 = new cjs.Text("Segunda mitad del siglo XII \nAuto de los Reyes Magos, \nanónimo", "12px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 184;
	this.text_4.setTransform(440.8,178.6);
 var html = createDiv(txt['hito_bame_3'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(440, 178-613);

	this.btn_15 = new lib.btn_ampliar();
	this.btn_15.setTransform(333.3,424.8,0.6,0.6);
	new cjs.ButtonHelper(this.btn_15, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_14 = new lib.btn_ampliar();
	this.btn_14.setTransform(162.9,186.4,0.6,0.6);
	new cjs.ButtonHelper(this.btn_14, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_5 = new cjs.Text("Alrededor del 1251 \nCalila y Dimna, anónimo", "12px Verdana");
	this.text_5.lineHeight = 14;
	this.text_5.lineWidth = 210;
	this.text_5.setTransform(175.1,178.6);
 var html = createDiv(txt['hito_bame_1'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_5 = new cjs.DOMElement(html);
    this.text_5.setTransform(175, 178-613);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AAAowIAARh");
	  this.shape_2 = new lib.Mapadebits1();
	this.shape_2.setTransform(161.7,247.6-50);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,1,1).p("AAALlIAA3K");
	  this.shape_3 = new lib.Mapadebits1();
	this.shape_3.setTransform(833,253.5-80,1,1.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_4.setTransform(833.2,328.8,1.046,1);

	this.text_6 = new cjs.Text("1330-1350 \nLibro de Buen Amor, \nJuan Ruiz (Arcipreste de Hita)", "12px Verdana");
	this.text_6.textAlign = "right";
	this.text_6.lineHeight = 14;
	this.text_6.lineWidth = 210;
	this.text_6.setTransform(562.2,418.4);
 var html = createDiv(txt['hito_bame_4'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_6 = new cjs.DOMElement(html);
    this.text_6.setTransform(562-230, 418-613);

	this.btn_17 = new lib.btn_ampliar();
	this.btn_17.setTransform(576.6,425.8,0.6,0.6);
	new cjs.ButtonHelper(this.btn_17, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_5 = new cjs.Shape();
	this.shape_5  = new lib.Mapadebits1();
	  this.shape_5 = new lib.Mapadebits1();
	this.shape_5.setTransform(575.7,361-50);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_6.setTransform(576.1,304.8,1.046,1,0,-179.9,180);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(2,1,1).p("AAAn8IAAP5");
	  this.shape_7 = new lib.Mapadebits1();
	this.shape_7.setTransform(757.3,386.8-50);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_8.setTransform(756.7,329.9,1.046,1,-179.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9  = new lib.Mapadebits1();
	  this.shape_9 = new lib.Mapadebits1();
	this.shape_9.setTransform(428,240.5-50,1,.9);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_10.setTransform(428.4,278.3,1.047,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11  = new lib.Mapadebits1();
	  this.shape_11 = new lib.Mapadebits1();
	this.shape_11.setTransform(332.3,360-50);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_12.setTransform(332.7,303.8,1.046,1,0,-179.9,180);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_13.setTransform(160.8,302.2,1.047,1);

	
	this.instance_1 = new lib.mc_bajamedia();
	this.instance_1.setTransform(479,327.4,1,1,0,0,0,331.5,60.3);

	 this.btn_14.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_2_1']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_15.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_2_2'],1.5);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_16.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_2_3'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_17.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_2_4'],1.4);
            this.parent.addChild(this.parent.popup);
        });

                this.btn_18.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_2_5'],1.4);
            this.parent.addChild(this.parent.popup);
        });

                this.btn_19.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_2_6'],1.6);
            this.parent.addChild(this.parent.popup);
        });

                this.btn_20.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_2_7'],1.4);
            this.parent.addChild(this.parent.popup);
        });

       this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info1']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1_2());
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1_4());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.btn_17,this.text_6,this.shape_4,this.shape_3,this.shape_2,this.text_5,this.btn_14,this.btn_15,this.titulo,this.btn_16,this.text_3,this.text_4,this.btn_19,this.text_2,this.shape_1,this.text_1,this.btn_18,this.shape,this.text,this.btn_20,this.logo,this.home,this.siguiente,this.anterior,this.informacion);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame1_4 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,1,0);
        titulo2(this, txt['titulo1_1']);

	this.btn_25 = new lib.btn_ampliar();
	this.btn_25.setTransform(768.8,188.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_25, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text = new cjs.Text("1492\nGramática de la lengua castellana, Antonio de Nebrija", "12px Verdana");
	this.text.textAlign = "right";
	this.text.lineHeight = 11;
	this.text.lineWidth = 250;
	this.text.setTransform(749.5,181.4);
var html = createDiv(txt['hito_prere_5'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(749-230, 181-613);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(769.7,300.5,1.047,1);

	this.text_1 = new cjs.Text("1456 \nLaberinto de Fortuna, \nJuan de Mena", "12px Verdana");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 210;
	this.text_1.setTransform(267.9,435.6);
var html = createDiv(txt['hito_prere_2'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(267-230, 435-613);

	this.btn_26 = new lib.btn_ampliar();
	this.btn_26.setTransform(860.6,448.6,0.6,0.6);
	new cjs.ButtonHelper(this.btn_26, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_2 = new cjs.Text("1499 \nLa Celestina, \nFernando de Rojas", "12px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 11;
	this.text_2.lineWidth = 257;
	this.text_2.setTransform(840.6,441.9);
var html = createDiv(txt['hito_prere_6'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(840-230, 441-613);

	this.btn_23 = new lib.btn_ampliar();
	this.btn_23.setTransform(336.4,202.7,0.6,0.6);
	new cjs.ButtonHelper(this.btn_23, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_3 = new cjs.Text("1458 \nComedieta de Ponza, marqués de Santillana", "12px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.lineWidth = 184;
	this.text_3.setTransform(348.7,188.4);
var html = createDiv(txt['hito_prere_3'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(348, 188-613);

	this.btn_22 = new lib.btn_ampliar();
	this.btn_22.setTransform(283.4,443,0.6,0.6);
	new cjs.ButtonHelper(this.btn_22, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_21 = new lib.btn_ampliar();
	this.btn_21.setTransform(122.6,209.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_21, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_4 = new cjs.Text("1430-1520 \nCancionero \nde Baena, de Estúñiga \ny de Palacio", "12px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 210;
	this.text_4.setTransform(134.8,199.6);
var html = createDiv(txt['hito_prere_1'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(134, 199-613);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AAAn/IAAP/");
	  this.shape_2 = new lib.Mapadebits1();
	this.shape_2.setTransform(121.7,267.7-50);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,1,1).p("AAAo1IAARr");
	  this.shape_3 = new lib.Mapadebits1();
	this.shape_3.setTransform(334.5,269.2-50);
this.shape_3b = new cjs.Shape();
	this.shape_3b.graphics.f().s("#000000").ss(2,1,1).p("AAAo1IAARr");
	  this.shape_3b = new lib.Mapadebits1();
	this.shape_3b.setTransform(770,239.2-50);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("AAAmWIAAMu");
	  this.shape_4 = new lib.Mapadebits1();
	this.shape_4.setTransform(581.1,367.6-50);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(2,1,1).p("AAAtCIAAaF");
	  this.shape_5 = new lib.Mapadebits2();
	this.shape_5.setTransform(861.4,362.3-75,1,1);

	this.text_5 = new cjs.Text("1492 \nCoplas a la muerte \ndel maestre don Rodrigo, \nJorge Manrique", "12px Verdana");
	this.text_5.textAlign = "right";
	this.text_5.lineHeight = 11;
	this.text_5.lineWidth = 210;
	this.text_5.setTransform(199,404.9);
var html = createDiv(txt['hito_prere_4'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_5 = new cjs.DOMElement(html);
    this.text_5.setTransform(562-230, 404-613);

	this.btn_24 = new lib.btn_ampliar();
	this.btn_24.setTransform(582.4,412.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_24, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_6.setTransform(581.8,327.8,1.046,1,0,-179.9,180);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_7.setTransform(861.3,279,1.046,1,-179.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_8.setTransform(335.3,325.3,1.047,1);

	this.shape_9 = new cjs.Shape();
	this.shape_9  = new lib.Mapadebits1();
	  this.shape_9 = new lib.Mapadebits1();
	this.shape_9.setTransform(282.4,378.2-50);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_10.setTransform(282.8,325.9,1.046,1,0,-179.9,180);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_11.setTransform(120.5,322.4,1.047,1);



	this.instance_1 = new lib.mc_prerenacimiento();
	this.instance_1.setTransform(479,327.4,1,1,0,0,0,331.5,60.3);

	 this.btn_21.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_3_1']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_22.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_3_2'],1.5);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_23.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_3_3'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_24.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_3_4'],1.4);
            this.parent.addChild(this.parent.popup);
        });

                this.btn_25.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_3_5'],1.4);
            this.parent.addChild(this.parent.popup);
        });

                this.btn_26.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup1_3_6'],1.6);
            this.parent.addChild(this.parent.popup);
        });


       this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info1']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1_3());
        });
       
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.text_6,this.titulo,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.btn_24,this.text_5,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.text_4,this.btn_21,this.btn_22,this.text_3,this.btn_23,this.shape_3b,this.text_2,this.btn_26,this.text_1,this.shape_1,this.text,this.btn_25,this.logo,this.home,this.anterior,this.informacion);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,1,0);
        titulo2(this, txt['titulo2_1']);

	this.instance_1 = new lib.mc_Intro1500();
	this.instance_1.setTransform(491.1,329.9,1,1,0,0,0,331.5,60.3);
        
        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info2']);
            this.parent.addChild(this.parent.informacion);
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame2_2());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.titulo,this.instance_1,this.informacion,this.siguiente,this.home,this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,1,0);
        titulo2(this, txt['titulo2_1']);

	this.btn_86 = new lib.btn_ampliar();
	this.btn_86.setTransform(714.4,172.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_86, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text = new cjs.Text("1577-1582 \nCántico espiritual, \nsan Juan de la Cruz", "12px Verdana");
	this.text.lineHeight = 11;
	this.text.lineWidth = 210;
	this.text.setTransform(725.7,163.7);
var html = createDiv(txt['hito_re_7'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(725, 163-613);

	  this.shape_1 = new lib.Mapadebits2();
	  this.shape_1.setTransform(712.5,254.3-70);
	  this.shape_2 = new lib.Mapadebits1();
	  this.shape_2.setTransform(537,271.1-50);

	  this.shape_4 = new lib.Mapadebits2();
	  this.shape_4.setTransform(805.7,365.7-70,1,.9);
	  this.shape_6 = new lib.Mapadebits1();
	  this.shape_6.setTransform(589.5,366.2-50,1,.9);
	  this.shape_8 = new lib.Mapadebits2();
	  this.shape_8.setTransform(345,249.5-70,1,.9);

	  this.shape_9 = new lib.Mapadebits1();
	  this.shape_9.setTransform(414.5,348.6-50);
	  this.shape_12 = new lib.Mapadebits1();
	  this.shape_12.setTransform(254.5,382.1-50);
	  this.shape_14 = new lib.Mapadebits1();
	this.shape_14.setTransform(159.1,264.5-50,1,.9);


	this.text_1 = new cjs.Text("Finales del siglo XVI \nVida retirada, \nfray Luis León", "12px Verdana");
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 257;
	this.text_1.setTransform(601.5,395.2);
var html = createDiv(txt['hito_re_6'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(601, 395-613);


	this.btn_84 = new lib.btn_ampliar();
	this.btn_84.setTransform(537.3,210.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_84, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_2 = new cjs.Text("1562-1565 \nLibro de la vida, \nsanta Teresa de Jesús", "12px Verdana");
	this.text_2.lineHeight = 11;
	this.text_2.lineWidth = 210;
	this.text_2.setTransform(548.6,202.5);
var html = createDiv(txt['hito_re_5'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(548, 202-613);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(536.9,326,1.047,1);

	this.btn_83 = new lib.btn_ampliar();
	this.btn_83.setTransform(416.2,402.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_83, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_3 = new cjs.Text("1554 \nEl Lazarillo \nde Tormes, anónimo\n ", "12px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.lineWidth = 257;
	this.text_3.setTransform(427.3,395.7);
var html = createDiv(txt['hito_re_4'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(427, 395-613);

	this.btn_82 = new lib.btn_ampliar();
	this.btn_82.setTransform(346.9,168.2,0.6,0.6);
	new cjs.ButtonHelper(this.btn_82, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_4 = new cjs.Text("1543 \nÉglogas, \nGarcilaso de la Vega", "12px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 210;
	this.text_4.setTransform(358.2,156.1);
var html = createDiv(txt['hito_re_3'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(358, 156-613);

	this.btn_81 = new lib.btn_ampliar();
	this.btn_81.setTransform(255.4,446.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_81, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_5 = new cjs.Text("1526\nLa incorporación a la lírica castellana \nde la métrica y el estilo propios \ndel renacimiento italiano", "12px Verdana");
	this.text_5.lineHeight = 11;
	this.text_5.lineWidth = 257;
	this.text_5.setTransform(265.6,441.2);
var html = createDiv(txt['hito_re_2'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_5 = new cjs.DOMElement(html);
    this.text_5.setTransform(265, 441-613);

	this.btn_80 = new lib.btn_ampliar();
	this.btn_80.setTransform(160.8,209.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_80, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_6 = new cjs.Text("1508\nAmadís de Gaula, \nanónimo", "12px Verdana");
	this.text_6.lineHeight = 11;
	this.text_6.lineWidth = 210;
	this.text_6.setTransform(173,201.2);
var html = createDiv(txt['hito_re_1'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_6 = new cjs.DOMElement(html);
    this.text_6.setTransform(173, 201-613);


	this.btn_87 = new lib.btn_ampliar();
	this.btn_87.setTransform(805.7,455.6,0.6,0.6);
	new cjs.ButtonHelper(this.btn_87, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_7 = new cjs.Text("1585\n La Galatea, \nMiguel de Cervantes\n", "12px Verdana");
	this.text_7.textAlign = "right";
	this.text_7.lineHeight = 11;
	this.text_7.lineWidth = 257;
	this.text_7.setTransform(788.5,453.8);
var html = createDiv(txt['hito_re_8'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_7 = new cjs.DOMElement(html);
    this.text_7.setTransform(788-230, 453-613);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_5.setTransform(807.1,302,1.046,1,0,-179.9,180);

	this.btn_85 = new lib.btn_ampliar();
	this.btn_85.setTransform(591.2,401.7,0.6,0.6);
	new cjs.ButtonHelper(this.btn_85, 0, 1, 2, false, new lib.btn_ampliar(), 3);


	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_7.setTransform(589.6,325.2,1.046,1,-179.9);

	
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_10.setTransform(414.6,301.1,1.046,1,-179.9);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_11.setTransform(344.6,326.9,1.047,1);

	
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_13.setTransform(254.9,325.9,1.046,1,0,-179.9,180);

	
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_15.setTransform(159.4,302.3,1.047,1);



	this.instance_1 = new lib.mc_renacimiento();
	this.instance_1.setTransform(479,327.4,1,1,0,0,0,331.5,60.3);

	 this.btn_80.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_1_1']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_81.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_1_2']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_82.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_1_3'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_83.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_1_4'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_84.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_1_5'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_85.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_1_6'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_86.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_1_7'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_87.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_1_8'],1.4);
            this.parent.addChild(this.parent.popup);
        });
        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info1']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame2_1());
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame2_3());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.text_8,this.titulo,this.btn_inicio,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.btn_85,this.shape_5,this.text_7,this.btn_87,this.shape_4,this.text_6,this.btn_80,this.text_5,this.btn_81,this.text_4,this.btn_82,this.text_3,this.btn_83,this.shape_3,this.text_2,this.btn_84,this.shape_2,this.text_1,this.shape_1,this.text,this.btn_86,this.logo,this.siguiente,this.anterior,this.informacion,this.home);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,1,0);
        titulo2(this, txt['titulo2_1']);

	this.btn_7 = new lib.btn_ampliar();
	this.btn_7.setTransform(591.2,179.7,0.6,0.6,180);
	new cjs.ButtonHelper(this.btn_7, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_6 = new lib.btn_ampliar();
	this.btn_6.setTransform(538.7,410.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_6, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_5 = new lib.btn_ampliar();
	this.btn_5.setTransform(402.1,194.6,0.6,0.6);
	new cjs.ButtonHelper(this.btn_5, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_4 = new lib.btn_ampliar();
	this.btn_4.setTransform(313.9,466.8,0.6,0.6,180);
	new cjs.ButtonHelper(this.btn_4, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_3 = new lib.btn_ampliar();
	this.btn_3.setTransform(259.3,175.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_3, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_2 = new lib.btn_ampliar();
	this.btn_2.setTransform(183.1,416.2,0.6,0.6,180);
	new cjs.ButtonHelper(this.btn_2, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_1 = new lib.btn_ampliar();
	this.btn_1.setTransform(139.4,195,0.6,0.6);
	new cjs.ButtonHelper(this.btn_1, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_1 = new cjs.Text("1651 \nEl criticón, \nBaltasar Gracián ", "12px Verdana");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 11;
	this.text_1.setTransform(842.7,212.1);
var html = createDiv(txt['hito_bar_9'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(842-230, 212-613);

	this.text_2 = new cjs.Text("1635 \nLa vida es sueño,\nCalderón de la Barca \n", "12px Verdana");
	this.text_2.lineHeight = 11;
	this.text_2.setTransform(752.2,450.5);
var html = createDiv(txt['hito_bar_8'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(752, 450-613);

	this.text_3 = new cjs.Text("1628 \nEl burlador de Sevilla,\nTirso de Molina  \n", "12px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.setTransform(601.2,170.6);
var html = createDiv(txt['hito_bar_7'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(601, 170-613);

	this.text_4 = new cjs.Text("1626 \nEl Buscón, \nFrancisco de Quevedo ", "12px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.setTransform(551.3,402.8);
var html = createDiv(txt['hito_bar_6'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(551, 402-613);

	this.text_5 = new cjs.Text("1615 \nSegunda parte \nde El Quijote, \nMiguel de Cervantes", "12px Verdana");
	this.text_5.lineHeight = 11;
	this.text_5.setTransform(410.9,189.9);
var html = createDiv(txt['hito_bar_5'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_5 = new cjs.DOMElement(html);
    this.text_5.setTransform(410, 189-613);

	this.text_6 = new cjs.Text("1613 \nFábula de Polifemo \ny Galatea, \nLuis de Góngora", "12px Verdana");
	this.text_6.lineHeight = 11;
	this.text_6.setTransform(325.9,454.5);
var html = createDiv(txt['hito_bar_4'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_6 = new cjs.DOMElement(html);
    this.text_6.setTransform(325, 454-613);

	this.text_7 = new cjs.Text("1609\nArte nuevo de \nhacer comedias, \nLope de Vega", "12px Verdana");
	this.text_7.lineHeight = 11;
	this.text_7.lineWidth = 253;
	this.text_7.setTransform(271.2,170.6);
var html = createDiv(txt['hito_bar_3'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_7 = new cjs.DOMElement(html);
    this.text_7.setTransform(271, 170-613);

	this.text_8 = new cjs.Text("1605\nEl Quijote, \nMiguel de \nCervantes", "12px Verdana");
	this.text_8.lineHeight = 11;
	this.text_8.lineWidth = 210;
	this.text_8.setTransform(194,405);
var html = createDiv(txt['hito_bar_2'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_8 = new cjs.DOMElement(html);
    this.text_8.setTransform(194, 405-613);

	this.text_9 = new cjs.Text("1599-1602\nGuzmán de \nAlfarache, \nMateo Alemán", "12px Verdana");
	this.text_9.lineHeight = 11;
	this.text_9.lineWidth = 210;
	this.text_9.setTransform(148.6,189.5);
var html = createDiv(txt['hito_bar_1'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_9 = new cjs.DOMElement(html);
    this.text_9.setTransform(148, 189-613);

	this.btn_9 = new lib.btn_ampliar();
	this.btn_9.setTransform(859.2,227.8,0.6,0.6,180);
	new cjs.ButtonHelper(this.btn_9, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_8 = new lib.btn_ampliar();
	this.btn_8.setTransform(740.5,462.4,0.6,0.6);
	new cjs.ButtonHelper(this.btn_8, 0, 1, 2, false, new lib.btn_ampliar(), 3);



	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(591.2,281.5,1.047,1);

	this.shape_2 = new cjs.Shape();
		  this.shape_2 = new lib.Mapadebits1();

	this.shape_2.setTransform(402.6,253.5-50);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(402.6,302.7,1.047,1);

	this.shape_4 = new cjs.Shape();
		  this.shape_4 = new lib.Mapadebits1();

	this.shape_4.setTransform(183.3,356.6-50);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_5.setTransform(183.3,307.3,1.047,1,180);

	this.shape_6 = new cjs.Shape();
	this.shape_6  = new lib.Mapadebits1();
	this.shape_6.setTransform(139.2,256-50);

	this.shape_7 = new cjs.Shape();
	this.shape_7 = new lib.Mapadebits1();
	this.shape_7.setTransform(858.9,245.2-10,1,.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_8.setTransform(858.4,306.2,1.046,1,0,0,0,-0.2,0.1);

	this.shape_9 = new cjs.Shape();
	this.shape_9 = new lib.Mapadebits2();
	this.shape_9.setTransform(739.8,375.3-80);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_10.setTransform(740,283.3,1.047,1,180);

	this.shape_11 = new cjs.Shape();
	this.shape_11  = new lib.Mapadebits1();
	this.shape_11.setTransform(537.8,359.6-50);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_12.setTransform(538.1,305.7,1.047,1,180);

	this.shape_13 = new cjs.Shape();
	this.shape_13  = new lib.Mapadebits1();
	this.shape_13.setTransform(314.5,392.6-50);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_14.setTransform(314.1,329.8,1.046,1,-179.9);

	this.shape_15 = new cjs.Shape();
	this.shape_15  = new lib.Mapadebits1();
	this.shape_15.setTransform(258.5,233.1-50);
this.shape_15b = new cjs.Shape();
	this.shape_15b  = new lib.Mapadebits1();
	this.shape_15b.setTransform(590,233.1-50);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_16.setTransform(258.7,282.2,1.047,1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_17.setTransform(139.1,305.3,1.047,1);

	this.instance_1 = new lib.mc_barroco();
	this.instance_1.setTransform(480.3,329.9,1,1,0,0,0,331.5,60.3);

	 this.btn_1.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup5_1_1']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_2.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup5_1_2'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_3.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup5_1_3'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_4.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup5_1_4'],1.6);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_5.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup5_1_5'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_6.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup5_1_6'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_7.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup5_1_7'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_8.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup5_1_8'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_9.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup5_1_9'],1.4);
            this.parent.addChild(this.parent.popup);
        });
        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info2']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame2_2());
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame2_4());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.btn_8,this.btn_9,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.btn_1,this.btn_2,this.btn_3,this.btn_4,this.btn_5,this.btn_6,this.btn_7,this.shape_15b,this.logo,this.siguiente,this.anterior,this.informacion,this.home,this.titulo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
      (lib.frame2_4 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,1,0);
        titulo2(this, txt['titulo2_1']);

		this.text = new cjs.Text("1794\nInforme en el expediente de la ley agraria, Gaspar Melchor de Jovellanos", "12px Verdana");
	this.text.textAlign = "right";
	this.text.lineHeight = 11;
	this.text.lineWidth = 257;
	this.text.setTransform(822.1,154.3);
var html = createDiv(txt['hito_neo_9'], "Verdana", "12px", '250px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(822-250, 154-613);

	

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(838.3,305,1.047,1);

	this.btn_77 = new lib.btn_ampliar();
	this.btn_77.setTransform(605.1,220.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_77, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_2 = new cjs.Shape();
	this.shape_2  = new lib.Mapadebits1();
	this.shape_2.setTransform(605,263.4-50);
this.shape_3 = new cjs.Shape();
	this.shape_3  = new lib.Mapadebits1();
	this.shape_3.setTransform(730.3,346.2-50);
        
        this.shape_6 = new cjs.Shape();
	this.shape_6  = new lib.Mapadebits1();
	this.shape_6.setTransform(551.4,402.6-58,1,1.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7 = new lib.Mapadebits1();
	this.shape_7.setTransform(402.3,238.7-58,1,1.2);
	
	this.shape_8b = new lib.Mapadebits1();
	this.shape_8b.setTransform(840.3,238.7-58,1,1.2);

	this.shape_7b  = new lib.Mapadebits1();
	this.shape_7b.setTransform(840.3,238.7-58,1,1.2);
	this.shape_8 = new cjs.Shape();
	this.shape_8  = new lib.Mapadebits1();
	this.shape_8.setTransform(211.6,275.6-30,1,.6);
this.shape_10 = new cjs.Shape();
	this.shape_10  = new lib.Mapadebits1();
	this.shape_10.setTransform(337.1,358.2-50);

	this.shape_11 = new cjs.Shape();
	this.shape_11  = new lib.Mapadebits1();
	this.shape_11.setTransform(84.9,238.5-58,1,1.2);

	this.btn_79 = new lib.btn_ampliar();
	this.btn_79.setTransform(837.8,164.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_79, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_1 = new cjs.Text("1792\nLa comedia \nnueva o El café, \nLeandro Fernández \nde Moratín", "12px Verdana");
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 257;
	this.text_1.setTransform(740.7,403.7);
var html = createDiv(txt['hito_neo_8'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(742, 403-613);

	this.btn_78 = new lib.btn_ampliar();
	this.btn_78.setTransform(730.7,411.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_78, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_4.setTransform(730.3,283,1.047,1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_5.setTransform(605.8,306.9,1.047,1);

	this.text_2 = new cjs.Text("1789\nCartas marruecas, \nJosé Cadalso", "12px Verdana");
	this.text_2.lineHeight = 11;
	this.text_2.lineWidth = 250;
	this.text_2.setTransform(613.6,213);
var html = createDiv(txt['hito_neo_7'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(615, 213-613);

	
	this.btn_75 = new lib.btn_ampliar();
	this.btn_75.setTransform(403.2,162.7,0.6,0.6);
	new cjs.ButtonHelper(this.btn_75, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_73 = new lib.btn_ampliar();
	this.btn_73.setTransform(210.9,238.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_73, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_3 = new cjs.Text("1737 \nPoética, Ignacio de Luzán", "12px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.lineWidth = 250;
	this.text_3.setTransform(219.4,230.7);
var html = createDiv(txt['hito_neo_3'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(221, 230-613);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_9.setTransform(211.8,306.5,1.047,1);

	this.text_4 = new cjs.Text("1726-1740 \nTeatro crítico universal, Benito Jerónimo Feijoo", "12px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 175;
	this.text_4.setTransform(149,418.5);
var html = createDiv(txt['hito_neo_2'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(150, 418-613);

	this.btn_76 = new lib.btn_ampliar();
	this.btn_76.setTransform(552.1,477.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_76, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_5 = new cjs.Text("1785\nPoesías, \nJuan Meléndez Valdés", "12px Verdana");
	this.text_5.lineHeight = 11;
	this.text_5.lineWidth = 257;
	this.text_5.setTransform(560.5,469.9);
var html = createDiv(txt['hito_neo_6'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_5 = new cjs.DOMElement(html);
    this.text_5.setTransform(562, 469-613);

	this.text_6 = new cjs.Text("1782\nFábulas literarias, \nTomás de Iriarte", "12px Verdana");
	this.text_6.lineHeight = 11;
	this.text_6.lineWidth = 184;
	this.text_6.setTransform(411.7,155.1);
var html = createDiv(txt['hito_neo_5'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_6 = new cjs.DOMElement(html);
    this.text_6.setTransform(413, 155-613);

	this.btn_72 = new lib.btn_ampliar();
	this.btn_72.setTransform(139.2,426.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_72, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_71 = new lib.btn_ampliar();
	this.btn_71.setTransform(86.1,165.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_71, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_7 = new cjs.Text("1713\nLa fundación de la \nBiblioteca Nacional y de la \nReal Academia Española", "12px Verdana");
	this.text_7.lineHeight = 11;
	this.text_7.lineWidth = 224;
	this.text_7.setTransform(96.4,155.6);
var html = createDiv(txt['hito_neo_1'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_7 = new cjs.DOMElement(html);
    this.text_7.setTransform(98, 155-613);

	this.btn_74 = new lib.btn_ampliar();
	this.btn_74.setTransform(337.3,408.7,0.6,0.6);
	new cjs.ButtonHelper(this.btn_74, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	

	this.text_8 = new cjs.Text("1781\nFábulas morales, Félix María Samaniego", "12px Verdana");
	this.text_8.lineHeight = 11;
	this.text_8.lineWidth = 210;
	this.text_8.setTransform(347.2,402.3);
var html = createDiv(txt['hito_neo_4'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_8 = new cjs.DOMElement(html);
    this.text_8.setTransform(348, 402-613);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_12.setTransform(336.8,307,1.046,1,0,-179.9,180);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_13.setTransform(551.9,330.9,1.046,1,-179.9);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_14.setTransform(401.2,307.4,1.047,1);

	this.shape_15 = new cjs.Shape();
	this.shape_15  = new lib.Mapadebits1();
	this.shape_15.setTransform(138.2,362.1-50);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_16.setTransform(138.6,309.8,1.046,1,0,-179.9,180);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_17.setTransform(85,308.3,1.047,1);

	this.instance_1 = new lib.mc_neoclasicismo();
	this.instance_1.setTransform(470.1,329.5,1,1,0,0,0,331.5,60.3);

	 this.btn_71.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup6_1_1']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_72.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup6_1_2'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_73.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup6_1_3'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_74.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup6_1_4'],1.6);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_75.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup6_1_5'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_76.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup6_1_6'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_77.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup6_1_7'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_78.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup6_1_8'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_79.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup6_1_9'],1.4);
            this.parent.addChild(this.parent.popup);
        });
        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info2']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame2_3());
        });
       
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.titulo,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.text_8,this.shape_11,this.shape_10,this.btn_74,this.shape_8b,this.text_7,this.btn_71,this.btn_72,this.text_6,this.text_5,this.btn_76,this.text_4,this.shape_9,this.text_3,this.btn_73,this.shape_8,this.shape_7,this.btn_75,this.shape_6,this.text_2,this.shape_5,this.shape_4,this.shape_3,this.btn_78,this.text_1,this.btn_79,this.shape_2,this.btn_77,this.shape_1,this.text,this.shape_7b,this.logo,this.anterior,this.informacion,this.home);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,1,0);
        titulo2(this, txt['titulo3_1']);

	this.instance_1 = new lib.mc_Intro1800();
	this.instance_1.setTransform(491.1,329.9,1,1,0,0,0,331.5,60.3);
        
        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info3']);
            this.parent.addChild(this.parent.informacion);
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame3_2());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.titulo,this.instance_1,this.informacion,this.siguiente,this.home,this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
       (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,1,0);
        titulo2(this, txt['titulo3_1']);

	this.btn_64 = new lib.btn_ampliar();
	this.btn_64.setTransform(712.4,207.1,0.6,0.6);
	new cjs.ButtonHelper(this.btn_64, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text = new cjs.Text("1844\nDon Juan Tenorio, \nJosé Zorrilla", "12px Verdana");
	this.text.lineHeight = 11;
	this.text.lineWidth = 257;
	this.text.setTransform(599.2,440.1);
var html = createDiv(txt['hito_rom_4'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(601, 440-613);

	
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_2.setTransform(711.6,300.7,1.047,1);

	this.text_1 = new cjs.Text("1849\nLa gaviota, \nFernán Caballero", "12px Verdana");
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 210;
	this.text_1.setTransform(723.7,198.9);
var html = createDiv(txt['hito_rom_5'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(725, 198-613);

	this.btn_62 = new lib.btn_ampliar();
	this.btn_62.setTransform(374.4,209.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_62, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_2 = new cjs.Text("1836\nEl estudiante de Salamanca, José de Espronceda ", "12px Verdana");
	this.text_2.lineHeight = 11;
	this.text_2.lineWidth = 210;
	this.text_2.setTransform(386.6,200.9);
var html = createDiv(txt['hito_rom_3'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(388, 201-613);

	this.btn_61 = new lib.btn_ampliar();
	this.btn_61.setTransform(268.6,446.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_61, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_3 = new cjs.Text("1835\nDon Álvaro o la fuerza del sino, \nduque de Rivas", "12px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.lineWidth = 257;
	this.text_3.setTransform(278.8,441.2);
var html = createDiv(txt['hito_rom_2'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(280, 441-613);

	this.btn_60 = new lib.btn_ampliar();
	this.btn_60.setTransform(158.8,209.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_60, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_4 = new cjs.Text("1832-1837\nArtículos, Mariano \nJosé de Larra", "12px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 210;
	this.text_4.setTransform(171,201.2);
var html = createDiv(txt['hito_rom_1'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(172, 201-613);

	this.btn_63 = new lib.btn_ampliar();
	this.btn_63.setTransform(589.2,446.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_63, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(588.9,279.9,1.046,1,0,-179.9,180);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_6.setTransform(373,326.9,1.047,1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_7.setTransform(268.1,279.3,1.046,1,0,-179.9,180);
this.shape_1 = new cjs.Shape();
	this.shape_1  = new lib.Mapadebits1();
	this.shape_1.setTransform(373.4,272.7-50);

	this.shape_4 = new cjs.Shape();
	this.shape_4  = new lib.Mapadebits2();
	this.shape_4.setTransform(588.9,363.2-74);

	this.shape_5 = new cjs.Shape();
	this.shape_5  = new lib.Mapadebits2();
	this.shape_5.setTransform(268.2,362.2-74);

	this.shape_8 = new cjs.Shape();
	this.shape_8  = new lib.Mapadebits1();
	this.shape_8.setTransform(157.1,264.5-50,1,.8);

	this.shape = new cjs.Shape();
	this.shape = new lib.Mapadebits1();
	this.shape.setTransform(711.4,258.4-50,1,.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_9.setTransform(157.4,302.3,1.047,1);

	

	

	this.instance_1 = new lib.mc_romanticismo();
	this.instance_1.setTransform(477,327.4,1,1,0,0,0,331.5,60.3);

	 this.btn_60.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3b_1_1']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_61.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3b_1_2']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_62.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3b_1_3'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_63.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3b_1_4'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_64.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3b_1_5'],1.4);
            this.parent.addChild(this.parent.popup);
        });

        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info3']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame3_1());
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame3_3());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.titulo,this.btn_inicio,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.btn_63,this.text_4,this.btn_60,this.text_3,this.btn_61,this.text_2,this.btn_62,this.text_1,this.shape_2,this.shape_1,this.text,this.shape,this.btn_64,this.logo,this.siguiente,this.anterior,this.informacion,this.home);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame3_3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,1,0);
        titulo2(this, txt['titulo3_1']);

	this.btn_49 = new lib.btn_ampliar();
	this.btn_49.setTransform(772.9,161.1,0.6,0.6);
	new cjs.ButtonHelper(this.btn_49, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(772.9,304.5,1.047,1);

	this.btn_48 = new lib.btn_ampliar();
	this.btn_48.setTransform(731.5,467.2,0.6,0.6);
	new cjs.ButtonHelper(this.btn_48, 0, 1, 2, false, new lib.btn_ampliar(), 3);


	this.btn_42 = new lib.btn_ampliar();
	this.btn_42.setTransform(151.1,456.6,0.6,0.6);
	new cjs.ButtonHelper(this.btn_42, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_47 = new lib.btn_ampliar();
	this.btn_47.setTransform(644.3,222,0.6,0.6);
	new cjs.ButtonHelper(this.btn_47, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_45 = new lib.btn_ampliar();
	this.btn_45.setTransform(536.3,161.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_45, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_43 = new lib.btn_ampliar();
	this.btn_43.setTransform(408.1,183.6,0.6,0.6);
	new cjs.ButtonHelper(this.btn_43, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_41 = new lib.btn_ampliar();
	this.btn_41.setTransform(112.2,200.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_41, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_1 = new cjs.Text("1886\nLos pazos \nde Ulloa, \nEmilia Pardo \nBazán ", "12px Verdana");
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 210;
	this.text_1.setTransform(783.3,153.7);
var html = createDiv(txt['hito_real_9'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(785, 153-613);

	this.text_2 = new cjs.Text("1884\nSotileza, \nJosé María de Pereda ", "12px Verdana");
	this.text_2.lineHeight = 11;
	this.text_2.lineWidth = 210;
	this.text_2.setTransform(740.9,457.7);
var html = createDiv(txt['hito_real_8'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(742, 457-613);

	this.text_3 = new cjs.Text("1884-1885\nLa Regenta, \nClarín", "12px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.lineWidth = 210;
	this.text_3.setTransform(655.7,213);
var html = createDiv(txt['hito_real_7'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(657, 213-613);

	this.text_4 = new cjs.Text("1881\nLa desheredada, \nBenito Pérez Galdós", "12px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 210;
	this.text_4.setTransform(604.1,480);
var html = createDiv(txt['hito_real_6'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(606, 480-613);

	this.btn_46 = new lib.btn_ampliar();
	this.btn_46.setTransform(594.7,487.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_46, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_5 = new cjs.Text("1876\nDoña perfecta, \nBenito Pérez Galdós", "12px Verdana");
	this.text_5.lineHeight = 11;
	this.text_5.lineWidth = 210;
	this.text_5.setTransform(546.2,152.8);
var html = createDiv(txt['hito_real_5'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_5 = new cjs.DOMElement(html);
    this.text_5.setTransform(548, 153-613);

	this.text_6 = new cjs.Text("1874\nPepita Jiménez, \nJuan Valera", "12px Verdana");
	this.text_6.lineHeight = 11;
	this.text_6.lineWidth = 210;
	this.text_6.setTransform(449.9,476.2);
var html = createDiv(txt['hito_real_4'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_6 = new cjs.DOMElement(html);
    this.text_6.setTransform(451, 476-613);

	this.text_7 = new cjs.Text("1873-1912\nEpisodios \nNacionales, \nBenito Pérez \nGaldós", "12px Verdana");
	this.text_7.lineHeight = 11;
	this.text_7.lineWidth = 210;
	this.text_7.setTransform(418.4,176);
var html = createDiv(txt['hito_real_3'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_7 = new cjs.DOMElement(html);
    this.text_7.setTransform(420, 176-613);
	
	this.text_8 = new cjs.Text("1863\nCantares gallegos, \nRosalía de Castro", "12px Verdana");
	this.text_8.lineHeight = 11;
	this.text_8.lineWidth = 210;
	this.text_8.setTransform(162.8,449.4);
var html = createDiv(txt['hito_real_2'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_8 = new cjs.DOMElement(html);
    this.text_8.setTransform(164, 450-613);

	this.text_9 = new cjs.Text("1857-1871 \nRimas y Leyendas, \nGustavo Adolfo Bécquer", "12px Verdana");
	this.text_9.lineHeight = 11;
	this.text_9.lineWidth = 210;
	this.text_9.setTransform(121.7,191);
var html = createDiv(txt['hito_real_1'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_9 = new cjs.DOMElement(html);
    this.text_9.setTransform(123, 191-613);

	this.btn_44 = new lib.btn_ampliar();
	this.btn_44.setTransform(438.5,485,0.6,0.6);
	new cjs.ButtonHelper(this.btn_44, 0, 1, 2, false, new lib.btn_ampliar(), 3);
	this.shape_8 = new cjs.Shape();
	this.shape_8 = new lib.Mapadebits1();
	this.shape_8.setTransform(110.9,269.9-55,1,1.05);

         this.shape_3 = new cjs.Shape();
	this.shape_3  = new lib.Mapadebits1();
	this.shape_3.setTransform(150.1,392.3-55,1,1.05);
this.shape_4 = new cjs.Shape();
	this.shape_4  = new lib.Mapadebits1();
	this.shape_4.setTransform(407.8,248-50);
this.shape_10 = new cjs.Shape();
	this.shape_10  = new lib.Mapadebits2();
	this.shape_10.setTransform(437.6,392.5-75);

this.shape_2 = new cjs.Shape();
	this.shape_2  = new lib.Mapadebits1();
	this.shape_2.setTransform(536.4,237.3-65,1,1.2);
this.shape_7 = new cjs.Shape();
	this.shape_7 = new lib.Mapadebits2();
	this.shape_7.setTransform(593.3,391.4-75);

	this.shape_13 = new cjs.Shape();
	this.shape_13  = new lib.Mapadebits1();
	this.shape_13.setTransform(644.3,271.3-50,1,.8);


	
	this.shape_5 = new cjs.Shape();
	this.shape_5  = new lib.Mapadebits2();
	this.shape_5.setTransform(730.1,386.6-78);
this.shape_2b = new cjs.Shape();
	this.shape_2b  = new lib.Mapadebits1();
	this.shape_2b.setTransform(770,237.3-65,1,1.2);
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_6.setTransform(730.1,304.8,1.047,1,180);

	
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_9.setTransform(593,305.8,1.047,1,180);

	
	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_11.setTransform(438.2,304.9,1.047,1,180);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_12.setTransform(150.9,327.9,1.047,1,180);


	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_14.setTransform(644.3,304.9,1.047,1);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_15.setTransform(536.2,304.9,1.047,1);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_16.setTransform(407.5,303.4,1.047,1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_17.setTransform(111.7,327.4,1.047,1);

	this.instance_1 = new lib.mc_realismo();
	this.instance_1.setTransform(478.4,327.4,1,1,0,0,0,331.5,60.3);

	 this.btn_41.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_2_1']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_42.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_2_2']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_43.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_2_3'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_44.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_2_4'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_45.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_2_5'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_46.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_2_6'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_47.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_2_7'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_48.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_2_8'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_49.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_2_9'],1.4);
            this.parent.addChild(this.parent.popup);
        });

        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info3']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame3_2());
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame3_4());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.btn_44,this.text_9,this.text_8,this.shape_3,this.text_7,this.text_6,this.text_5,this.btn_46,this.text_4,this.text_3,this.text_2,this.text_1,this.btn_41,this.btn_43,this.btn_45,this.btn_47,this.btn_42,this.shape_2,this.btn_48,this.shape_1,this.btn_49,this.shape_2b,this.titulo,this.logo,this.siguiente,this.anterior,this.informacion,this.home);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
      (lib.frame3_4 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,1,0);
        titulo2(this, txt['titulo3_1']);

	this.btn_38 = new lib.btn_ampliar();
	this.btn_38.setTransform(860.9,482.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_38, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	
	this.text = new cjs.Text("1914\nNiebla, \nMiguel de Unamuno", "12px Verdana");
	this.text.textAlign = "right";
	this.text.lineHeight = 11;
	this.text.lineWidth = 257;
	this.text.setTransform(843.3,476);
var html = createDiv(txt['hito_mod_9'], "Verdana", "12px", '250px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(845-250, 476-613);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(861.3,304.4,1.047,1);

	this.btn_35 = new lib.btn_ampliar();
	this.btn_35.setTransform(563.1,166.6,0.6,0.6);
	new cjs.ButtonHelper(this.btn_35, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_1 = new cjs.Text("1902\nSoledades, \nAntonio Machado", "12px Verdana");
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 175;
	this.text_1.setTransform(395.4,421.9);
var html = createDiv(txt['hito_mod_4'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(397, 421-613);

	this.btn_34 = new lib.btn_ampliar();
	this.btn_34.setTransform(387.3,430.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_34, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_6.setTransform(386.7,332.1,1.046,1,0,-179.9,180);

	this.text_2 = new cjs.Text("1914\nJuan Ramón Jiménez", "12px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 11;
	this.text_2.lineWidth = 257;
	this.text_2.setTransform(765.7,219.8);
var html = createDiv(txt['hito_mod_2'], "Verdana", "12px", '250px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(767-250, 220-613);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_7.setTransform(781.8,307.3,1.047,1);

	this.btn_37 = new lib.btn_ampliar();
	this.btn_37.setTransform(782.3,228.6,0.6,0.6);
	new cjs.ButtonHelper(this.btn_37, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_3 = new cjs.Text("1911\nEl árbol de la ciencia, \nPío Baroja", "12px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.lineWidth = 257;
	this.text_3.setTransform(671.1,418.4);
var html = createDiv(txt['hito_mod_7'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(672, 419-613);

	this.btn_36 = new lib.btn_ampliar();
	this.btn_36.setTransform(663.1,427.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_36, 0, 1, 2, false, new lib.btn_ampliar(), 3);


	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_9.setTransform(662.6,307.3,1.047,1);

	this.btn_33 = new lib.btn_ampliar();
	this.btn_33.setTransform(221.4,227.4,0.6,0.6);
	new cjs.ButtonHelper(this.btn_33, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_4 = new cjs.Text("1902\nLa voluntad, \nAzorín", "12px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 151;
	this.text_4.setTransform(230.9,220.6);
var html = createDiv(txt['hito_mod_3'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(232, 221-613);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_10.setTransform(221.4,306.8,1.047,1);

	this.text_5 = new cjs.Text("1898 \nLa generación del 98", "12px Verdana");
	this.text_5.lineHeight = 11;
	this.text_5.lineWidth = 175;
	this.text_5.setTransform(191,418.9);
var html = createDiv(txt['hito_mod_8'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_5 = new cjs.DOMElement(html);
    this.text_5.setTransform(192, 418-613);

	this.text_6 = new cjs.Text("1907\nLos intereses creados, Jacinto Benavente", "12px Verdana");
	this.text_6.lineHeight = 11;
	this.text_6.lineWidth = 184;
	this.text_6.setTransform(572.5,160.2);
var html = createDiv(txt['hito_mod_6'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_6 = new cjs.DOMElement(html);
    this.text_6.setTransform(574, 160-613);

	this.btn_32 = new lib.btn_ampliar();
	this.btn_32.setTransform(182.9,427.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_32, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_31 = new lib.btn_ampliar();
	this.btn_31.setTransform(95.6,165.7,0.6,0.6);
	new cjs.ButtonHelper(this.btn_31, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_7 = new cjs.Text("1888 \nAzul, \nRubén Darío", "12px Verdana");
	this.text_7.lineHeight = 11;
	this.text_7.lineWidth = 224;
	this.text_7.setTransform(105.9,155.9);
var html = createDiv(txt['hito_mod_1'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_7 = new cjs.DOMElement(html);
    this.text_7.setTransform(107, 155-613);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_11.setTransform(181.6,328.1,1.046,1,0,-179.9,180);

this.shape_12 = new cjs.Shape();
	this.shape_12  = new lib.Mapadebits2();
	this.shape_12.setTransform(94.4,250.6-80,1,.9);
this.shape_14 = new cjs.Shape();
	this.shape_14  = new lib.Mapadebits1();
	this.shape_14.setTransform(182,362.5-50);
this.shape_1 = new cjs.Shape();
	this.shape_1  = new lib.Mapadebits1();
	this.shape_1.setTransform(220.2,271.9-50,1,.85);
this.shape_5 = new cjs.Shape();
	this.shape_5  = new lib.Mapadebits1();
	this.shape_5.setTransform(386.3,384.5-50);
this.shape_4 = new cjs.Shape();
	this.shape_4  = new lib.Mapadebits1();
	this.shape_4.setTransform(562.9,227.9-50);

	
	this.shape_8 = new cjs.Shape();
	this.shape_8  = new lib.Mapadebits1();
	this.shape_8.setTransform(662.7,370.5-55);
this.shape_2 = new cjs.Shape();
	this.shape_2  = new lib.Mapadebits1();
	this.shape_2.setTransform(782,274.8-50,1,.85);

	
this.shape = new cjs.Shape();
	this.shape  = new lib.Mapadebits2();
	this.shape.setTransform(861.4,392.5-80);

	
	
	
	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_13.setTransform(562.9,280,1.047,1);

	
	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_15.setTransform(181.6,310.1,1.046,1,0,-179.9,180);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_16.setTransform(94.5,328.7,1.047,1);

	

	this.instance_1 = new lib.mc_modernismo();
	this.instance_1.setTransform(479.6,329.9,1,1,0,0,0,331.5,60.3);

	 this.btn_31.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_3_1']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_32.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_3_2']);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_33.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_3_3'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_34.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_3_4'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_35.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_3_5'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_36.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_3_6'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_37.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_3_7'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_38.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup3_3_8'],1.4);
            this.parent.addChild(this.parent.popup);
        });

        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info3']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame3_3());
        });
     
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.text_8,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.text_7,this.btn_31,this.btn_32,this.text_6,this.text_5,this.shape_10,this.text_4,this.btn_33,this.shape_9,this.shape_8,this.btn_36,this.text_3,this.btn_37,this.shape_7,this.text_2,this.shape_6,this.shape_5,this.btn_34,this.text_1,this.shape_4,this.btn_35,this.shape_3,this.text,this.shape_2,this.shape_1,this.shape,this.btn_38,this.titulo,this.logo,this.anterior,this.informacion,this.home);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    
     (lib.frame4_1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,1,0);
        titulo2(this, txt['titulo4_1']);

	this.instance_1 = new lib.mc_Intro1900();
	this.instance_1.setTransform(491.1,329.9,1,1,0,0,0,331.5,60.3);
        
        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info4']);
            this.parent.addChild(this.parent.informacion);
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame4_2());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.titulo,this.instance_1,this.informacion,this.siguiente,this.home,this.logo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
         (lib.frame4_2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,1,0);
        titulo2(this, txt['titulo4_1']);

	this.btn_95 = new lib.btn_ampliar();
	this.btn_95.setTransform(690.3,205.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_95, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text = new cjs.Text("1925 \nLa deshumanización del arte, José Ortega y Gasset", "12px Verdana");
	this.text.lineHeight = 11;
	this.text.lineWidth = 151;
	this.text.setTransform(700.7,198.7);
var html = createDiv(txt['hito_nove_5'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(702, 199-613);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(689.3,300.1,1.047,1);

	this.text_1 = new cjs.Text("1922 \nSegunda antolojía poética, Juan Ramón Jiménez", "12px Verdana");
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 175;
	this.text_1.setTransform(581.8,415.8);
var html = createDiv(txt['hito_nove_4'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(583, 415-613);

	this.btn_94 = new lib.btn_ampliar();
	this.btn_94.setTransform(572.8,424.2,0.6,0.6);
	new cjs.ButtonHelper(this.btn_94, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(572.5,326.2,1.046,1,0,-179.9,180);
this.shape_2 = new cjs.Shape();
	this.shape_2  = new lib.Mapadebits1();
	this.shape_2.setTransform(572.1,375.5-50);

	this.shape_4 = new cjs.Shape();
	this.shape_4  = new lib.Mapadebits1();
	this.shape_4.setTransform(92.3,267.5-50);

	this.shape_5 = new cjs.Shape();
	this.shape_5  = new lib.Mapadebits1();
	this.shape_5.setTransform(385.1,255.5-50,1,.9);
	this.shape_5b = new cjs.Shape();
	this.shape_5b  = new lib.Mapadebits1();
	this.shape_5b.setTransform(685.1,255.5-50,1,.9);
this.shape_9 = new cjs.Shape();
	this.shape_9  = new lib.Mapadebits1();
	this.shape_9.setTransform(215.8,376.1-50);

	
	this.btn_93 = new lib.btn_ampliar();
	this.btn_93.setTransform(386.3,205,0.6,0.6);
	new cjs.ButtonHelper(this.btn_93, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_2 = new cjs.Text("1921 \nNuestro padre san Daniel, Gabriel Miró", "12px Verdana");
	this.text_2.lineHeight = 11;
	this.text_2.lineWidth = 151;
	this.text_2.setTransform(396.7,198.2);
var html = createDiv(txt['hito_nove_3'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(398, 198-613);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_6.setTransform(385.3,299.6,1.047,1);

	this.text_3 = new cjs.Text("1916\nDiario de un poeta \nrecién casado, \nJuan Ramón Jiménez", "12px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.lineWidth = 175;
	this.text_3.setTransform(225.5,416.4);
var html = createDiv(txt['hito_nove_2'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(227, 416-613);

	this.btn_92 = new lib.btn_ampliar();
	this.btn_92.setTransform(216.5,424.8,0.6,0.6);
	new cjs.ButtonHelper(this.btn_92, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_91 = new lib.btn_ampliar();
	this.btn_91.setTransform(94,201.2,0.6,0.6);
	new cjs.ButtonHelper(this.btn_91, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_4 = new cjs.Text("1914\nLa generación de 1914", "12px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 224;
	this.text_4.setTransform(104.3,191.4);
var html = createDiv(txt['hito_nove_1'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(106, 191-613);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_7.setTransform(91.9,279.2,1.047,1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_8.setTransform(92.5,301.8,1.047,1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_10.setTransform(216.2,326.8,1.046,1,0,-179.9,180);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_11.setTransform(92.5,325.7,1.047,1);


	this.instance_1 = new lib.mc_NOVECENTISMO();
	this.instance_1.setTransform(478,327.4,1,1,0,0,0,331.5,60.3);

	 this.btn_91.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4b_1_1'],1.8);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_92.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4b_1_2'],1.6);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_93.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4b_1_3'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_94.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4b_1_4'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_95.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4b_1_5'],1.7);
            this.parent.addChild(this.parent.popup);
        });

        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info4']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame4_1());
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame4_3());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.text_5,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.text_4,this.btn_91,this.btn_92,this.text_3,this.shape_6,this.text_2,this.btn_93,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_5b,this.btn_94,this.text_1,this.shape_1,this.text,this.btn_95,this.logo,this.siguiente,this.anterior,this.informacion,this.home,this.titulo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame4_3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,1,0);
        titulo2(this, txt['titulo4_1']);

	this.text = new cjs.Text("1936\n La realidad y el deseo, \nLuis Cernuda", "12px Verdana");
	this.text.textAlign = "right";
	this.text.lineHeight = 11;
	this.text.lineWidth = 210;
	this.text.setTransform(847.9,484.2);
var html = createDiv(txt['hito_van_10'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(849-230, 484-613);

	this.btn_59 = new lib.btn_ampliar();
	this.btn_59.setTransform(862.2,490.8,0.6,0.6);
	new cjs.ButtonHelper(this.btn_59, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape = new cjs.Shape();
	this.shape  = new lib.Mapadebits2();
	this.shape.setTransform(860.8,412-75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(861.6,331.8,1.046,1,0,-179.9,180);

	this.text_1 = new cjs.Text("1933\nBodas de sangre, \nFederico García Lorca", "12px Verdana");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 210;
	this.text_1.setTransform(797.2,151);
var html = createDiv(txt['hito_van_9'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(799-230, 151-613);

	this.shape_2 = new cjs.Shape();
	this.shape_2 = new lib.Mapadebits1();
	this.shape_2.setTransform(687.5,350.7-50);

	this.btn_57 = new lib.btn_ampliar();
	this.btn_57.setTransform(687.6,400.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_57, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_2 = new cjs.Text("1933 \nFlor de greguerías, \nRamón Gómez \nde la Serna", "12px Verdana");
	this.text_2.lineHeight = 11;
	this.text_2.lineWidth = 257;
	this.text_2.setTransform(698.8,393.7);
var html = createDiv(txt['hito_van_8'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(700, 394-613);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(687,304,1.046,1,0,-179.9,180);

	this.shape_4 = new cjs.Shape();
	this.shape_4 = new lib.Mapadebits1();
	this.shape_4.setTransform(539.2,386.1-50);

	this.btn_53 = new lib.btn_ampliar();
	this.btn_53.setTransform(322.8,446.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_53, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_3 = new cjs.Text("1924 \nVeinte poemas \nde amor y una \ncanción desesperada, \nPablo Neruda", "12px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.lineWidth = 257;
	this.text_3.setTransform(334,440.3);
var html = createDiv(txt['hito_van_4'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(335, 440-613);

	this.shape_5 = new cjs.Shape();
	this.shape_5  = new lib.Mapadebits1();
	this.shape_5.setTransform(321.7,387.1-50);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_6.setTransform(322.3,328.7,1.046,1,0,-179.9,180);

	this.btn_56 = new lib.btn_ampliar();
	this.btn_56.setTransform(627,218.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_56, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_7 = new cjs.Shape();
	this.shape_7  = new lib.Mapadebits1();
	this.shape_7.setTransform(626,271.8-50);

	this.text_4 = new cjs.Text("1929 \nSobre los ángeles, \nRafael Alberti\n", "12px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 257;
	this.text_4.setTransform(553.4,440.3);
var html = createDiv(txt['hito_van_6'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(555, 440-613);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_8.setTransform(626.1,328.7,1.047,1);

	this.text_5 = new cjs.Text("1931\nAltazor, \nVicente Huidobro", "12px Verdana");
	this.text_5.lineHeight = 11;
	this.text_5.lineWidth = 210;
	this.text_5.setTransform(638.2,210.3);
var html = createDiv(txt['hito_van_7'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_5 = new cjs.DOMElement(html);
    this.text_5.setTransform(640, 210-613);

	this.btn_52 = new lib.btn_ampliar();
	this.btn_52.setTransform(233.6,225.4,0.6,0.6);
	new cjs.ButtonHelper(this.btn_52, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_6 = new cjs.Text("1923\nCántico, \nJorge Guillén", "12px Verdana");
	this.text_6.lineHeight = 11;
	this.text_6.lineWidth = 210;
	this.text_6.setTransform(244.8,217.1);
var html = createDiv(txt['hito_van_3'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_6 = new cjs.DOMElement(html);
    this.text_6.setTransform(246, 217-613);

	this.btn_51 = new lib.btn_ampliar();
	this.btn_51.setTransform(150.9,446.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_51, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_7 = new cjs.Text("1922\nTrilce, \nCésar Vallejo", "12px Verdana");
	this.text_7.lineHeight = 11;
	this.text_7.lineWidth = 257;
	this.text_7.setTransform(162.1,440.3);
var html = createDiv(txt['hito_van_2'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_7 = new cjs.DOMElement(html);
    this.text_7.setTransform(164, 440-613);

	this.btn_50 = new lib.btn_ampliar();
	this.btn_50.setTransform(97.1,182.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_50, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_8 = new cjs.Text("1920\nLuces de Bohemia, \nValle-Inclán", "12px Verdana");
	this.text_8.lineHeight = 11;
	this.text_8.lineWidth = 210;
	this.text_8.setTransform(109.3,174.6);
var html = createDiv(txt['hito_van_1'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_8 = new cjs.DOMElement(html);
    this.text_8.setTransform(111, 174-613);

	this.shape_9 = new cjs.Shape();
	this.shape_9  = new lib.Mapadebits1();
	this.shape_9.setTransform(813.9,223.4-50);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_10.setTransform(813.8,278,1.047,1);

	this.btn_58 = new lib.btn_ampliar();
	this.btn_58.setTransform(813.4,160.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_58, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_54 = new lib.btn_ampliar();
	this.btn_54.setTransform(364.5,225.8,0.6,0.6);
	new cjs.ButtonHelper(this.btn_54, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_9 = new cjs.Text("1927\nLa generación del 27", "12px Verdana");
	this.text_9.lineHeight = 11;
	this.text_9.lineWidth = 210;
	this.text_9.setTransform(375.7,217.5);
var html = createDiv(txt['hito_van_5'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_9 = new cjs.DOMElement(html);
    this.text_9.setTransform(377, 217-613);

	this.shape_11 = new cjs.Shape();
	this.shape_11  = new lib.Mapadebits1();
	this.shape_11.setTransform(362.8,281.7-50);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_12.setTransform(362.1,328.2,1.047,1);

	this.shape_13 = new cjs.Shape();
	this.shape_13  = new lib.Mapadebits1();
	this.shape_13.setTransform(231.9,281.3-50);

	this.shape_14 = new cjs.Shape();
	this.shape_14  = new lib.Mapadebits1();
	this.shape_14.setTransform(149.7,387.1-50);

	this.btn_55 = new lib.btn_ampliar();
	this.btn_55.setTransform(541.4,446.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_55, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_15.setTransform(539.2,328.7,1.046,1,0,-179.9,180);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_16.setTransform(231.2,327.8,1.047,1);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_17.setTransform(150.3,328.7,1.046,1,0,-179.9,180);

	this.shape_18 = new cjs.Shape();
	this.shape_18  = new lib.Mapadebits1();
	this.shape_18.setTransform(95.4,237.9-50);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_19.setTransform(95.7,275.7,1.047,1);

	

	this.instance_1 = new lib.mc_VANGUARDIAS_OK();
	this.instance_1.setTransform(478,327.4,1,1,0,0,0,331.5,60.3);

	 this.btn_50.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_2_1'],1.8);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_51.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_2_2'],1.6);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_52.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_2_3'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_53.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_2_4'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_54.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_2_5'],1.7);
            this.parent.addChild(this.parent.popup);
        });
 this.btn_55.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_2_6'],1.8);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_56.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_2_7'],1.6);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_57.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_2_8'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_58.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_2_9'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_59.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_2_10'],1.7);
            this.parent.addChild(this.parent.popup);
        });
        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info4']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame4_2());
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame4_4());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.btn_inicio,this.text_10,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.btn_55,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.text_9,this.btn_54,this.btn_58,this.shape_10,this.shape_9,this.text_8,this.btn_50,this.text_7,this.btn_51,this.text_6,this.btn_52,this.text_5,this.shape_8,this.text_4,this.shape_7,this.btn_56,this.text_3,this.btn_53,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_2,this.btn_57,this.text_1,this.btn_59,this.text,this.logo,this.siguiente,this.anterior,this.informacion,this.home,this.titulo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
      (lib.frame4_4 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,1,0);
        titulo2(this, txt['titulo4_1']);

this.btn_111 = new lib.btn_ampliar();
	this.btn_111.setTransform(694.2,170.1,0.6,0.6);
	new cjs.ButtonHelper(this.btn_111, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	
	this.btn_105 = new lib.btn_ampliar();
	this.btn_105.setTransform(338.6,173.4,0.6,0.6);
	new cjs.ButtonHelper(this.btn_105, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_107 = new lib.btn_ampliar();
	this.btn_107.setTransform(440,227.8,0.6,0.6);
	new cjs.ButtonHelper(this.btn_107, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_106 = new lib.btn_ampliar();
	this.btn_106.setTransform(390.1,485.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_106, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(694.1,305.1,1.047,1);

	this.btn_110 = new lib.btn_ampliar();
	this.btn_110.setTransform(666.5,469.7,0.6,0.6);
	new cjs.ButtonHelper(this.btn_110, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_102 = new lib.btn_ampliar();
	this.btn_102.setTransform(149.1,483.3,0.6,0.6);
	new cjs.ButtonHelper(this.btn_102, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_109 = new lib.btn_ampliar();
	this.btn_109.setTransform(564.1,229.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_109, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_103 = new lib.btn_ampliar();
	this.btn_103.setTransform(222,230.4,0.6,0.6);
	new cjs.ButtonHelper(this.btn_103, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_101 = new lib.btn_ampliar();
	this.btn_101.setTransform(95.9,171.2,0.6,0.6);
	new cjs.ButtonHelper(this.btn_101, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_114 = new lib.btn_ampliar();
	this.btn_114.setTransform(859.2,478.2,0.6,0.6);
	new cjs.ButtonHelper(this.btn_114, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_1 = new cjs.Text("1970 \nNueve novísimos poetas españoles, \nJosep Maria Castellet", "12px Verdana");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 210;
	this.text_1.setTransform(842.7,470.2);
var html = createDiv(txt['hito_dicta1_14'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(841-230, 470-613);

	this.text_2 = new cjs.Text("1966\nMoralidades, \nJaime Gil \nde Biedma", "12px Verdana");
	this.text_2.lineHeight = 11;
	this.text_2.lineWidth = 210;
	this.text_2.setTransform(777,193.2);
var html = createDiv(txt['hito_dicta1_13'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(779, 193-613);

	this.btn_113 = new lib.btn_ampliar();
	this.btn_113.setTransform(767.4,201.2,0.6,0.6);
	new cjs.ButtonHelper(this.btn_113, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_3 = new cjs.Text("1966\nCinco horas \ncon Mario, \nMiguel Delibes", "12px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.lineWidth = 210;
	this.text_3.setTransform(730.5,396.3);
var html = createDiv(txt['hito_dicta1_12'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(732, 396-613);

	this.btn_112 = new lib.btn_ampliar();
	this.btn_112.setTransform(720.3,405.1,0.6,0.6);
	new cjs.ButtonHelper(this.btn_112, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_6.setTransform(720,305.3,1.047,1,180);

	this.text_4 = new cjs.Text("1955\nPedro Páramo, \nJuan Rulfo", "12px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 210;
	this.text_4.setTransform(449.2,217.6);
var html = createDiv(txt['hito_dicta1_7'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(451, 218-613);

	this.text_5 = new cjs.Text("1951\nLa colmena, \nCamilo José Cela", "12px Verdana");
	this.text_5.lineHeight = 11;
	this.text_5.lineWidth = 210;
	this.text_5.setTransform(399.3,478.9);
var html = createDiv(txt['hito_dicta1_6'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_5 = new cjs.DOMElement(html);
    this.text_5.setTransform(401, 478-613);

	this.text_6 = new cjs.Text("1949\nHistoria de una escalera, Antonio Buero Vallejo ", "12px Verdana");
	this.text_6.lineHeight = 11;
	this.text_6.lineWidth = 210;
	this.text_6.setTransform(232.2,221.6);
var html = createDiv(txt['hito_dicta1_3'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_6 = new cjs.DOMElement(html);
    this.text_6.setTransform(234, 221-613);


	
this.shape_8 = new cjs.Shape();
	this.shape_8  = new lib.Mapadebits1();
	this.shape_8.setTransform(94.5,240.8-50);

	this.shape_7 = new cjs.Shape();
	this.shape_7  = new lib.Mapadebits2();
	this.shape_7.setTransform(147.7,409-75,1,.9);
        
	this.shape_18 = new cjs.Shape();
	this.shape_18  = new lib.Mapadebits1();
	this.shape_18.setTransform(221.6,259.6-20,1,.4);
        
this.shape_17 = new cjs.Shape();
	this.shape_17  = new lib.Mapadebits1();
	this.shape_17.setTransform(238.2,360.6-50);

this.shape_1 = new cjs.Shape();
	this.shape_1  = new lib.Mapadebits2();
	this.shape_1.setTransform(337.5,256.9-70,1,.8);
        
this.shape_15 = new cjs.Shape();
	this.shape_15  = new lib.Mapadebits2();
	this.shape_15.setTransform(390.1,391.3-75);
        
	this.shape_2 = new cjs.Shape();
	this.shape_2  = new lib.Mapadebits1();
	this.shape_2.setTransform(441.2,273.2-50,1,.7);
        
          this.shape_13 = new cjs.Shape();
	this.shape_13  = new lib.Mapadebits1();
	this.shape_13.setTransform(548.3,365.8-30,1,.7);
  this.shape_23 = new cjs.Shape();
	this.shape_23  = new lib.Mapadebits1();
	this.shape_23.setTransform(564.1,271.9-50,1,.7);

this.shape_12 = new cjs.Shape();
	this.shape_12  = new lib.Mapadebits2();
	this.shape_12.setTransform(665.8,388.2-75);

	
this.shape = new cjs.Shape();
	this.shape  = new lib.Mapadebits1();
	this.shape.setTransform(693.8,241.9-50);

	
this.shape_5 = new cjs.Shape();
	this.shape_5  = new lib.Mapadebits1();
	this.shape_5.setTransform(719.8,355.8-50);
	
          this.shape_9 = new cjs.Shape();
	this.shape_9  = new lib.Mapadebits1();
	this.shape_9.setTransform(767,269.3-55);
    
	
          this.shape_4 = new cjs.Shape();
	this.shape_4  = new lib.Mapadebits2();
	this.shape_4.setTransform(860.4,402.9-75,1,.9);

	this.text_7 = new cjs.Text("1962\nTiempo de silencio, \nLuis Martín-Santos\n", "12px Verdana");
	this.text_7.textAlign = "right";
	this.text_7.lineHeight = 11;
	this.text_7.lineWidth = 210;
	this.text_7.setTransform(679.2,162.3);
var html = createDiv(txt['hito_dicta1_11'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_7 = new cjs.DOMElement(html);
    this.text_7.setTransform(678-230, 162-613);

	this.text_8 = new cjs.Text("1960\nEl boom \nde la novela \nhispanoamericana", "12px Verdana");
	this.text_8.textAlign = "right";
	this.text_8.lineHeight = 11;
	this.text_8.lineWidth = 210;
	this.text_8.setTransform(652.2,462.7);
var html = createDiv(txt['hito_dicta1_10'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_8 = new cjs.DOMElement(html);
    this.text_8.setTransform(654-230, 462-613);

	this.text_9 = new cjs.Text("1956 \nEl Jarama, Rafael Sánchez Ferlosio", "12px Verdana");
	this.text_9.lineHeight = 11;
	this.text_9.lineWidth = 210;
	this.text_9.setTransform(573.4,219.9);
var html = createDiv(txt['hito_dicta1_9'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_9 = new cjs.DOMElement(html);
    this.text_9.setTransform(575, 220-613);

	this.text_10 = new cjs.Text("1955\nPido la paz y \nla palabra, \nBlas de Otero", "12px Verdana");
	this.text_10.textAlign = "right";
	this.text_10.lineHeight = 11;
	this.text_10.lineWidth = 210;
	this.text_10.setTransform(531.6,397.4);
var html = createDiv(txt['hito_dicta1_8'], "Verdana", "12px", '250px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_10 = new cjs.DOMElement(html);
    this.text_10.setTransform(531-250, 397-613);

	this.btn_108 = new lib.btn_ampliar();
	this.btn_108.setTransform(549,403.6,0.6,0.6);
	new cjs.ButtonHelper(this.btn_108, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_11 = new cjs.Text("1950 \nLa generación de 1950", "12px Verdana");
	this.text_11.lineHeight = 11;
	this.text_11.lineWidth = 210;
	this.text_11.setTransform(346.4,165.8);
var html = createDiv(txt['hito_dicta1_5'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_11 = new cjs.DOMElement(html);
    this.text_11.setTransform(348, 165-613);

	this.text_12 = new cjs.Text("1949 \nEl Aleph, \nJorge Luis Borges", "12px Verdana");
	this.text_12.lineHeight = 11;
	this.text_12.lineWidth = 210;
	this.text_12.setTransform(249.1,413.4);
var html = createDiv(txt['hito_dicta1_4'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_12 = new cjs.DOMElement(html);
    this.text_12.setTransform(251, 413-613);

	this.text_13 = new cjs.Text("1944\nHijos de la ira, \nDámaso Alonso", "12px Verdana");
	this.text_13.lineHeight = 11;
	this.text_13.lineWidth = 210;
	this.text_13.setTransform(158.7,475);
var html = createDiv(txt['hito_dicta1_2'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_13 = new cjs.DOMElement(html);
    this.text_13.setTransform(160, 475-613);

	this.text_14 = new cjs.Text("1942 \nLa familia de Pascual Duarte, Camilo José Cela", "12px Verdana");
	this.text_14.lineHeight = 11;
	this.text_14.lineWidth = 210;
	this.text_14.setTransform(104.5,162.4);
var html = createDiv(txt['hito_dicta1_1'], "Verdana", "12px", '250px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_14 = new cjs.DOMElement(html);
    this.text_14.setTransform(106, 162-613);

	this.btn_104 = new lib.btn_ampliar();
	this.btn_104.setTransform(238.7,421.1,0.6,0.6);
	new cjs.ButtonHelper(this.btn_104, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	
	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_10.setTransform(860.4,329.4,1.047,1,180);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_11.setTransform(767.9,328.9,1.047,1);

	
	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_14.setTransform(441.6,303.9,1.047,1);

	
	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_16.setTransform(390.6,303.9,1.047,1);

	
	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_19.setTransform(665.1,305.2,1.047,1,180);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_20.setTransform(549,329.3,1.047,1,180);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_21.setTransform(238.5,302.3,1.047,1,180);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_22.setTransform(147.8,330.4,1.047,1,180);

	
	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_24.setTransform(564.1,305.5,1.047,1);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_25.setTransform(338.5,327.3,1.047,1);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_26.setTransform(221.3,279.1,1.047,1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_27.setTransform(95.4,302.6,1.047,1);

	this.instance_1 = new lib.mc_dictadura();
	this.instance_1.setTransform(479.3,328.1,1,1,0,0,0,331.5,60.3);
        
	 this.btn_101.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_1'],1.8);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_102.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_2'],1.6);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_103.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_3'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_104.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_4'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_105.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_5'],1.7);
            this.parent.addChild(this.parent.popup);
        });
        this.btn_106.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_6'],1.8);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_107.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_7'],1.6);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_108.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_8'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_109.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_9'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_110.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_10'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_111.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_11'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_112.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_12'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_113.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_13'],1.7);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_114.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_3_14'],1.7);
            this.parent.addChild(this.parent.popup);
        });
        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info4']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame4_3());
        });
        this.siguiente.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame4_5());
        });
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.shape_27,this.shape_26,this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.btn_104,this.text_14,this.text_13,this.text_12,this.text_11,this.btn_108,this.text_10,this.text_9,this.text_8,this.text_7,this.shape_7,this.text_6,this.text_5,this.text_4,this.shape_6,this.shape_5,this.btn_112,this.text_3,this.btn_113,this.text_2,this.shape_4,this.text_1,this.btn_114,this.btn_101,this.btn_103,this.btn_109,this.btn_102,this.btn_110,this.shape_3,this.btn_106,this.btn_107,this.shape_2,this.shape_1,this.btn_105,this.shape,this.btn_111,this.text,this.logo,this.siguiente,this.anterior,this.informacion,this.home,this.titulo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
      (lib.frame4_5 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,1,0);
        titulo2(this, txt['titulo4_1']);
this.btn_128 = new lib.btn_ampliar();
	this.btn_128.setTransform(426.7,434.2,0.6,0.6);
	new cjs.ButtonHelper(this.btn_128, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_125 = new lib.btn_ampliar();
	this.btn_125.setTransform(98.3,187.2,0.6,0.6);
	new cjs.ButtonHelper(this.btn_125, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_1 = new cjs.Text("2002-2007\nTu rostro mañana, \nJavier Marías", "12px Verdana");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 210;
	this.text_1.setTransform(795.9,492.2);
var html = createDiv(txt['hito_dicta2_8'], "Verdana", "12px", '230px', '40px', "20px", "185px", "right");
  html.style.zIndex=-1;
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(795-230, 492-613);

	this.btn_132 = new lib.btn_ampliar();
	this.btn_132.setTransform(811.4,499.5,0.6,0.6);
	new cjs.ButtonHelper(this.btn_132, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape = new cjs.Shape();
	this.shape  = new lib.Mapadebits2();
	this.shape.setTransform(811.7,403.6-85);

	this.text_2 = new cjs.Text("1989\nJuegos de la edad tardía, \nLuís Landero", "12px Verdana");
	this.text_2.lineHeight = 11;
	this.text_2.lineWidth = 210;
	this.text_2.setTransform(550.7,180);
var html = createDiv(txt['hito_dicta2_5'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(552, 180-613);

	this.text_3 = new cjs.Text("1985\nLos vanos mundos, \nFelipe Benítez Reyes", "12px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.lineWidth = 210;
	this.text_3.setTransform(435.2,426.7);
var html = createDiv(txt['hito_dicta2_4'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(437, 426-613);

	this.btn_127 = new lib.btn_ampliar();
	this.btn_127.setTransform(286.7,229.6,0.6,0.6);
	new cjs.ButtonHelper(this.btn_127, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.text_4 = new cjs.Text("1991\nEl jinete polaco, \nAntonio Muñoz Molina", "12px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 210;
	this.text_4.setTransform(631.7,429);
var html = createDiv(txt['hito_dicta2_6'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(633, 429-613);

	this.btn_130 = new lib.btn_ampliar();
	this.btn_130.setTransform(621.5,435.8,0.6,0.6);
	new cjs.ButtonHelper(this.btn_130, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(621.3,306.6,1.047,1,180);

	this.text_5 = new cjs.Text("1983\nEl jardín extranjero, \nLuís García Montero", "12px Verdana");
	this.text_5.lineHeight = 11;
	this.text_5.lineWidth = 210;
	this.text_5.setTransform(294.4,222.1);
var html = createDiv(txt['hito_dicta2_3'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_5 = new cjs.DOMElement(html);
    this.text_5.setTransform(296, 222-613);

	this.text_6 = new cjs.Text("1979 \nLos mares del Sur, \nManuel Vázquez Montalbán", "12px Verdana");
	this.text_6.lineHeight = 11;
	this.text_6.lineWidth = 210;
	this.text_6.setTransform(199.3,428.2);
var html = createDiv(txt['hito_dicta2_2'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_6 = new cjs.DOMElement(html);
    this.text_6.setTransform(201, 428-613);

	this.text_7 = new cjs.Text("1975\nLa verdad sobre el caso Savolta, Eduardo Mendoza ", "12px Verdana");
	this.text_7.lineHeight = 11;
	this.text_7.lineWidth = 210;
	this.text_7.setTransform(106.8,176.5);
var html = createDiv(txt['hito_dicta2_1'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_7 = new cjs.DOMElement(html);
    this.text_7.setTransform(108, 176-613);

	this.btn_126 = new lib.btn_ampliar();
	this.btn_126.setTransform(188.9,435.9,0.6,0.6);
	new cjs.ButtonHelper(this.btn_126, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.btn_131 = new lib.btn_ampliar();
	this.btn_131.setTransform(724.5,226,0.6,0.6);
	new cjs.ButtonHelper(this.btn_131, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_2 = new cjs.Shape();
	this.shape_2 = new lib.Mapadebits1();
	this.shape_2.setTransform(724.3,270.9-40,1,.7);

	this.text_8 = new cjs.Text("2005\nDoctor Pasavento, \nEnrique Vila-Matas", "12px Verdana");
	this.text_8.lineHeight = 11;
	this.text_8.lineWidth = 210;
	this.text_8.setTransform(732.2,218.6);
var html = createDiv(txt['hito_dicta2_7'], "Verdana", "12px", '230px', '40px', "20px", "185px", "left");
  html.style.zIndex=-1;
    this.text_8 = new cjs.DOMElement(html);
    this.text_8.setTransform(734, 218-613);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(723.9,306.7,1.047,1,180);

	this.shape_4 = new cjs.Shape();
	this.shape_4  = new lib.Mapadebits1();
	this.shape_4.setTransform(620.2,370.3-50);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_5.setTransform(541.1,306.3,1.047,1);

	this.btn_129 = new lib.btn_ampliar();
	this.btn_129.setTransform(541.6,187.2,0.6,0.6);
	new cjs.ButtonHelper(this.btn_129, 0, 1, 2, false, new lib.btn_ampliar(), 3);

	this.shape_6 = new cjs.Shape();
	this.shape_6  = new lib.Mapadebits1();
	this.shape_6.setTransform(540.3,255.3-50);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_7.setTransform(286.2,329.2,1.047,1,180);

	this.shape_8 = new cjs.Shape();
	this.shape_8  = new lib.Mapadebits1();
	this.shape_8.setTransform(285.3,282.7-50);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_9.setTransform(812.6,305.7,1.047,1,180);

	this.shape_10 = new cjs.Shape();
	this.shape_10  = new lib.Mapadebits1();
	this.shape_10.setTransform(427,385.5-50);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_11.setTransform(427.4,328.4,1.047,1);

	this.shape_12 = new cjs.Shape();
	this.shape_12  = new lib.Mapadebits1();
	this.shape_12.setTransform(188.4,366.1-50);

	this.shape_13 = new cjs.Shape();
	this.shape_13  = new lib.Mapadebits1();
	this.shape_13.setTransform(97,251.1-50);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_14.setTransform(188.6,305.7,1.047,1,180);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_15.setTransform(96.8,303.9,1.047,1);

	this.instance_1 = new lib.mc_dictadura2();
	this.instance_1.setTransform(478.3,329.5,1,1,0,0,0,331.5,60.3);
        
	 this.btn_125.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_4_1'],1.8);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_126.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_4_2'],1.6);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_127.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_4_3'],1.9);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_128.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_4_4'],1.4);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_129.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_4_5'],1.7);
            this.parent.addChild(this.parent.popup);
        });
        this.btn_130.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_4_6'],1.8);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_131.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_4_7'],1.6);
            this.parent.addChild(this.parent.popup);
        });
         this.btn_132.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
             this.parent.popup = new lib.popup(txt['txt_popup4_4_8'],1.7);
            this.parent.addChild(this.parent.popup);
        });
      
       
        this.informacion.on("click", function (evt) {
             if (popupon) return;
             popupon = true;
            this.parent.informacion=new lib.informacion(txt['txt_info4']);
            this.parent.addChild(this.parent.informacion);
        });
         this.anterior.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame4_4());
        });
      
        this.home.on("click", function (evt) {
             if (popupon) return;
            putStage(new lib.frame1());
        });

	this.addChild(this.instance_1,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.btn_129,this.shape_5,this.shape_4,this.shape_3,this.text_8,this.shape_2,this.btn_131,this.btn_126,this.text_7,this.text_6,this.text_5,this.shape_1,this.btn_130,this.text_4,this.btn_127,this.text_3,this.text_2,this.shape,this.btn_132,this.text_1,this.btn_125,this.btn_128,this.text,this.text,this.logo,this.anterior,this.informacion,this.home,this.titulo);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto,size) {
        size=size||'25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
          html.style.zIndex=-1;

        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130+ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }


    
    (lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,104);


  (lib.Mapadebits2 = function() {
	this.initialize(img.Mapadebits2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,104);


   (lib.mc_barroco = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("1700", "bold 16px Verdana");
	this.text.textAlign = "right";
	this.text.lineHeight = 18;
	this.text.lineWidth = 61;
	this.text.setTransform(716.1,85.1+incremento);

	this.text_1 = new cjs.Text("1600", "bold 16px Verdana");
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 53;
	this.text_1.setTransform(-49.6,85.1+incremento);

	this.text_2 = new cjs.Text("BARROCO", "16px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 18;
	this.text_2.setTransform(326.9,85.1+incremento);

	this.text_3 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(329.5,49.1+incremento);

	this.text_4 = new cjs.Text("PROSA", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(329.5,24.6+incremento);

	this.text_5 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(329.5,0.8+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA9NADwMh6ZAAAIAAnfMB6ZAAAg");
	this.shape.setTransform(329,96.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#66FFFF").s().p("Eg9MADwIAAnfMB6ZAAAIAAHfg");
	this.shape_1.setTransform(329,96.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("EAzzAB4MhnlAAAIAAjvMBnlAAAg");
	this.shape_2.setTransform(329.1,60.5,1.182,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#C398BF").s().p("EgzyAB4IAAjvMBnlAAAIAADvg");
	this.shape_3.setTransform(329.1,60.5,1.182,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("EAzzAB4MhnlAAAIAAjvMBnlAAAg");
	this.shape_4.setTransform(329.1,36.2,1.182,1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFF99").s().p("EgzyAB4IAAjvMBnlAAAIAADvg");
	this.shape_5.setTransform(329.1,36.2,1.182,1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("EAzzAB4MhnlAAAIAAjvMBnlAAAg");
	this.shape_6.setTransform(329.1,12,1.181,1);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#8FBF67").s().p("EgzyAB4IAAjvMBnlAAAIAADvg");
	this.shape_7.setTransform(329.1,12,1.181,1);

	this.addChild(this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.7,0,783.6,120.7);
(lib.mc_dictadura2 = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("1975", "bold 16px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 149;
	this.text.setTransform(-61.2,88.3+incremento);

	this.text_1 = new cjs.Text("LITERATURA DE LA DEMOCRACIA", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(328.8,85.7+incremento);

	this.text_2 = new cjs.Text("hasta la actualidad", "bold 16px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(713,73.1+incremento);

	// Capa 1
	this.text_3 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(329.5,49.1+incremento);

	this.text_4 = new cjs.Text("PROSA", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(329.5,24.6+incremento);

	this.text_5 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(329.5,0.8+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA9KADwMh6TAAAIAAnfMB6TAAAg");
	this.shape.setTransform(329.3,96.6,1,1,0,0,0,0.4,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADxEg9LADgIAAjg");
	this.shape_1.setTransform(329.1,48.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_2.setTransform(329.1,36.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_3.setTransform(329.1,12);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_4.setTransform(329.1,12);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_5.setTransform(329.1,48.5);

	// colors_nous2
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_6.setTransform(-62.6,61.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_7.setTransform(329.1,48.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvEg9MAB4IAAjv");
	this.shape_8.setTransform(329.1,60.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_9.setTransform(329.1,60.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF9900").s().p("Eg9JADwIAAnfMB6TAAAIAAHfg");
	this.shape_10.setTransform(329.1,96.7,1,1,0,0,0,0.1,-0.2);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.6,0,783.5,121);

(lib.mc_dictadura = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("1939", "bold 16px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 149;
	this.text.setTransform(-58.1,88.3+incremento);

	this.text_1 = new cjs.Text("LITERATURA DE LA DICTADURA", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(328.8,85.7+incremento);

	this.text_2 = new cjs.Text("1975", "bold 16px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(704.6,87.5+incremento);

	// Capa 1
	this.text_3 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(329.5,49.1+incremento);

	this.text_4 = new cjs.Text("PROSA", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(329.5,24.6+incremento);

	this.text_5 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(329.5,0.8+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA9KADwMh6TAAAIAAnfMB6TAAAg");
	this.shape.setTransform(329.3,96.6,1,1,0,0,0,0.4,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADxEg9LADgIAAjg");
	this.shape_1.setTransform(329.1,48.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_2.setTransform(329.1,36.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_3.setTransform(329.1,12);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_4.setTransform(329.1,12);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_5.setTransform(329.1,48.5);

	// colors_nous2
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_6.setTransform(-62.6,61.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_7.setTransform(329.1,48.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_8.setTransform(329.1,60.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_9.setTransform(329.1,60.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D55060").s().p("Eg9JADwIAAnfMB6TAAAIAAHfg");
	this.shape_10.setTransform(329.1,96.7,1,1,0,0,0,0.1,-0.2);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.6,0,783.5,121);

(lib.mc_VANGUARDIAS_OK = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("1918", "bold 16px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 149;
	this.text.setTransform(-58.1,88.3+incremento);

	this.text_1 = new cjs.Text("VANGUARDIAS", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(328.8,85.7+incremento);

	this.text_2 = new cjs.Text("1936", "bold 16px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(707.4,87.5+incremento);

	// colors_nous
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("Eg9JADsIAAnXMB6TAAAIAAHXg");
	this.shape.setTransform(329.2,96.5);

	// Capa 1
	this.text_3 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(329.5,49.1+incremento);

	this.text_4 = new cjs.Text("PROSA", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(329.5,24.6+incremento);

	this.text_5 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(329.5,0.8+incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("EA9NADwMh6ZAAAIAAnfMB6ZAAAg");
	this.shape_1.setTransform(329,96.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_2.setTransform(-62.6,61.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_3.setTransform(329.1,48.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_4.setTransform(329.1,60.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_5.setTransform(329.1,60.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADx");
	this.shape_6.setTransform(329.1,48.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_7.setTransform(329.1,36.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_8.setTransform(329.1,12);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_9.setTransform(329.1,12);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_10.setTransform(329.1,48.5);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.text_5,this.text_4,this.text_3,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.7,0,783.6,120.7);


(lib.mc_NOVECENTISMO = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("1914", "bold 16px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 149;
	this.text.setTransform(-58.1,88.3+incremento);

	this.text_1 = new cjs.Text("NOVECENTISMO", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(328.8,85.7+incremento);

	this.text_2 = new cjs.Text("1936", "bold 16px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(704.6,87.5+incremento);

	// Capa 1
	this.text_3 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(329.5,49.1+incremento);

	this.text_4 = new cjs.Text("PROSA", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(329.5,24.6+incremento);

	this.text_5 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(329.5,0.8+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA9KADwMh6TAAAIAAnfMB6TAAAg");
	this.shape.setTransform(329.3,96.6,1,1,0,0,0,0.4,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADxEg9LADgIAAjg");
	this.shape_1.setTransform(329.1,48.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_2.setTransform(329.1,36.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_3.setTransform(329.1,12);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_4.setTransform(329.1,12);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_5.setTransform(329.1,48.5);

	// colors_nous2
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_6.setTransform(-62.6,61.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_7.setTransform(329.1,48.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_8.setTransform(329.1,60.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_9.setTransform(329.1,60.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#D55060").s().p("Eg9JADwIAAnfMB6TAAAIAAHfg");
	this.shape_10.setTransform(329.1,96.7,1,1,0,0,0,0.1,-0.2);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.6,0,783.5,121);

(lib.mc_realismo = function() {
	this.initialize();

	// textes_nous
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgngtIBOAtIhOAtg");
	this.shape.setTransform(715.3,168);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("A+OAAMA8dAAA");
	this.shape_1.setTransform(561.6,168,0.775,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgmgsIBOAsIhOAtg");
	this.shape_2.setTransform(245.1,94.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("A+OAAMA8dAAA");
	this.shape_3.setTransform(92.9,94.7,0.804,1);

	this.text = new cjs.Text("naturalismo", "16px Verdana");
	this.text.lineHeight = 18;
	this.text.setTransform(574.6,146+incremento);

	this.text_1 = new cjs.Text("realismo", "16px Verdana");
	this.text_1.lineHeight = 18;
	this.text_1.setTransform(103.4,72.9+incremento);

	// anys
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("AAAILIAAwV");
	this.shape_4.setTransform(411.7,125.6,1,0.993);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("AAAILIAAwV");
	this.shape_5.setTransform(249.3,125.5,1,0.993);

	this.text_2 = new cjs.Text("1900", "bold 16px Verdana");
	this.text_2.lineHeight = 18;
	this.text_2.setTransform(670.7,117+incremento);

	this.text_3 = new cjs.Text("1880", "bold 16px Verdana");
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(390.2,179+incremento);

	this.text_4 = new cjs.Text("1870", "bold 16px Verdana");
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(225.7,179+incremento);

	this.text_5 = new cjs.Text("1850", "bold 16px Verdana");
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(-62.9,117+incremento);

	// Capa 1
	this.text_6 = new cjs.Text("REALISMO / NATURALISMO", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 18;
	this.text_6.setTransform(329.5,112.1+incremento);

	this.text_7 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 18;
	this.text_7.setTransform(329.5,49.1+incremento);

	this.text_8 = new cjs.Text("PROSA", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 18;
	this.text_8.setTransform(329.5,24.6+incremento);

	this.text_9 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 18;
	this.text_9.setTransform(329.5,0.8+incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("EA9NgILIAAQXMh6ZAAAIAAwX");
	this.shape_6.setTransform(329,125.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("rgba(102,0,153,0.498)").s().p("Eg9MAIMIAAwXMB6ZAAAIAAQXg");
	this.shape_7.setTransform(329,125.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_8.setTransform(-62.6,61.2);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_9.setTransform(329.1,48.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_10.setTransform(329.1,60.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_11.setTransform(329.1,60.8);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADx");
	this.shape_12.setTransform(329.1,48.3);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_13.setTransform(329.1,36.2);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_14.setTransform(329.1,12);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_15.setTransform(329.1,12);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_16.setTransform(329.1,48.5);

	this.addChild(this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.shape_5,this.shape_4,this.text_1,this.text,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.9,0,783.8,202.4);

(lib.mc_modernismo = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("1880", "bold 16px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 149;
	this.text.setTransform(-58.1,88.3+incremento);

	this.text_1 = new cjs.Text("MODERNISMO", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(328.8,85.7+incremento);

	this.text_2 = new cjs.Text("1915", "bold 16px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(704.6,87.5+incremento);

	// Capa 1
	this.text_3 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(329.5,49.1+incremento);

	this.text_4 = new cjs.Text("PROSA", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(329.5,24.6+incremento);

	this.text_5 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(329.5,0.8+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA9KADwMh6TAAAIAAnfMB6TAAAg");
	this.shape.setTransform(329.3,96.6,1,1,0,0,0,0.4,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADxEg9LADgIAAjg");
	this.shape_1.setTransform(329.1,48.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_2.setTransform(329.1,36.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_3.setTransform(329.1,12);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_4.setTransform(329.1,12);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_5.setTransform(329.1,48.5);

	// colors_nous2
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_6.setTransform(-62.6,61.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_7.setTransform(329.1,48.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_8.setTransform(329.1,60.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_9.setTransform(329.1,60.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#7AB199").s().p("Eg9JADwIAAnfMB6TAAAIAAHfg");
	this.shape_10.setTransform(329.1,96.7,1,1,0,0,0,0.1,-0.2);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.6,0,783.5,121);

(lib.mc_renacimiento = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("1500", "bold 16px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 149;
	this.text.setTransform(-58.1,88.3+incremento);

	this.text_1 = new cjs.Text("RENACIMIENTO", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(328.8,85.7+incremento);

	this.text_2 = new cjs.Text("1600", "bold 16px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(712.2,87.5+incremento);

	// colors_nous
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("Eg9JADsIAAnXMB6TAAAIAAHXg");
	this.shape.setTransform(329.2,96.5);

	// Capa 1
	this.text_3 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(329.5,49.1+incremento);

	this.text_4 = new cjs.Text("PROSA", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(329.5,24.6+incremento);

	this.text_5 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(329.5,0.8+incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("EA9NADwMh6ZAAAIAAnfMB6ZAAAg");
	this.shape_1.setTransform(329,96.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_2.setTransform(-62.6,61.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_3.setTransform(329.1,48.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_4.setTransform(329.1,60.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_5.setTransform(329.1,60.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADx");
	this.shape_6.setTransform(329.1,48.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_7.setTransform(329.1,36.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_8.setTransform(329.1,12);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_9.setTransform(329.1,12);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_10.setTransform(329.1,48.5);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.text_5,this.text_4,this.text_3,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.7,0,783.6,120.7);

(lib.mc_romanticismo = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("1800", "bold 16px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 149;
	this.text.setTransform(-58.1,88.3+incremento);

	this.text_1 = new cjs.Text("ROMANTICISMO", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(328.8,85.7+incremento);

	this.text_2 = new cjs.Text("1850", "bold 16px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(712.2,87.5+incremento);

	// colors_nous
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#00FFFF").s().p("Eg9JADsIAAnXMB6TAAAIAAHXg");
	this.shape.setTransform(329.2,96.5);

	// Capa 1
	this.text_3 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(329.5,49.1+incremento);

	this.text_4 = new cjs.Text("PROSA", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(329.5,24.6+incremento);

	this.text_5 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(329.5,0.8+incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("EA9NADwMh6ZAAAIAAnfMB6ZAAAg");
	this.shape_1.setTransform(329,96.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_2.setTransform(-62.6,61.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_3.setTransform(329.1,48.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_4.setTransform(329.1,60.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_5.setTransform(329.1,60.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADx");
	this.shape_6.setTransform(329.1,48.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_7.setTransform(329.1,36.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_8.setTransform(329.1,12);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_9.setTransform(329.1,12);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_10.setTransform(329.1,48.5);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.text_5,this.text_4,this.text_3,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.7,0,783.6,120.7);

   (lib.mc_prerenacimiento = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("1400", "bold 16px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 149;
	this.text.setTransform(-58.1,88.3+incremento);

	this.text_1 = new cjs.Text("PRERENACIMIENTO", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(328.8,85.7+incremento);

	this.text_2 = new cjs.Text("1500", "bold 16px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(704.6,87.5+incremento);

	// Capa 1
	this.text_3 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(329.5,49.1+incremento);

	this.text_4 = new cjs.Text("PROSA", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(329.5,24.6+incremento);

	this.text_5 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(329.5,0.8+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA9NADwMh6ZAAAIAAnfMB6ZAAAg");
	this.shape.setTransform(329.3,96.6,1,1,0,0,0,0.1,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADxEg9LADgIAAjg");
	this.shape_1.setTransform(329.1,48.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_2.setTransform(329.1,36.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_3.setTransform(329.1,12);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_4.setTransform(329.1,12);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_5.setTransform(329.1,48.5);

	// colors_nous2
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_6.setTransform(-62.6,61.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_7.setTransform(329.1,48.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_8.setTransform(329.1,60.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_9.setTransform(329.1,60.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF9900").s().p("Eg9IADwIAAnfMB6RAAAIAAHfg");
	this.shape_10.setTransform(329.1,96.7,1,1,0,0,0,0.2,-0.2);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.6,0,783.6,121);


   (lib.mc_bajamedia = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("1400", "bold 16px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 149;
	this.text.setTransform(-58.1,88.3+incremento);

	this.text_1 = new cjs.Text("BAJA EDAD MEDIA", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(328.8,85.7+incremento);

	this.text_2 = new cjs.Text("1500", "bold 16px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(712.2,87.5+incremento);

	// Capa 1
	this.text_3 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(329.5,49.1+incremento);

	this.text_4 = new cjs.Text("PROSA", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(329.5,24.6+incremento);

	this.text_5 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(329.5,0.8+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA9NADwMh6ZAAAIAAnfMB6ZAAAg");
	this.shape.setTransform(329.1,96.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADxEg9LADgIAAjg");
	this.shape_1.setTransform(329.1,48.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_2.setTransform(329.1,36.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_3.setTransform(329.1,12);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_4.setTransform(329.1,12);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_5.setTransform(329.1,48.5);

	// colors_nous2
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_6.setTransform(-62.6,61.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_7.setTransform(329.1,48.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_8.setTransform(329.1,60.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_9.setTransform(329.1,60.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#66FFFF").s().p("Eg9KADwIAAnfMB6UAAAIAAHfg");
	this.shape_10.setTransform(329.2,96.7,1,1,0,0,0,0.1,-0.2);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.6,0,783.5,121);

(lib.mc_neoclasicismo = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("1700", "bold 16px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 149;
	this.text.setTransform(-58.1,88.3+incremento);

	this.text_1 = new cjs.Text("NEOCLASICISMO", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(328.8,85.7+incremento);

	this.text_2 = new cjs.Text("1800", "bold 16px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(704.6,87.5+incremento);

	// Capa 1
	this.text_3 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(329.5,49.1+incremento);

	this.text_4 = new cjs.Text("PROSA", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(329.5,24.6+incremento);

	this.text_5 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(329.5,0.8+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("EA9NADwMh6ZAAAIAAnfMB6ZAAAg");
	this.shape.setTransform(329.2,96.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADxEg9LAAAIAADg");
	this.shape_1.setTransform(329.1,48.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_2.setTransform(329.1,36.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_3.setTransform(329.1,12);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_4.setTransform(329.1,12);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_5.setTransform(329.1,48.5);

	// colors_nous2
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_6.setTransform(-62.6,61.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_7.setTransform(329.1,48.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_8.setTransform(329.1,60.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_9.setTransform(329.1,60.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FF9900").s().p("Eg9MADwIAAnfMB6ZAAAIAAHfg");
	this.shape_10.setTransform(329.2,96.7,1,1,0,0,0,-0.1,-0.2);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.6,0,783.8,121);
   (lib.mc_anonima = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("1100", "bold 16px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 149;
	this.text.setTransform(-58.1,88.3+incremento);

	this.text_1 = new cjs.Text("ALTA EDAD MEDIA", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(328.8,85.7+incremento);

	this.text_2 = new cjs.Text("1250", "bold 16px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(712.2,87.5+incremento);

	// colors_nous
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF0000").s().p("Eg9JADsIAAnXMB6TAAAIAAHXg");
	this.shape.setTransform(329.2,96.5);

	// Capa 1
	this.text_3 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(329.5,49.1+incremento);

	this.text_4 = new cjs.Text("PROSA", "16px Verdana");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(329.5,24.6+incremento);

	this.text_5 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(329.5,0.8+incremento);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("EA9NADwMh6ZAAAIAAnfMB6ZAAAg");
	this.shape_1.setTransform(329,96.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_2.setTransform(-62.6,61.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_3.setTransform(329.1,48.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_4.setTransform(329.1,60.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_5.setTransform(329.1,60.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADx");
	this.shape_6.setTransform(329.1,48.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_7.setTransform(329.1,36.2);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_8.setTransform(329.1,12);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_9.setTransform(329.1,12);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_10.setTransform(329.1,48.5);

	this.addChild(this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.text_5,this.text_4,this.text_3,this.shape,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.7,0,783.6,120.7);


    (lib.informacion = function (texto) {
        this.initialize();
        this.capa=new cjs.Shape();
        this.capa.graphics.f("#FFFFFF").drawRect(0, 0, 950, 608);
        
        // Capa 1
        basicos(this, 0, 0, 0, 0, 1);
        var html = createDiv(texto, "Verdana", "16px", '790px', '400px', "20px", "185px", "left");
        this.texto = new cjs.DOMElement(html);
        html.style.backgroundColor="#FFFFFF";
            this.texto.setTransform(90, -582);
       

        this.cerrar.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });
        onResize();
        this.addChild( this.capa, this.logo,this.cerrar, this.texto);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
   (lib.mc_Intro = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("PRERENACIMIENTO", "15px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.setTransform(639,97.7+incremento);

	this.text_1 = new cjs.Text("ALTA EDAD MEDIA", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(11.9,97.7+incremento);

	this.text_2 = new cjs.Text("1400-1500", "bold 16px Verdana");
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(615.4,74.7+incremento);

	this.text_3 = new cjs.Text("1250 - 1400", "bold 16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.lineWidth = 149;
	this.text_3.setTransform(326.5,76.6+incremento);

	this.text_4 = new cjs.Text("1100-1250", "bold 16px Verdana");
	this.text_4.lineHeight = 18;
	this.text_4.lineWidth = 114;
	this.text_4.setTransform(-57.6,75.5+incremento);

	this.text_5 = new cjs.Text("BAJA EDAD MEDIA", "15px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 17;
	this.text_5.setTransform(326.9,97.7+incremento);

	// colors_nous2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AAAjrIAAHX");
	this.shape.setTransform(112.6,96.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AAAjqIAAHV");
	this.shape_1.setTransform(545.5,96.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF9900").s().p("AtqDtIAAnYIbVAAIAAHYg");
	this.shape_2.setTransform(633.2,96.5,1,1,0,0,0,0.2,0);

	// colors_nous
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("AtqDsIAAnXIbVAAIAAHXg");
	this.shape_3.setTransform(25.3,96.5);

	// Capa 1
	this.text_6 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 18;
	this.text_6.setTransform(329.5,49.1+incremento);

	this.text_7 = new cjs.Text("PROSA", "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 18;
	this.text_7.setTransform(329.5,24.6+incremento);

	this.text_8 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 18;
	this.text_8.setTransform(329.5,0.8+incremento);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("EA9NADwMh6ZAAAIAAnfMB6ZAAAg");
	this.shape_4.setTransform(329,96.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#66FFFF").s().p("Eg9MADwIAAnfMB6ZAAAIAAHfg");
	this.shape_5.setTransform(329,96.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_6.setTransform(-62.6,61.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_7.setTransform(329.1,48.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_8.setTransform(329.1,60.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_9.setTransform(329.1,60.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADx");
	this.shape_10.setTransform(329.1,48.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_11.setTransform(329.1,36.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_12.setTransform(329.1,12);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_13.setTransform(329.1,12);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_14.setTransform(329.1,48.5);

	this.addChild(this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.text_8,this.text_7,this.text_6,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.7,0,797.7,120.7);

(lib.mc_Intro1500 = function() {
	this.initialize();

	// textes
	this.text = new cjs.Text("NEOCLASICISMO", "15px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 17;
	this.text.setTransform(607.9,98.5+incremento);

	this.text_1 = new cjs.Text("RENACIMIENTO", "15px Verdana");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 17;
	this.text_1.setTransform(45.5,97+incremento);

	this.text_2 = new cjs.Text("1700-1800", "bold 16px Verdana");
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 116;
	this.text_2.setTransform(557.2,75.5+incremento);

	this.text_3 = new cjs.Text("1600-1700", "bold 16px Verdana");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 18;
	this.text_3.lineWidth = 149;
	this.text_3.setTransform(326.5,76.6+incremento);

	this.text_4 = new cjs.Text("1500 - 1600", "bold 16px Verdana");
	this.text_4.lineHeight = 18;
	this.text_4.lineWidth = 114;
	this.text_4.setTransform(-9.3,75.5+incremento);

	this.text_5 = new cjs.Text("BARROCO", "15px Verdana");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 17;
	this.text_5.setTransform(326.9,97.7+incremento);

	// colors_nous2
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).p("AAAjrIAAHX");
	this.shape.setTransform(179.9,96.6,1.385,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("AAAjqIAAHV");
	this.shape_1.setTransform(478.7,96.5,1.381,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FF9900").s().p("Ay4DtIAAnYMAlxAAAIAAHYg");
	this.shape_2.setTransform(599.9,96.5,1,1,0,0,0,0.3,0);

	// colors_nous
	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FF0000").s().p("Ay7DsIAAnXMAl3AAAIAAHXg");
	this.shape_3.setTransform(59,96.5);

	// Capa 1
	this.text_6 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 18;
	this.text_6.setTransform(329.5,49.1+incremento);

	this.text_7 = new cjs.Text("PROSA", "16px Verdana");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 18;
	this.text_7.setTransform(329.5,24.6+incremento);

	this.text_8 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 18;
	this.text_8.setTransform(329.5,0.8+incremento);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(1,1,1).p("EA9NADwMh6ZAAAIAAnfMB6ZAAAg");
	this.shape_4.setTransform(329,96.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#66FFFF").s().p("Eg9MADwIAAnfMB6ZAAAIAAHfg");
	this.shape_5.setTransform(329,96.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_6.setTransform(-62.6,61.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_7.setTransform(329.1,48.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_8.setTransform(329.1,60.8);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_9.setTransform(329.1,60.8);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADx");
	this.shape_10.setTransform(329.1,48.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_11.setTransform(329.1,36.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_12.setTransform(329.1,12);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_13.setTransform(329.1,12);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_14.setTransform(329.1,48.5);

	this.addChild(this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.text_8,this.text_7,this.text_6,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-62.7,0,783.6,120.7);

(lib.mc_Intro1900 = function() {
	this.initialize();

	// textes_nous
	this.text = new cjs.Text("Literatura de la democracia", "16px Verdana");
	this.text.lineHeight = 18;
	this.text.setTransform(486.4,144.4+incremento);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgngsIBOAsIhOAtg");
	this.shape.setTransform(149.5,134.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("A+OAAMA8dAAA");
	this.shape_1.setTransform(72.7,135,0.379,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("Ag3gtIBvAtIhvAtg");
	this.shape_2.setTransform(443.2,133.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("A2/AAMAt/AAA");
	this.shape_3.setTransform(314.9,133.9,0.831,1,0,0,0,-0.1,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgngtIBOAtIhOAtg");
	this.shape_4.setTransform(151.7,170.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("A+OAAMA8dAAA");
	this.shape_5.setTransform(95.5,170.5,0.273,1);

	this.text_1 = new cjs.Text("vanguardias", "16px Verdana");
	this.text_1.lineHeight = 18;
	this.text_1.setTransform(40.2,146.8+incremento);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgngtIBOAtIhOAtg");
	this.shape_6.setTransform(715.3,168);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("A+OAAMA8dAAA");
	this.shape_7.setTransform(585.1,168,0.654,1);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgngtIBPAtIhPAtg");
	this.shape_8.setTransform(48.1,96.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f().s("#000000").ss(1,1,1).p("A+OAAMA8dAAA");
	this.shape_9.setTransform(-8,96.7,0.273,1);

	this.text_2 = new cjs.Text("modernismo", "16px Verdana");
	this.text_2.lineHeight = 18;
	this.text_2.setTransform(-63.3,73+incremento);

	this.text_3 = new cjs.Text("Literatura de la dictadura", "16px Verdana");
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(219,109.6+incremento);

	this.text_4 = new cjs.Text("novecentismo", "16px Verdana");
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(29.4,113.9+incremento);

	// anys
	this.text_5 = new cjs.Text("hasta\nla \nactualidad", "bold 16px Verdana");
	this.text_5.textAlign = "right";
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(717,178+incremento);

	this.shape_10 = new cjs.Shape();
	this.shape_10 = new lib.Mapadebits1();
	this.shape_10.setTransform(596.3,126.5-50,1,0.993);

	this.shape_11 = new cjs.Shape();
	this.shape_11 = new lib.Mapadebits1();
	this.shape_11.setTransform(463.7,126-50,1,0.993);

	this.shape_12 = new cjs.Shape();
	this.shape_12 = new lib.Mapadebits1();
	this.shape_12.setTransform(328,124.9-50,1,0.993);

	this.shape_13 = new cjs.Shape();
	this.shape_13 = new lib.Mapadebits1();
	this.shape_13.setTransform(195.3,125.5-50,1,0.993);

	this.shape_14 = new cjs.Shape();
	this.shape_14 = new lib.Mapadebits1();
	this.shape_14.setTransform(59.3,125.4-50);

	this.text_6 = new cjs.Text("2000", "bold 16px Verdana");
	this.text_6.lineHeight = 18;
	this.text_6.setTransform(570.7,179+incremento);

	this.text_7 = new cjs.Text("1980", "bold 16px Verdana");
	this.text_7.lineHeight = 18;
	this.text_7.setTransform(438.9,179+incremento);

	this.text_8 = new cjs.Text("1960", "bold 16px Verdana");
	this.text_8.lineHeight = 18;
	this.text_8.setTransform(303.2,179+incremento);

	this.text_9 = new cjs.Text("1940", "bold 16px Verdana");
	this.text_9.lineHeight = 18;
	this.text_9.setTransform(168.7,179+incremento);

	this.text_10 = new cjs.Text("1920", "bold 16px Verdana");
	this.text_10.lineHeight = 18;
	this.text_10.setTransform(32.7,179+incremento);

	this.text_11 = new cjs.Text("1900", "bold 16px Verdana");
	this.text_11.lineHeight = 18;
	this.text_11.setTransform(-66.9,179+incremento);

	// Capa 1
	this.text_12 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 18;
	this.text_12.setTransform(329.5,49.1+incremento);

	this.text_13 = new cjs.Text("PROSA", "16px Verdana");
	this.text_13.textAlign = "center";
	this.text_13.lineHeight = 18;
	this.text_13.setTransform(329.5,24.6+incremento);

	this.text_14 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_14.textAlign = "center";
	this.text_14.lineHeight = 18;
	this.text_14.setTransform(329.5,0.8+incremento);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("EA9NAIMMh6ZAAAIAAwXMB6ZAAAg");
	this.shape_15.setTransform(329,125.6);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#66FFFF").s().p("Eg9MAIMIAAwXMB6ZAAAIAAQXg");
	this.shape_16.setTransform(329,125.6);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_17.setTransform(-62.6,61.2);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_18.setTransform(329.1,48.5);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_19.setTransform(329.1,60.8);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_20.setTransform(329.1,60.8);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADx");
	this.shape_21.setTransform(329.1,48.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_22.setTransform(329.1,36.2);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_23.setTransform(329.1,12);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_24.setTransform(329.1,12);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_25.setTransform(329.1,48.5);

	this.addChild(this.shape_25,this.shape_24,this.shape_23,this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.text_14,this.text_13,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.shape_14,this.shape_13,this.shape_12,this.shape_11,this.shape_10,this.text_5,this.text_4,this.text_3,this.text_2,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.text_1,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-66.9,0,788,244.3);

(lib.mc_Intro1800 = function() {
	this.initialize();

	// textes_nous
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgngtIBOAtIhOAtg");
	this.shape.setTransform(715.3,168);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(1,1,1).p("A+OAAMA8dAAA");
	this.shape_1.setTransform(609.2,168,0.53,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgngtIBPAtIhPAtg");
	this.shape_2.setTransform(714.6,94.2);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(1,1,1).p("A+OAAMA8dAAA");
	this.shape_3.setTransform(644.6,94.2,0.344,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgmgtIBNAtIhNAtg");
	this.shape_4.setTransform(545.9,143.9);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(1,1,1).p("A+OAAMA8dAAA");
	this.shape_5.setTransform(438.6,143.9,0.536,1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgngsIBPAsIhPAtg");
	this.shape_6.setTransform(328.1,92.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f().s("#000000").ss(1,1,1).p("A+OAAMA8dAAA");
	this.shape_7.setTransform(130.9,92.7);

	this.text = new cjs.Text("modernismo", "16px Verdana");
	this.text.lineHeight = 18;
	this.text.setTransform(574.6,146+incremento);

	this.text_1 = new cjs.Text("naturalismo", "16px Verdana");
	this.text_1.lineHeight = 18;
	this.text_1.setTransform(575.3,71.4+incremento);

	this.text_2 = new cjs.Text("realismo", "16px Verdana");
	this.text_2.lineHeight = 18;
	this.text_2.setTransform(412,119.6+incremento);

	this.text_3 = new cjs.Text("romanticismo", "16px Verdana");
	this.text_3.lineHeight = 18;
	this.text_3.setTransform(103.4,70.9+incremento);

	// anys
	this.shape_8 = new cjs.Shape();
	this.shape_8 = new lib.Mapadebits1();
	this.shape_8.setTransform(573.7,125.6-50,1,0.993);

	this.shape_9 = new cjs.Shape();
	this.shape_9 = new lib.Mapadebits1();
	this.shape_9.setTransform(411.7,125.6-50,1,0.993);

	this.shape_10 = new cjs.Shape();
	this.shape_10 = new lib.Mapadebits1();
	this.shape_10.setTransform(249.3,125.5-50,1,0.993);

	this.shape_11 = new cjs.Shape();
	this.shape_11 = new lib.Mapadebits1();
	this.shape_11.setTransform(87.3,125.4-50);

	this.text_4 = new cjs.Text("1900", "bold 16px Verdana");
	this.text_4.lineHeight = 18;
	this.text_4.setTransform(674.7,179+incremento);

	this.text_5 = new cjs.Text("1880", "bold 16px Verdana");
	this.text_5.lineHeight = 18;
	this.text_5.setTransform(551.9,179+incremento);

	this.text_6 = new cjs.Text("1860", "bold 16px Verdana");
	this.text_6.lineHeight = 18;
	this.text_6.setTransform(390.2,179+incremento);

	this.text_7 = new cjs.Text("1840", "bold 16px Verdana");
	this.text_7.lineHeight = 18;
	this.text_7.setTransform(225.7,179+incremento);

	this.text_8 = new cjs.Text("1820", "bold 16px Verdana");
	this.text_8.lineHeight = 18;
	this.text_8.setTransform(64.7,179+incremento);

	this.text_9 = new cjs.Text("1800", "bold 16px Verdana");
	this.text_9.lineHeight = 18;
	this.text_9.setTransform(-66.9,179+incremento);

	// Capa 1
	this.text_10 = new cjs.Text("POESÍA", "16px Verdana");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 18;
	this.text_10.setTransform(329.5,49.1+incremento);

	this.text_11 = new cjs.Text("PROSA", "16px Verdana");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 18;
	this.text_11.setTransform(329.5,24.6+incremento);

	this.text_12 = new cjs.Text("TEATRO", "16px Verdana");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 18;
	this.text_12.setTransform(329.5,0.8+incremento);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f().s("#000000").ss(1,1,1).p("EA9NAIMMh6ZAAAIAAwXMB6ZAAAg");
	this.shape_12.setTransform(329,125.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#66FFFF").s().p("Eg9MAIMIAAwXMB6ZAAAIAAQXg");
	this.shape_13.setTransform(329,125.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f().s("#000000").ss(1,1,1).p("AAAiAIAAEB");
	this.shape_14.setTransform(-62.6,61.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_15.setTransform(329.1,48.5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f().s("#000000").ss(0.1,1,1).p("EA9NgB3IAADvMh6ZAAAIAAjv");
	this.shape_16.setTransform(329.1,60.8);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#C398BF").s().p("Eg9MAB4IAAjvMB6ZAAAIAADvg");
	this.shape_17.setTransform(329.1,60.8);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f().s("#000000").ss(1,1,1).p("Eg9LAAAIAAjwMB6XAAAIAADwIAADx");
	this.shape_18.setTransform(329.1,48.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFF99").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_19.setTransform(329.1,36.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f().s("#000000").ss(1,1,1).p("EA9MAB4Mh6XAAAIAAjvMB6XAAAg");
	this.shape_20.setTransform(329.1,12);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#8FBF67").s().p("Eg9LAB4IAAjvMB6XAAAIAADvg");
	this.shape_21.setTransform(329.1,12);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f().s("#000000").ss(1,1,1).p("EA9MAAAMh6XAAA");
	this.shape_22.setTransform(329.1,48.5);

	this.addChild(this.shape_22,this.shape_21,this.shape_20,this.shape_19,this.shape_18,this.shape_17,this.shape_16,this.shape_15,this.shape_14,this.shape_13,this.shape_12,this.text_12,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.text_3,this.text_2,this.text_1,this.text,this.shape_7,this.shape_6,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-66.9,0,791.4,202.4);

   (lib._0005UN01 = function() {
	this.initialize(img._0005UN01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,308);


(lib._000JP801 = function() {
	this.initialize(img._000JP801);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,308);


(lib._001ABW01 = function() {
	this.initialize(img._001ABW01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,308);


(lib.shutterstock_83187919 = function() {
	this.initialize(img.shutterstock_83187919);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,500,308);

(lib.btn_04 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['titulo4_1'], "19px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 278;
	this.text.setTransform(121.1,156);

	this.instance = new lib.shutterstock_83187919();
	this.instance.setTransform(0,0,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("A0aMrIAA5VMAo1AAAIAAZVg");
	this.shape.setTransform(125.5,75.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).to({state:[{t:this.instance},{t:this.shape},{t:this.text}]},1).to({state:[{t:this.instance},{t:this.text}]},1).to({state:[{t:this.instance},{t:this.text}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17.8,0,282,184.3);


(lib.btn_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['titulo3_1'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 244;
	this.text.setTransform(122,156);

	this.instance = new lib._0005UN01();
	this.instance.setTransform(0,0,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("A0aMrIAA5VMAo1AAAIAAZVg");
	this.shape.setTransform(125.5,75.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).to({state:[{t:this.instance},{t:this.text},{t:this.shape}]},1).to({state:[{t:this.instance},{t:this.text}]},1).to({state:[{t:this.instance},{t:this.text}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,250,184.3);


(lib.btn_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text(txt['titulo2_1'], "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 244;
	this.text.setTransform(123.2,157);

	this.instance = new lib._001ABW01();
	this.instance.setTransform(0,0,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("A0aMrIAA5VMAo1AAAIAAZVg");
	this.shape.setTransform(125.5,75.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).to({state:[{t:this.instance},{t:this.text},{t:this.shape}]},1).to({state:[{t:this.instance},{t:this.text}]},1).to({state:[{t:this.instance},{t:this.text}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,250,185.3);

 (lib.popup = function (texto,alto) {
        this.initialize();
 alto=alto || 1.3;
        // Capa 1
         var html = createDiv(texto, "Verdana", "20px", '580px', '150px', "20px", "115px", "left", 'txtpopup');
        this.txt_popup = new cjs.DOMElement(html);

        this.txt_popup.setTransform(200, -390);

        this.btn_salir = new lib.btn_cerrar();
        this.btn_salir.setTransform(779.6, 218.5, 0.8, 0.8);
        new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        this.btn_salir.on("click", function (evt) {
            this.parent.visible = false;
            popupon = false;
        });

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-215.15, -77.8, 430.3, 155.6, 10);
        this.shape.setTransform(481.8, 280.6+(alto-1)*80,1.5,alto);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(255,255,255,0.694)").s().p("EhEzArZMAAAhWxMCJnAAAMAAABWxg");
        this.shape_1.setTransform(475, 304, 1.078, 1.094);

        this.addChild(this.shape_1, this.shape, this.instance, this.btn_salir, this.txt_popup);
        onResize();
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    
(lib.btn_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("1100 - 1500", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 244;
	this.text.setTransform(123,157);

	this.instance = new lib._000JP801();
	this.instance.setTransform(0,0,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("A0aMrIAA5VMAo1AAAIAAZVg");
	this.shape.setTransform(125.5,75.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text}]}).to({state:[{t:this.instance},{t:this.text},{t:this.shape}]},1).to({state:[{t:this.instance},{t:this.text}]},1).to({state:[{t:this.instance},{t:this.text}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,250,185.3);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

 (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
    
    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}