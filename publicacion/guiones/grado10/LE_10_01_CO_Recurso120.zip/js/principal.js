(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 0,0,1,0,0);
        titulo1(this, txt['titulo']);
        this.imagen = new lib.boton_1();
        this.imagen.setTransform(750.5,294.2,1,1,0,0,0,435.2,182.8);
	new cjs.ButtonHelper(this.imagen, 0, 1, 2, false, new lib.boton_1(), 3);

          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
       this.imagen.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        
        this.addChild(this.logo, this.titulo, this.siguiente, this.imagen);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
      (lib.frame2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,0,0);
       
         var html = createDiv(txt['txt_01_01'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto1=new lib.fadeText(html,0);
        this.texto1.setTransform(100,-520);
        var flecha=new lib.flecha();
        this.flechaA=new lib.fadeElement(flecha,25);
        this.flechaA.setTransform(300.1,193.2,1,1,0,0,0,5.7,36.8);
        html = createDiv(txt['txt_01_02'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto2=new lib.fadeText(html,50);
        this.texto2.setTransform(180,-380);

        html = createDiv(txt['txt_01_03'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto3=new lib.fadeText(html,70);
        this.texto3.setTransform(100,-180);


          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      
        
        this.addChild(this.logo,  this.home,this.siguiente, this.imagen,this.texto1,this.flechaA,this.texto2,this.texto3);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
      (lib.frame3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
       
         var html = createDiv(txt['txt_02_01'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto1=new lib.fadeText(html,0);
        this.texto1.setTransform(100,-520);

          html = createDiv(txt['txt_02_04'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto2=new lib.fadeText(html,22);
        this.texto2.setTransform(100,-280);

        html = createDiv(txt['txt_02_02'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto3=new lib.fadeText(html,45);
        this.texto3.setTransform(100,-520);

html = createDiv(txt['txt_02_03'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto4=new lib.fadeText(html,65);
        this.texto4.setTransform(150,-440);

  html = createDiv(txt['txt_02_05'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto5=new lib.fadeText(html,85);
        this.texto5.setTransform(100,-280);
        
         html = createDiv(txt['txt_02_06'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto6=new lib.fadeText(html,105);
        this.texto6.setTransform(150,-200);
        
          this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      
        
        this.addChild(this.logo,this.home,this.anterior,  this.siguiente, this.imagen,this.texto1,this.texto2,this.texto3,this.texto4,this.texto5,this.texto6);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame4 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
       
         var html = createDiv(txt['txt_03_01'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto1=new lib.fadeText(html,0);
        this.texto1.setTransform(100,-520);

          html = createDiv(txt['txt_03_02'], "Verdana", "16px",  '800px', '100px', "20px", "185px", "left");
        this.texto2=new lib.fadeText(html,22);
        this.texto2.setTransform(100,-490);

        html = createDiv(txt['txt_03_03'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto3=new lib.fadeText(html,45);
        this.texto3.setTransform(100,-330);
        html = createDiv(txt['txt_03_03b'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto4=new lib.fadeText(html,65);
        this.texto4.setTransform(100,-330);
        
         var flecha=new lib.flechacorta();
        this.flecha=new lib.fadeElement(flecha,85);
	this.flecha.setTransform(462.7,250.6,1,0.826,180,0,0,5.7,36.7);

        html = createDiv(txt['txt_03_04'], "Verdana", "20px",  '600px', '60px', "20px", "185px", "left");
        html.setAttribute("class","dashed");
        this.texto5=new lib.fadeText(html,105);
        this.texto5.setTransform(120,-440);

        
         html = createDiv(txt['txt_03_05'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto6=new lib.fadeText(html,125);
        this.texto6.setTransform(120,-200);
        
          this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      
        
        this.addChild(this.logo,this.home,this.anterior,  this.siguiente, this.imagen,this.texto1,this.texto2,this.texto3,this.flecha,this.texto4,this.texto5,this.texto6);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame5 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
       
         var html = createDiv(txt['txt_04_02'], "Verdana", "20px",  '400px', '100px', "20px", "185px", "left");
        this.texto1=new lib.fadeText(html,0);
        this.texto1.setTransform(100,-420);

        html = createDiv(txt['txt_04_03'], "Verdana", "20px",  '400px', '100px', "20px", "185px", "left");
        this.texto2=new lib.fadeText(html,25);
        this.texto2.setTransform(450,-420);

        html = createDiv(txt['txt_04_01'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto3=new lib.fadeText(html,50);
        this.texto3.setTransform(100,-520);

  this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
          this.home.on("click", function (evt) {
            putStage(new lib.frame6());
        });
      
        
        this.addChild(this.logo,  this.home,this.siguiente,this.anterior, this.imagen,this.texto1,this.texto2,this.texto3);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame6 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
       
         var html = createDiv(txt['txt_05_01'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto1=new lib.fadeText(html,0);
        this.texto1.setTransform(100,-520);

          html = createDiv(txt['txt_05_02'], "Verdana", "16px",  '800px', '100px', "20px", "185px", "left");
        this.texto2=new lib.fadeText(html,22);
        this.texto2.setTransform(100,-490);

        html = createDiv(txt['txt_05_03'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto3=new lib.fadeText(html,45);
        this.texto3.setTransform(100,-430);

        html = createDiv(txt['txt_05_04'], "Verdana", "20px",  '600px', '60px', "20px", "185px", "left");
        this.texto5=new lib.fadeText(html,65);
        this.texto5.setTransform(120,-360);

        
         html = createDiv(txt['txt_05_05'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto6=new lib.fadeText(html,85);
        this.texto6.setTransform(100,-180);
        
          this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      var imagen = new lib.IMG_05_01();
        this.imagen=new lib.fadeElement(imagen,105);
	this.imagen.setTransform(1015.6,573.5,0.326,0.326,0,0,0,435.1,182.8);
        
         html = createDiv(txt['txt_05_06'], "Verdana", "14px",  '250px', '20px', "20px", "185px", "right");
        this.texto7=new lib.fadeText(html,105);
        this.texto7.setTransform(620,-100);
        
        this.addChild(this.logo,this.home,this.anterior,  this.siguiente, this.imagen,this.texto1,this.texto2,this.texto3,this.flecha,this.texto4,this.texto5,this.texto6,this.texto7);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
     (lib.frame7 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,1,0);
       
         var html = createDiv(txt['txt_06_01'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto1=new lib.fadeText(html,0);
        this.texto1.setTransform(100,-520);

          html = createDiv(txt['txt_06_02'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto2=new lib.fadeText(html,22);
        this.texto2.setTransform(100,-390);

        html = createDiv(txt['txt_06_03'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto3=new lib.fadeText(html,45);
        this.texto3.setTransform(100,-260);

           this.informacion.on("click", function (evt) {
            putStage(new lib.frame7b());
        });
          this.anterior.on("click", function (evt) {
            putStage(new lib.frame6());
        });
          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame8());
        });
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      
        
        this.addChild(this.logo,this.home,this.anterior,  this.siguiente, this.imagen,this.texto1,this.texto2,this.texto3,this.informacion);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame7b = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 0,0,0,0,1);
       
         var html = createDiv(txt['txt_popup_info_01'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto1=new cjs.DOMElement(html);
        this.texto1.setTransform(100,-520);

          html = createDiv(txt['txt_popup_info_02'], "Verdana", "20px",  '500px', '100px', "20px", "185px", "left");
        this.texto2=new cjs.DOMElement(html);
        this.texto2.setTransform(250,-430);

        html = createDiv(txt['txt_popup_info_03'], "Verdana", "20px",  '500px', '100px', "20px", "185px", "left");
        this.texto3=new cjs.DOMElement(html);
        this.texto3.setTransform(340,-160);

           this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });
      
        
        this.addChild(this.logo,this.cerrar,this.texto1,this.texto2,this.texto3);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame8 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
       
         var html = createDiv(txt['txt_07_01'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto1=new lib.fadeText(html,0);
        this.texto1.setTransform(100,-520);

          html = createDiv(txt['txt_07_02'], "Verdana", "16px",  '800px', '100px', "20px", "185px", "left");
        this.texto2=new lib.fadeText(html,22);
        this.texto2.setTransform(100,-490);

        html = createDiv(txt['txt_07_03'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto3=new lib.fadeText(html,45);
        this.texto3.setTransform(100,-440);

        html = createDiv(txt['txt_07_04'], "Verdana", "20px",  '800px', '60px', "20px", "185px", "left");
        this.texto4=new lib.fadeText(html,65);
        this.texto4.setTransform(100,-340);

        
          this.anterior.on("click", function (evt) {
            putStage(new lib.frame7());
        });
          this.siguiente.on("click", function (evt) {
            putStage(new lib.frame9());
        });
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      
        
        this.addChild(this.logo,this.home,this.anterior,  this.siguiente, this.imagen,this.texto1,this.texto2,this.texto3,this.flecha,this.texto4);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    (lib.frame9 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,0,0);
       
         var html = createDiv(txt['txt_08_01'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto1=new lib.fadeText(html,0);
        this.texto1.setTransform(100,-520);


        html = createDiv(txt['txt_08_02'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto3=new lib.fadeText(html,25);
        this.texto3.setTransform(100,-440);

        html = createDiv(txt['txt_08_03'], "Verdana", "20px",  '800px', '60px', "20px", "185px", "left");
        this.texto4=new lib.fadeText(html,45);
        this.texto4.setTransform(100,-290);

               this.practica = new lib.btn_practica(txt['txt_practica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.practica.on("click", function (evt) {
            putStage(new lib.frame10());
        });

        
          this.anterior.on("click", function (evt) {
            putStage(new lib.frame8());
        });
        
          this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      
        
        this.addChild(this.logo,this.home,  this.anterior, this.imagen,this.texto1,this.texto3,this.flecha,this.texto4,this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame10 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 0,0,0,0,1);
       
         var html = createDiv(txt['txt_practica_01'], "Verdana", "20px",  '800px', '100px', "20px", "185px", "left");
        this.texto1=new lib.fadeText(html,0);
        this.texto1.setTransform(100,-560);

        html = createDiv(txt['txt_practica_04'], "Verdana", "16px",  '800px', '100px', "20px", "185px", "left");
        this.texto2=new lib.fadeText(html,25);
        this.texto2.setTransform(250,-490);

        html = createDiv(txt['txt_practica_02'], "Verdana", "16px",  '800px', '100px', "20px", "185px", "left");
        this.texto3=new lib.fadeText(html,25);
        this.texto3.setTransform(330,-490);

        html = createDiv(txt['txt_practica_05'], "Verdana", "16px",  '800px', '100px', "20px", "185px", "left");
        this.texto5=new lib.fadeText(html,45);
        this.texto5.setTransform(250,-290);

        html = createDiv(txt['txt_practica_03'], "Verdana", "16px",  '800px', '60px', "20px", "185px", "left");
        this.texto4=new lib.fadeText(html,45);
        this.texto4.setTransform(330,-290);

               this.practica = new lib.btn_practica(txt['txt_solucion']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.practica.on("click", function (evt) {
            putStage(new lib.frame11());
        });

        
          this.cerrar.on("click", function (evt) {
            putStage(new lib.frame9());
        });
      
        
        this.addChild(this.logo,this.cerrar,this.texto1,this.texto2,this.texto3,this.texto4,this.practica,this.texto5);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
     (lib.frame11 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 0,1,0,0,1);
       

        html = createDiv(txt['txt_solucion_01'], "Verdana", "20px",  '200px', '100px', "20px", "185px", "right");
        this.texto1=new cjs.DOMElement(html);
        this.texto1.setTransform(120,-460);

                 html = createDiv(txt['txt_solucion_01b'], "Verdana", "14px",  '300px', '100px', "20px", "185px", "right");
        this.texto1b=new cjs.DOMElement(html);
        this.texto1b.setTransform(10,-400);


        html = createDiv(txt['txt_solucion_02'], "Verdana", "20px",  '200px', '100px', "20px", "185px", "right");
        this.texto6=new cjs.DOMElement(html);
        this.texto6.setTransform(120,-260);

                 html = createDiv(txt['txt_solucion_02b'], "Verdana", "14px",  '300px', '100px', "20px", "185px", "right");
        this.texto6b=new cjs.DOMElement(html);
        this.texto6b.setTransform(10,-200);


        html = createDiv(txt['txt_practica_04'], "Verdana", "16px",  '500px', '100px', "20px", "185px", "left");
        html.style.color='#999999';
        this.texto2=new cjs.DOMElement(html);
        this.texto2.setTransform(250,-490);

        html = createDiv(txt['txt_practica_02'], "Verdana", "16px",  '500px', '100px', "20px", "185px", "left");
        this.texto3=new cjs.DOMElement(html);
        this.texto3.setTransform(330,-490);

        html = createDiv(txt['txt_practica_05'], "Verdana", "16px",  '500px', '100px', "20px", "185px", "left");
        html.style.color='#999999';
        this.texto5=new cjs.DOMElement(html);
        this.texto5.setTransform(250,-290);

        html = createDiv(txt['txt_practica_03'], "Verdana", "16px",  '500px', '60px', "20px", "185px", "left");
        this.texto4=new cjs.DOMElement(html);
        this.texto4.setTransform(330,-290);

               this.practica = new lib.btn_practica(txt['txt_solucion']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.anterior.on("click", function (evt) {
            putStage(new lib.frame10());
        });

        
          this.cerrar.on("click", function (evt) {
            putStage(new lib.frame9());
        });
      
        
        this.addChild(this.logo,this.cerrar,this.texto1,this.texto2,this.texto3,this.texto4,this.anterior,this.texto5,this.texto1b,this.texto6,this.texto6b);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto,size) {
        size=size||'25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130+ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }


    
     (lib.fadeText = function (textohtml,espera,mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});
        this.texto=new cjs.DOMElement(textohtml);
        this.texto.alpha=0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({ alpha: 1}, 20).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
     (lib.fadeElement = function (elemento,espera,mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha=0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({ alpha: 1}, 20).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

(lib.btn_practica = function (texto,mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

(lib.CdP_Practica = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape.setTransform(65,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape_1.setTransform(65,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-65,-15,130,30,6);
	this.shape_2.setTransform(65,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,130,30);
    (lib.LC_09_04_01 = function() {
	this.initialize(img.LC_09_04_01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,695,768);
(lib.IMG_05_01 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.LC_09_04_01();
	this.instance.setTransform(-694.9,-767.9);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(-694.9,-767.9,695,768);

(lib.flechacorta = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag3g6IBvAEIg6Bxg");
	this.shape.setTransform(5.7,41.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AAACzIAAll");
	this.shape_1.setTransform(5.4,18);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,11.3,47.6);


(lib.flecha = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("Ag3g6IBvAEIg6Bxg");
	this.shape.setTransform(5.7,66.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AAAEwIAApf");
	this.shape_1.setTransform(5.4,30.4);

	this.addChild(this.shape_1,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,60.7,11.3,11.9);

(lib.boton_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.4)").s().dr(-430,-190,860,380);
	this.shape.setTransform(179,197.5,0.416,1.04,0,0,0,-0.1,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("rgba(255,255,255,0.4)").s().p("A79e3MAAAg9tMA37AAAMAAAA9tg");
	this.shape_1.setTransform(179,197.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[]},1).to({state:[{t:this.shape_1}]},1).wait(1));

	// Capa 1
	this.instance = new lib.mosaico_01();
	this.instance.setTransform(85.8,75.8,0.798,0.798,0,0,0,107.5,95);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({_off:true},3).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,357.7,394.9);

(lib.mosaico_01 = function() {
	this.initialize();

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,1,1).dr(-107.5,-81,215,162);
	this.shape.setTransform(224.5,248,2.084,3.05);

	// Capa 1 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	mask.graphics.p("EgjAgmqMBGCAAAMAAABNVMhGCAAAg");
	mask.setTransform(224.2,247.5);

	// Capa 2
	this.instance = new lib.LC_09_04_01();
	this.instance.setTransform(0,0,0.648,0.648);

	this.instance.mask = mask;

	this.addChild(this.instance,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,450.3,497.6);


    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}