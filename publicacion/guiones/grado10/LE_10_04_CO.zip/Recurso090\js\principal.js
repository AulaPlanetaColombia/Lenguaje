(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 1, 0, 0);
        titulo1(this, txt['titol']);

        this.btn_imatge = new lib.btn_imatge();
        this.btn_imatge.setTransform(475.1, 339, 1, 1, 0, 0, 0, 262.3, 182.5);
        new cjs.ButtonHelper(this.btn_imatge, 0, 1, 2, false, new lib.btn_imatge(), 3);


        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.btn_imatge.on("click", function (evt) {
            putStage(new lib.frame2());
        });

        this.addChild(this.logo, this.titulo, this.siguiente, this.btn_imatge);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 1, 0, 0, 1);
        titulo2(this, txt['titol_01']);

        var flecha = new lib.mc_ImatgeSol();
    
        this.instance_1 = new lib.fadeElement(flecha, 25);
        this.instance_1.setTransform(469.4, 338.7, 1, 1, 0, 0, 0, 224, 182.5);

        this.audioplay.on("click", function (evt) {
            reproductor = cjs.Sound.play("misonido");
            this.visible = false;
            this.parent.audiopause.visible = true;
        });

        this.audiopause.on("click", function (evt) {
            if(window.reproductor!==undefined)
            reproductor.stop();
            this.visible = false;
            this.parent.audioplay.visible = true;
        });

        this.siguiente.on("click", function (evt) {
            if(window.reproductor!==undefined)
            reproductor.stop();
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
             if(window.reproductor!==undefined) reproductor.stop();
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.siguiente, this.audioplay, this.audiopause, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_02']);

  //Fade text y element
    var html = createDiv(txt['txt_poema_01'], "Verdana", "16px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    
     var flecha = new lib.mc_ImatgePosta();
    
        this.instance_1 = new lib.fadeElement(flecha, 25);
    	
	this.instance_1.setTransform(660.6,232.8,1,1,0,0,0,117,100);

 var html = createDiv(txt['txt_pregunta_01'], "Verdana", "20px", '390px', '100px', "20px", "185px", "center");
    this.texto2 = new lib.fadeText(html, 45);
    this.texto2.setTransform(490, -270);
    
   
 var flecha = new lib.preguntas1();
    
        this.instance_2 = new lib.fadeElement(flecha, 65);
    	
	this.instance_2.setTransform(30,-60);
	
        
        this.anterior.on("click", function (evt) {
            if (popupon) return;
            putStage(new lib.frame2());
        });
        this.siguiente.on("click", function (evt) {
            if (popupon) return;
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            if (popupon) return;
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.texto1,this.instance_1,this.instance_2,this.texto2 );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_03']);

  var html = createDiv(txt['txt_poema_02'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    
     var flecha = new lib.mc_ImatgePosta();
    
        this.instance_1 = new lib.fadeElement(flecha, 25);
    	
	this.instance_1.setTransform(660.6,232.8,1,1,0,0,0,117,100);

 var html = createDiv(txt['txt_pregunta_02'], "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
    this.texto2 = new lib.fadeText(html, 45);
    this.texto2.setTransform(100, -250);
    
   
 var flecha = new lib.preguntas2();
    
        this.instance_2 = new lib.fadeElement(flecha, 65);
    	
	this.instance_2.setTransform(30,-60);
        
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.texto1,this.instance_1,this.instance_2,this.texto2 );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5 = function () {
        this.initialize();
        clearTexts();



   basicos(this, 1, 1, 1, 0, 0, 1);
        titulo2(this, txt['titol_04']);

        var flecha = new lib.mc_ImatgeGolondrinas();
    
        this.instance_1 = new lib.fadeElement(flecha, 25);
        this.instance_1.setTransform(661.4,236.7,1,1,0,0,0,117,100);

        this.audioplay.on("click", function (evt) {
            reproductor = cjs.Sound.play("misonido2");
            this.visible = false;
            this.parent.audiopause.visible = true;
        });

        this.audiopause.on("click", function (evt) {
            if(window.reproductor!==undefined)
            reproductor.stop();
            this.visible = false;
            this.parent.audioplay.visible = true;
        });
        
        this.anterior.on("click", function (evt) {
              if(window.reproductor!==undefined)
            reproductor.stop();
            putStage(new lib.frame4());
        });
          this.siguiente.on("click", function (evt) {
              if(window.reproductor!==undefined)
            reproductor.stop();
            putStage(new lib.frame6());
        });
        this.home.on("click", function (evt) {
              if(window.reproductor!==undefined)
            reproductor.stop();
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.siguiente, this.audioplay, this.audiopause, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame6 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_05']);

  //Fade text y element
    var html = createDiv(txt['txt_poema_03'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -500);
    
     var flecha = new lib.mc_ImatgeOrenetas();
    
        this.instance_1 = new lib.fadeElement(flecha, 25);
    	
	this.instance_1.setTransform(665.6,192.8,1,1,0,0,0,117,100);

 var html = createDiv(txt['txt_pregunta_03'], "Verdana", "20px", '390px', '100px', "20px", "185px", "center");
    this.texto2 = new lib.fadeText(html, 45);
    this.texto2.setTransform(490, -220);
    
   
 var flecha = new lib.preguntas3();
    
        this.instance_2 = new lib.fadeElement(flecha, 65);
    	
	this.instance_2.setTransform(30,-60);
	
        
        this.anterior.on("click", function (evt) {
            if (popupon) return;
            putStage(new lib.frame5());
        });
        this.siguiente.on("click", function (evt) {
            if (popupon) return;
            putStage(new lib.frame7());
        });
        this.home.on("click", function (evt) {
            if (popupon) return;
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.texto1,this.instance_1,this.instance_2,this.texto2 );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame7 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        titulo2(this, txt['titol_06']);

  //Fade text y element
    var html = createDiv(txt['txt_poema_04'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    html.style.lineHeight="160%";
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -500);
    
     var flecha = new lib.mc_ImatgeOrenetas2();
    
        this.instance_1 = new lib.fadeElement(flecha, 25);
    	
	this.instance_1.setTransform(665.6,192.8,1,1,0,0,0,117,100);

 var html = createDiv(txt['txt_pregunta_04'], "Verdana", "20px", '390px', '100px', "20px", "185px", "center");
 
    this.texto2 = new lib.fadeText(html, 45);
    this.texto2.setTransform(490, -220);
    
   
 var flecha = new lib.preguntas4();
    
        this.instance_2 = new lib.fadeElement(flecha, 65);
    	
	this.instance_2.setTransform(30,-60);
	
        
        this.anterior.on("click", function (evt) {
            if (popupon) return;
            putStage(new lib.frame6());
        });
        this.siguiente.on("click", function (evt) {
            if (popupon) return;
            putStage(new lib.frame8());
        });
        this.home.on("click", function (evt) {
            if (popupon) return;
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior, this.siguiente, this.texto1,this.instance_1,this.instance_2,this.texto2 );
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame8 = function () {
        this.initialize();
        clearTexts();



   basicos(this, 1, 1, 1, 0, 0, 1);
        titulo2(this, txt['titol_07']);

        var flecha = new lib.mc_ImatgeFaro();
    
        this.instance_1 = new lib.fadeElement(flecha, 25);
        this.instance_1.setTransform(660.6,237.6,1,1,0,0,0,117,100);
 var html = createDiv(txt['txt_pregunta_05'], "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
 
    this.texto2 = new lib.fadeText(html, 45);
    this.texto2.setTransform(100, -200);
    
      
 var flecha = new lib.preguntas5();
    
        this.instance_2 = new lib.fadeElement(flecha, 65);
    	
	this.instance_2.setTransform(20,-20);
	
        
        this.audioplay.on("click", function (evt) {
            reproductor = cjs.Sound.play("misonido3");
            this.visible = false;
            this.parent.audiopause.visible = true;
        });

        this.audiopause.on("click", function (evt) {
            if(window.reproductor!==undefined)
            reproductor.stop();
            this.visible = false;
            this.parent.audioplay.visible = true;
        });
        
        this.anterior.on("click", function (evt) {
              if(window.reproductor!==undefined)
            reproductor.stop();
            putStage(new lib.frame7());
        });
          this.siguiente.on("click", function (evt) {
              if(window.reproductor!==undefined)
            reproductor.stop();
            putStage(new lib.frame9());
        });
        this.home.on("click", function (evt) {
              if(window.reproductor!==undefined)
            reproductor.stop();
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.siguiente, this.audioplay, this.audiopause, this.instance_1, this.instance_2,this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

(lib.frame9 = function () {
        this.initialize();
        clearTexts();



   basicos(this, 1, 1, 0, 0, 0, 0);
        titulo2(this, txt['titol_08']);

        var flecha = new lib.mc_ImatgeRayo();
    
        this.instance_1 = new lib.fadeElement(flecha, 25);
        this.instance_1.setTransform(660.6,237.6,1,1,0,0,0,117,100);
 var html = createDiv(txt['txt_pregunta_06'], "Verdana", "20px", '770px', '100px', "20px", "185px", "center");
 
    this.texto2 = new lib.fadeText(html, 45);
    this.texto2.setTransform(100, -200);
    
      
 var flecha = new lib.preguntas6();
    
        this.instance_2 = new lib.fadeElement(flecha, 65);
    	
	this.instance_2.setTransform(10,-20);
	
       
        
        this.anterior.on("click", function (evt) {
             
            putStage(new lib.frame7());
        });
        
        this.home.on("click", function (evt) {
            
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.anterior,this.siguiente, this.audioplay, this.audiopause, this.instance_1, this.instance_2,this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130 + ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(190.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(167, 578, 1.44, 1.44);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(167, 578, 1.44, 1.44);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }*/
    
 
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 578, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(232, 578, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }

(lib.preguntas3 = function () {
        this.initialize();

         this.txt_incorrecto_1 = new cjs.Text(txt['txt_incorrecto_4'], "bold 16px Arial");
	this.txt_incorrecto_1.textAlign = "center";
	this.txt_incorrecto_1.lineHeight = 18;
	this.txt_incorrecto_1.lineWidth = 110;
	this.txt_incorrecto_1.setTransform(742.4,504.7+incremento);

	this.mc_boto_02 = new lib.mc_01();
	this.mc_boto_02.setTransform(744.5,513.6,1,1,0,0,0,57.5,15);
new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_01(), 3);
	this.txt_correcto_1 = new cjs.Text(txt['txt_correcto_3'], "bold 16px Arial");
	this.txt_correcto_1.textAlign = "center";
	this.txt_correcto_1.lineHeight = 18;
	this.txt_correcto_1.lineWidth = 110;
	this.txt_correcto_1.setTransform(574.3,504.4+incremento);

	this.mc_boto_01 = new lib.mc_01();
	this.mc_boto_01.setTransform(576.5,513.6,1,1,0,0,0,57.5,15);
     new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_01(), 3);  
     
      this.mc_boto_02.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_incorrecto_1(4);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
     this.mc_boto_01.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_correcto_1(3);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
     this.addChild(this.mc_boto_01,this.txt_correcto_1,this.mc_boto_02,this.txt_incorrecto_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0,0,200,100);
 
 (lib.preguntas4 = function () {
        this.initialize();

         this.txt_incorrecto_1 = new cjs.Text(txt['txt_incorrecto_5'], "bold 16px Arial");
	this.txt_incorrecto_1.textAlign = "center";
	this.txt_incorrecto_1.lineHeight = 18;
	this.txt_incorrecto_1.lineWidth = 110;
	this.txt_incorrecto_1.setTransform(742.4,504.7+incremento);

	this.mc_boto_02 = new lib.mc_01();
	this.mc_boto_02.setTransform(744.5,513.6,1,1,0,0,0,57.5,15);
new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_01(), 3);
	this.txt_correcto_1 = new cjs.Text(txt['txt_correcto_4'], "bold 16px Arial");
	this.txt_correcto_1.textAlign = "center";
	this.txt_correcto_1.lineHeight = 18;
	this.txt_correcto_1.lineWidth = 110;
	this.txt_correcto_1.setTransform(574.3,504.4+incremento);

	this.mc_boto_01 = new lib.mc_01();
	this.mc_boto_01.setTransform(576.5,513.6,1,1,0,0,0,57.5,15);
     new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_01(), 3);  
     
      this.mc_boto_02.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_incorrecto_1(5);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
     this.mc_boto_01.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_correcto_1(4);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
     this.addChild(this.mc_boto_01,this.txt_correcto_1,this.mc_boto_02,this.txt_incorrecto_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0,0,200,100);

 (lib.preguntas1 = function () {
        this.initialize();

         this.txt_incorrecto_1 = new cjs.Text(txt['txt_incorrecto_1'], "bold 16px Arial");
	this.txt_incorrecto_1.textAlign = "center";
	this.txt_incorrecto_1.lineHeight = 18;
	this.txt_incorrecto_1.lineWidth = 110;
	this.txt_incorrecto_1.setTransform(742.4,504.7+incremento);

	this.mc_boto_02 = new lib.mc_01();
	this.mc_boto_02.setTransform(744.5,513.6,1,1,0,0,0,57.5,15);
new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_01(), 3);
	this.txt_correcto_1 = new cjs.Text(txt['txt_correcto_1'], "bold 16px Arial");
	this.txt_correcto_1.textAlign = "center";
	this.txt_correcto_1.lineHeight = 18;
	this.txt_correcto_1.lineWidth = 110;
	this.txt_correcto_1.setTransform(574.3,504.4+incremento);

	this.mc_boto_01 = new lib.mc_01();
	this.mc_boto_01.setTransform(576.5,513.6,1,1,0,0,0,57.5,15);
     new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_01(), 3);  
     
      this.mc_boto_02.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_incorrecto_1(1);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
     this.mc_boto_01.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_correcto_1(1);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
     this.addChild(this.mc_boto_01,this.txt_correcto_1,this.mc_boto_02,this.txt_incorrecto_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0,0,200,100);
    
    (lib.preguntas2 = function () {
        this.initialize();

    this.txt_correcto_2 = new cjs.Text(txt['txt_correcto_2'], "bold 16px Verdana");
	this.txt_correcto_2.textAlign = "center";
	this.txt_correcto_2.lineHeight = 18;
	this.txt_correcto_2.lineWidth = 177;
	this.txt_correcto_2.setTransform(467.4,483.8);

	this.mc_boto_02 = new lib.mc_02();
	this.mc_boto_02.setTransform(436,492.1,1,1,0,0,0,57.5,15);
new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_02(), 3);
	this.txt_incorrecto_2 = new cjs.Text(txt['txt_incorrecto_2'], "bold 16px Verdana");
	this.txt_incorrecto_2.textAlign = "center";
	this.txt_incorrecto_2.lineHeight = 18;
	this.txt_incorrecto_2.lineWidth = 177;
	this.txt_incorrecto_2.setTransform(229.3,483.9);

	this.mc_boto_01 = new lib.mc_02();
	this.mc_boto_01.setTransform(198,492.1,1,1,0,0,0,57.5,15);
new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_02(), 3);

	this.txt_incorrecto_3 = new cjs.Text(txt['txt_incorrecto_3'], "bold 16px Verdana");
	this.txt_incorrecto_3.textAlign = "center";
	this.txt_incorrecto_3.lineHeight = 18;
	this.txt_incorrecto_3.lineWidth = 177;
	this.txt_incorrecto_3.setTransform(718.6,483.1);

	this.mc_boto_03 = new lib.mc_02();
	this.mc_boto_03.setTransform(687.3,492.1,1,1,0,0,0,57.5,15);
new cjs.ButtonHelper(this.mc_boto_03, 0, 1, 2, false, new lib.mc_02(), 3);
     
      this.mc_boto_02.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_correcto_1(2);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
     this.mc_boto_01.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_incorrecto_1(2);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
    this.mc_boto_03.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_incorrecto_1(3);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
     this.addChild(this.mc_boto_03,this.txt_incorrecto_3,this.mc_boto_01,this.txt_incorrecto_2,this.mc_boto_02,this.txt_correcto_2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0,0,200,100);
    
       (lib.preguntas5 = function () {
        this.initialize();

   	this.txt_incorrecto_8 = new cjs.Text(txt['txt_incorrecto_8'], "bold 16px Arial");
	this.txt_incorrecto_8.textAlign = "center";
	this.txt_incorrecto_8.lineHeight = 18;
	this.txt_incorrecto_8.lineWidth = 177;
	this.txt_incorrecto_8.setTransform(777.9,484.7);

	this.mc_boto_04 = new lib.mc_02();
	this.mc_boto_04.setTransform(746.5,492.1,1,1,0,0,0,57.5,15);
        new cjs.ButtonHelper(this.mc_boto_04, 0, 1, 2, false, new lib.mc_02(), 3);

	this.txt_incorrecto_7 = new cjs.Text(txt['txt_incorrecto_7'], "bold 16px Arial");
	this.txt_incorrecto_7.textAlign = "center";
	this.txt_incorrecto_7.lineHeight = 18;
	this.txt_incorrecto_7.lineWidth = 177;
	this.txt_incorrecto_7.setTransform(373.7,493.9);

	this.mc_boto_02 = new lib.mc_02();
	this.mc_boto_02.setTransform(342.5,492.1,1,1,0,0,0,57.5,15);
        new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_02(), 3);

	this.txt_incorrecto_6 = new cjs.Text(txt['txt_incorrecto_6'], "bold 16px Arial");
	this.txt_incorrecto_6.textAlign = "center";
	this.txt_incorrecto_6.lineHeight = 18;
	this.txt_incorrecto_6.lineWidth = 177;
	this.txt_incorrecto_6.setTransform(171.8,494);

	this.mc_boto_01 = new lib.mc_02();
	this.mc_boto_01.setTransform(140.5,492.1,1,1,0,0,0,57.5,15);
        new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_02(), 3);

	this.txt_correcto_5 = new cjs.Text(txt['txt_correcto_5'], "bold 16px Arial");
	this.txt_correcto_5.textAlign = "center";
	this.txt_correcto_5.lineHeight = 18;
	this.txt_correcto_5.lineWidth = 177;
	this.txt_correcto_5.setTransform(575.6,493.2);

	this.mc_boto_03 = new lib.mc_02();
	this.mc_boto_03.setTransform(544.5,492.1,1,1,0,0,0,57.5,15);
        new cjs.ButtonHelper(this.mc_boto_03, 0, 1, 2, false, new lib.mc_02(), 3);
       this.mc_boto_04.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_incorrecto_1(8);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
      this.mc_boto_02.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_incorrecto_1(7);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
     this.mc_boto_01.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_incorrecto_1(6);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
    this.mc_boto_03.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_correcto_1(5);
          this.popup.setTransform(-20,20);
          this.parent.parent.addChild(this.popup);
    });
     this.addChild(this.mc_boto_03,this.txt_correcto_5,this.mc_boto_01,this.txt_incorrecto_6,this.mc_boto_02,this.txt_incorrecto_7,this.mc_boto_04,this.txt_incorrecto_8);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0,0,700,100);
    
    (lib.preguntas6 = function () {
        this.initialize();

         this.txt_incorrecto_1 = new cjs.Text(txt['txt_incorrecto_9'], "bold 16px Arial");
	this.txt_incorrecto_1.textAlign = "center";
	this.txt_incorrecto_1.lineHeight = 18;
	this.txt_incorrecto_1.lineWidth = 110;
	this.txt_incorrecto_1.setTransform(599.6,496.7+incremento);

	this.mc_boto_02 = new lib.mc_01();
	this.mc_boto_02.setTransform(601.6,505.6,1.108,1,0,0,0,57.6,15);
new cjs.ButtonHelper(this.mc_boto_02, 0, 1, 2, false, new lib.mc_01(), 3);
	this.txt_correcto_1 = new cjs.Text(txt['txt_correcto_6'], "bold 16px Arial");
	this.txt_correcto_1.textAlign = "center";
	this.txt_correcto_1.lineHeight = 18;
	this.txt_correcto_1.lineWidth = 110;
	this.txt_correcto_1.setTransform(346.7,496.4+incremento);

	this.mc_boto_01 = new lib.mc_01();
	this.mc_boto_01.setTransform(348.6,505.6,1.108,1,0,0,0,57.5,15);
     new cjs.ButtonHelper(this.mc_boto_01, 0, 1, 2, false, new lib.mc_01(), 3);  
     
      this.mc_boto_02.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_incorrecto_1(9);
          this.popup.setTransform(-20,-20);
          this.parent.parent.addChild(this.popup);
    });
     this.mc_boto_01.on("click", function (evt) {
          if (popupon) return;
          popupon=true;
          this.popup=new lib.popup_correcto_1(6);
          this.popup.setTransform(-20,-20);
          this.parent.parent.addChild(this.popup);
    });
     this.addChild(this.mc_boto_01,this.txt_correcto_1,this.mc_boto_02,this.txt_incorrecto_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0,0,200,100);

    (lib.mc_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-90.95,-25.2,181.9,50.4,6);
	this.shape.setTransform(90.8,25.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-90.95,-25.2,181.9,50.4,6);
	this.shape_1.setTransform(90.8,25.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-90.95,-25.2,181.9,50.4,6);
	this.shape_2.setTransform(90.8,25.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-0.1,181.9,50.4);

(lib.mc_FonsBlanc_Int = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().drawRect(0, 0, 950, 608);
	//this.shape.setTransform(475,304,1.02,1.051);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);
(lib.mc_FonsBlanc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.instance = new lib.mc_FonsBlanc_Int();
	this.instance.setTransform(-10,40,1,1);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.283},0).wait(1).to({alpha:0.567},0).wait(1).to({alpha:0.85},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_incorrecto_9 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(801.4,160.2,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_Error();
	this.instance.setTransform(198.7,208,0.685,0.685,0,0,0,98,103.7);

	this.txt_popup_incorrecto_9 = new cjs.Text("", "20px Verdana");
	this.txt_popup_incorrecto_9.lineHeight = 20;
	this.txt_popup_incorrecto_9.lineWidth = 612;
	this.txt_popup_incorrecto_9.setTransform(168.4,201.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-343,-130,686,260,6);
	this.shape.setTransform(475,275);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_incorrecto_9 = new cjs.Text("Complicado", "16px Arial", "#FFFFFF");
	this.txt_incorrecto_9.textAlign = "center";
	this.txt_incorrecto_9.lineHeight = 18;
	this.txt_incorrecto_9.lineWidth = 122;
	this.txt_incorrecto_9.setTransform(599.6,496.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_1.setTransform(601.5,505.6,1.108,1);

	this.addChild(this.shape_1,this.txt_incorrecto_9,this.instance_1,this.shape,this.txt_popup_incorrecto_9,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_incorrecto_8 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(801.4,160.2,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_Error();
	this.instance.setTransform(198.7,208,0.685,0.685,0,0,0,98,103.7);

	this.txt_popup_incorrecto_8 = new cjs.Text("", "20px Verdana");
	this.txt_popup_incorrecto_8.lineHeight = 20;
	this.txt_popup_incorrecto_8.lineWidth = 612;
	this.txt_popup_incorrecto_8.setTransform(168.4,201.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-342.5,-118,685,236,6);
	this.shape.setTransform(475.5,264);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_incorrecto_8 = new cjs.Text("Las tempestades del mar", "16px Arial", "#FFFFFF");
	this.txt_incorrecto_8.textAlign = "center";
	this.txt_incorrecto_8.lineHeight = 18;
	this.txt_incorrecto_8.lineWidth = 177;
	this.txt_incorrecto_8.setTransform(777.9,484.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-90.95,-25.2,181.9,50.4,6);
	this.shape_1.setTransform(779.7,502.1);

	this.addChild(this.shape_1,this.txt_incorrecto_8,this.instance_1,this.shape,this.txt_popup_incorrecto_8,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_incorrecto_7 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(827.3,160.2,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_Error();
	this.instance.setTransform(171.6,208,0.685,0.685,0,0,0,97.9,103.7);

	this.txt_popup_incorrecto_7 = new cjs.Text("", "20px Verdana");
	this.txt_popup_incorrecto_7.lineHeight = 20;
	this.txt_popup_incorrecto_7.lineWidth = 667;
	this.txt_popup_incorrecto_7.setTransform(141.4,201.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-368.5,-129,737,258,6);
	this.shape.setTransform(474.5,276);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_incorrecto_7 = new cjs.Text("El amor", "16px Arial", "#FFFFFF");
	this.txt_incorrecto_7.textAlign = "center";
	this.txt_incorrecto_7.lineHeight = 18;
	this.txt_incorrecto_7.lineWidth = 177;
	this.txt_incorrecto_7.setTransform(373.7,493.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-90.95,-25.2,181.9,50.4,6);
	this.shape_1.setTransform(375.7,502.1);

	this.addChild(this.shape_1,this.txt_incorrecto_7,this.instance_1,this.shape,this.txt_popup_incorrecto_7,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_incorrecto_6 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(785.4,160.2,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_Error();
	this.instance.setTransform(216.7,208,0.685,0.685,0,0,0,98,103.7);

	this.txt_popup_incorrecto_6 = new cjs.Text("", "20px Verdana");
	this.txt_popup_incorrecto_6.lineHeight = 20;
	this.txt_popup_incorrecto_6.lineWidth = 580;
	this.txt_popup_incorrecto_6.setTransform(186.4,201.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-327,-131.5,654,263,6);
	this.shape.setTransform(476,277.5);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_incorrecto_6 = new cjs.Text("El sepulcro.", "16px Arial", "#FFFFFF");
	this.txt_incorrecto_6.textAlign = "center";
	this.txt_incorrecto_6.lineHeight = 18;
	this.txt_incorrecto_6.lineWidth = 177;
	this.txt_incorrecto_6.setTransform(171.8,494);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-90.95,-25.2,181.9,50.4,6);
	this.shape_1.setTransform(173.7,502.1);

	this.addChild(this.shape_1,this.txt_incorrecto_6,this.instance_1,this.shape,this.txt_popup_incorrecto_6,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_incorrecto_5 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(741.4,160.2,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_Error();
	this.instance.setTransform(262.7,208,0.685,0.685,0,0,0,98,103.7);

	this.txt_popup_incorrecto_5 = new cjs.Text("", "20px Verdana");
	this.txt_popup_incorrecto_5.lineHeight = 20;
	this.txt_popup_incorrecto_5.lineWidth = 479;
	this.txt_popup_incorrecto_5.setTransform(242.9,201.6);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-281,-117.5,562,235,6);
	this.shape.setTransform(478,261.8);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_incorrecto_5 = new cjs.Text("", "16px Arial", "#FFFFFF");
	this.txt_incorrecto_5.textAlign = "center";
	this.txt_incorrecto_5.lineHeight = 18;
	this.txt_incorrecto_5.lineWidth = 110;
	this.txt_incorrecto_5.setTransform(771.7,500.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_1.setTransform(773.8,509.6);

	this.addChild(this.shape_1,this.txt_incorrecto_5,this.instance_1,this.shape,this.txt_popup_incorrecto_5,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_incorrecto_4 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(824.3,160.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_Error();
	this.instance.setTransform(173.7,208.7,0.685,0.685,0,0,0,98,103.7);

	this.txt_popup_incorrecto_4 = new cjs.Text("", "20px Verdana");
	this.txt_popup_incorrecto_4.lineHeight = 20;
	this.txt_popup_incorrecto_4.lineWidth = 667;
	this.txt_popup_incorrecto_4.setTransform(143.4,202.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-368,-118.5,736,237,10);
	this.shape.setTransform(475,263.5);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_incorrecto_4 = new cjs.Text("", "16px Arial", "#FFFFFF");
	this.txt_incorrecto_4.textAlign = "center";
	this.txt_incorrecto_4.lineHeight = 18;
	this.txt_incorrecto_4.lineWidth = 110;
	this.txt_incorrecto_4.setTransform(771.7,504.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_1.setTransform(773.8,513.6);

	this.addChild(this.shape_1,this.txt_incorrecto_4,this.instance_1,this.shape,this.txt_popup_incorrecto_4,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_incorrecto_3 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(824.3,160.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_Error();
	this.instance.setTransform(173.7,208.7,0.685,0.685,0,0,0,98,103.7);

	this.txt_popup_incorrecto_3 = new cjs.Text("", "20px Verdana");
	this.txt_popup_incorrecto_3.lineHeight = 20;
	this.txt_popup_incorrecto_3.lineWidth = 667;
	this.txt_popup_incorrecto_3.setTransform(143.4,202.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-368,-118.5,736,237,10);
	this.shape.setTransform(475,263.5);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_incorrecto_3 = new cjs.Text("Es un\nencabalgamiento", "16px Arial", "#FFFFFF");
	this.txt_incorrecto_3.textAlign = "center";
	this.txt_incorrecto_3.lineHeight = 18;
	this.txt_incorrecto_3.lineWidth = 177;
	this.txt_incorrecto_3.setTransform(718.6,483.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-90.95,-25.2,181.9,50.4,6);
	this.shape_1.setTransform(720.5,502.1);

	this.addChild(this.shape_1,this.txt_incorrecto_3,this.instance_1,this.shape,this.txt_popup_incorrecto_3,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_incorrecto_2 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(824.3,160.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_Error();
	this.instance.setTransform(173.7,208.7,0.685,0.685,0,0,0,98,103.7);

	this.txt_popup_incorrecto_2 = new cjs.Text("", "20px Verdana");
	this.txt_popup_incorrecto_2.lineHeight = 20;
	this.txt_popup_incorrecto_2.lineWidth = 620;
	this.txt_popup_incorrecto_2.setTransform(143.4,202.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-368,-118.5,736,237,10);
	this.shape.setTransform(475,263.5);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_incorrecto_2 = new cjs.Text("Es una\nexclamación", "16px Arial", "#FFFFFF");
	this.txt_incorrecto_2.textAlign = "center";
	this.txt_incorrecto_2.lineHeight = 18;
	this.txt_incorrecto_2.lineWidth = 177;
	this.txt_incorrecto_2.setTransform(229.3,483.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-90.95,-25.2,181.9,50.4,6);
	this.shape_1.setTransform(231.2,502.1);

	this.addChild(this.shape_1,this.txt_incorrecto_2,this.instance_1,this.shape,this.txt_popup_incorrecto_2,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_incorrecto_1 = function(num) {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(824.3,160.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

       this.btn_salir.on("click", function (evt) {
            this.parent.visible=false;
            popupon=false;
        });
	// Txt
	this.instance = new lib.Icona_Error();
	this.instance.setTransform(153,208.7,0.685,0.685,0,0,0,98,103.7);

	
 var html = createDiv(txt['txt_popup_incorrecto_'+num], "Verdana", "20px", '640px', '150px', "20px", "115px", "left", 'txt04',1);
        this.txt_popup_incorrecto_1 = new cjs.DOMElement(html);

        this.txt_popup_incorrecto_1.setTransform(190, -420);
        onResize();
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-368,-118.5,736,237,10);
	this.shape.setTransform(475,263.5);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,283.9,1,1.2,0,0,0,475,303.9);

	

	this.addChild(this.instance_1,this.shape,this.txt_popup_incorrecto_1,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_correcto_6 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(811.3,160.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_ok();
	this.instance.setTransform(182.6,208.7,0.685,0.685,0,0,0,97.9,103.7);

	this.txt_popup_correcto_6 = new cjs.Text("", "20px Verdana");
	this.txt_popup_correcto_6.lineHeight = 22;
	this.txt_popup_correcto_6.lineWidth = 635;
	this.txt_popup_correcto_6.setTransform(157.4,205.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-354,-131.5,708,263,6);
	this.shape.setTransform(475,276.5);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_correcto_6 = new cjs.Text("Sencillo", "16px Arial", "#FFFFFF");
	this.txt_correcto_6.textAlign = "center";
	this.txt_correcto_6.lineHeight = 18;
	this.txt_correcto_6.lineWidth = 122;
	this.txt_correcto_6.setTransform(346.7,496.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_1.setTransform(348.6,505.6,1.108,1);

	this.addChild(this.shape_1,this.txt_correcto_6,this.instance_1,this.shape,this.txt_popup_correcto_6,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_correcto_5 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(802.3,160.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_ok();
	this.instance.setTransform(192.6,208.7,0.685,0.685,0,0,0,97.9,103.7);

	this.txt_popup_correcto_5 = new cjs.Text("", "20px Verdana");
	this.txt_popup_correcto_5.lineHeight = 22;
	this.txt_popup_correcto_5.lineWidth = 620;
	this.txt_popup_correcto_5.setTransform(167.4,200.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-344,-102.5,688,205,6);
	this.shape.setTransform(476,248.5);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_correcto_5 = new cjs.Text("Las ruinas", "16px Arial", "#FFFFFF");
	this.txt_correcto_5.textAlign = "center";
	this.txt_correcto_5.lineHeight = 18;
	this.txt_correcto_5.lineWidth = 177;
	this.txt_correcto_5.setTransform(575.6,493.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-90.95,-25.2,181.9,50.4,6);
	this.shape_1.setTransform(577.7,502.1);

	this.addChild(this.shape_1,this.txt_correcto_5,this.instance_1,this.shape,this.txt_popup_correcto_5,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_correcto_4 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(803.3,160.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_ok();
	this.instance.setTransform(193.7,208.7,0.685,0.685,0,0,0,98,103.7);

	this.txt_popup_correcto_4 = new cjs.Text("", "20px Verdana");
	this.txt_popup_correcto_4.lineHeight = 22;
	this.txt_popup_correcto_4.lineWidth = 598;
	this.txt_popup_correcto_4.setTransform(181.7,195.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-344,-142.5,688,285,6);
	this.shape.setTransform(478,287.5);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_correcto_4 = new cjs.Text("", "16px Arial", "#FFFFFF");
	this.txt_correcto_4.textAlign = "center";
	this.txt_correcto_4.lineHeight = 18;
	this.txt_correcto_4.lineWidth = 110;
	this.txt_correcto_4.setTransform(603.6,500.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_1.setTransform(605.8,509.6);

	this.addChild(this.shape_1,this.txt_correcto_4,this.instance_1,this.shape,this.txt_popup_correcto_4,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_correcto_3 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(803.3,160.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_ok();
	this.instance.setTransform(193.7,208.7,0.685,0.685,0,0,0,98,103.7);

	this.txt_popup_correcto_3 = new cjs.Text("", "20px Verdana");
	this.txt_popup_correcto_3.lineHeight = 22;
	this.txt_popup_correcto_3.lineWidth = 609;
	this.txt_popup_correcto_3.setTransform(168.4,200.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-344,-142.5,688,285,6);
	this.shape.setTransform(478,287.5);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_correcto_3 = new cjs.Text("", "16px Arial", "#FFFFFF");
	this.txt_correcto_3.textAlign = "center";
	this.txt_correcto_3.lineHeight = 18;
	this.txt_correcto_3.lineWidth = 110;
	this.txt_correcto_3.setTransform(603.6,504.4);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_1.setTransform(605.8,513.6);

	this.addChild(this.shape_1,this.txt_correcto_3,this.instance_1,this.shape,this.txt_popup_correcto_3,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_correcto_2 = function() {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(803.3,160.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_ok();
	this.instance.setTransform(193.7,208.7,0.685,0.685,0,0,0,98,103.7);

	this.txt_popup_correcto_2 = new cjs.Text("", "20px Verdana");
	this.txt_popup_correcto_2.lineHeight = 22;
	this.txt_popup_correcto_2.lineWidth = 587;
	this.txt_popup_correcto_2.setTransform(184.6,200.3);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-345,-155,690,310,6);
	this.shape.setTransform(476,300);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,303.9,1,1,0,0,0,475,303.9);

	this.txt_correcto_2 = new cjs.Text("Es un\nepíteto", "16px Arial", "#FFFFFF");
	this.txt_correcto_2.textAlign = "center";
	this.txt_correcto_2.lineHeight = 18;
	this.txt_correcto_2.lineWidth = 177;
	this.txt_correcto_2.setTransform(467.4,483.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-90.95,-25.2,181.9,50.4,6);
	this.shape_1.setTransform(469.3,502.1);

	this.addChild(this.shape_1,this.txt_correcto_2,this.instance_1,this.shape,this.txt_popup_correcto_2,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_correcto_1 = function(num) {
	this.initialize();

	// Boto
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(803.3,160.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);

	// Txt
	this.instance = new lib.Icona_ok();
	this.instance.setTransform(183,208.7,0.685,0.685,0,0,0,98,103.7);

	
this.btn_salir.on("click", function (evt) {
            this.parent.visible=false;
            popupon=false;
        });
	// Txt
	

	
 var html = createDiv(txt['txt_popup_correcto_'+num], "Verdana", "20px", '600px', '150px', "20px", "115px", "left", 'txt04',1);
        this.txt_popup_correcto_1 = new cjs.DOMElement(html);

        this.txt_popup_correcto_1.setTransform(200, -410);
        onResize();
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-346.75,-137.7,693.5,275.4,10);
	this.shape.setTransform(472.7,293.3,1,1.1);

	// MC_Fons
	this.instance_1 = new lib.mc_FonsBlanc();
	this.instance_1.setTransform(475,283.9,1,1.2,0,0,0,475,303.9);

	

	this.addChild(this.instance_1,this.shape,this.instance,this.txt_popup_correcto_1,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);



(lib.mc_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape.setTransform(57.5,15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#CCCCCC").s("#000000").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_1.setTransform(57.5,15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#666666").s("#666666").ss(1,1,1).rr(-57.5,-15,115,30,6);
	this.shape_2.setTransform(57.5,15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,115,30);

    (lib.btn_imatge = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.instance = new lib._7_200242598001();
        this.instance.setTransform(0, 0, 0.5, 0.5);

        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.498)").s().p("EgpzAdEMAAAg6HMBToAAAMAAAA6Hg");
        this.shape.setTransform(263, 183);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.instance}]}).to({state: [{t: this.instance}, {t: this.shape}]}, 1).to({state: [{t: this.instance}]}, 1).to({state: [{t: this.instance}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 524.5, 365);
    (lib._1_shutterstock_58407121 = function () {
        this.initialize(img._1_shutterstock_58407121);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 896, 730);


    (lib._2_shutterstock_85957090 = function () {
        this.initialize(img._2_shutterstock_85957090);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 468, 400);


    (lib._3_shutterstock_69283318 = function () {
        this.initialize(img._3_shutterstock_69283318);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 600, 400);


    (lib._7_200242598001 = function () {
        this.initialize(img._7_200242598001);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1049, 730);


    (lib._8_shutterstock_79853296 = function () {
        this.initialize(img._8_shutterstock_79853296);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 602, 400);


    (lib._95391026 = function () {
        this.initialize(img._95391026);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 891, 596);


    (lib.Golondrinas = function () {
        this.initialize(img.Golondrinas);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 945, 596);


    (lib.Orenetas = function () {
        this.initialize(img.Orenetas);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 462, 298);


    (lib.Orenetas2 = function () {
        this.initialize(img.Orenetas2);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 568, 365);



    (lib.shutterstock_58247269 = function () {
        this.initialize(img.shutterstock_58247269);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1091, 730);
    //Simbolillos
    (lib.Icona_ok = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#0B6635", "#95C030"], [0, 1], 34.5, 77.7, -16.7, -68.8).s().p("ApNImQhWg8hWgzIhFgnIg/kOIAKAAQCVAUD6CeQB9BPBfBLQAhogGXnoQCAiZCWiAQBLhBAyghIE7E3QpsF1kSKEQhVDKgpDNQgVBmgDA+QiljQkSjAg");
        this.shape.setTransform(97.9, 103.7, 0.5, 0.5);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(53.3, 56.2, 89.4, 95.1);


    (lib.Icona_Error = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.lf(["#F09122", "#DF081F"], [0, 1], 22.6, 52.5, -22, -52.8).s().p("AEVG3IlKlxIjbFxQg1gdgvglQhehKAhglIECkIIjbjkQARhAAZg6QAzh1AmAdIDYFRIEWkqIBGAlQBBArgbAfIkXEXIF/EWQgbA4gjAxQg0BLghAAQgKAAgJgIg");
        this.shape.setTransform(102.6, 102.6, 1, 1, 0, 0, 0, 0.8, -0.3);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(57.5, 58.2, 88.7, 89.5);


    (lib.mc_ImatgeSol = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib.shutterstock_58247269();
        this.instance.setTransform(-42.9, 0, 0.5, 0.5);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-42.9, 0, 545.5, 365);


    (lib.mc_ImatgeRayo = function () {
        this.initialize();

        // FlashAICB
        this.instance = new lib._8_shutterstock_79853296();
        this.instance.setTransform(-256.4, 14.4, 0.624, 0.624);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-256.4, 14.4, 375.8, 249.7);


    (lib.mc_ImatgePosta = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib._2_shutterstock_85957090();
        this.instance.setTransform(0, 0, 0.5, 0.5);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 234, 200);


    (lib.mc_ImatgeOrenetas2 = function () {
        this.initialize();

        // FlashAICB
        this.instance = new lib.Orenetas2();
        this.instance.setTransform(-31.9, 14.4, 0.624, 0.624);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-31.9, 14.4, 354.6, 227.9);


    (lib.mc_ImatgeOrenetas = function () {
        this.initialize();

        // FlashAICB
        this.instance = new lib.Orenetas();
        this.instance.setTransform(-31.9, 21.6, 0.772, 0.772);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-31.9, 21.6, 356.8, 230.1);


    (lib.mc_ImatgeGolondrinas = function () {
        this.initialize();

        // FlashAICB
        this.instance = new lib._95391026();
        this.instance.setTransform(-350.3, 15.7, 0.63, 0.63);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-350.3, 15.7, 561.3, 375.5);


    (lib.mc_ImatgeFaro = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib._7_200242598001();
        this.instance.setTransform(-240.1, 15.2, 0.324, 0.324);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-240.1, 15.2, 339.6, 236.3);


    (lib.mc_ImatgeAlba = function () {
        this.initialize();

        // Capa 1
        this.instance = new lib._3_shutterstock_69283318();
        this.instance.setTransform(-31.9, 21.6, 0.5, 0.5);

        this.addChild(this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(-31.9, 21.6, 300, 200);


    (lib.mc_FonsBlanc_Int = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("EhIvAtLMAAAhaWMCRfAAAMAAABaWg");
        this.shape.setTransform(475, 304, 1.02, 1.051);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

    (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id,zIndex) {
    zIndex=zIndex||-1;
    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";
    html.style.zIndex=zIndex;
    
    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);

    //Audio
    this.audioplay.on("click", function (evt) {
        reproductor = cjs.Sound.play("misonido");
        this.visible = false;
        this.parent.audiopause.visible = true;
    });

    this.audiopause.on("click", function (evt) {
        reproductor.stop();
        this.visible = false;
        this.parent.audioplay.visible = true;
    });
}