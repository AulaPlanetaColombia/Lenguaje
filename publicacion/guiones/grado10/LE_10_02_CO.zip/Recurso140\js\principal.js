(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
        titulo1(this, txt['titulo']);
        this.instance = new lib.btn_01();
        this.instance.setTransform(674.5, 110.5);
        new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.btn_01(), 3);

        this.instance_1 = new lib.btn_01();
        this.instance_1.setTransform(395.5, 110.5);
        new cjs.ButtonHelper(this.instance_1, 0, 1, 2, false, new lib.btn_01(), 3);

        this.instance_2 = new lib.btn_01();
        this.instance_2.setTransform(115.5, 110.5);
        new cjs.ButtonHelper(this.instance_2, 0, 1, 2, false, new lib.btn_01(), 3);


        this.text = new cjs.Text(txt['selecciona'], "16px Arial");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 266;
        this.text.setTransform(472.6, 555.1);

        this.text_1 = new cjs.Text(txt['btn3'], "20px Verdana");
        this.text_1.textAlign = "center";
        this.text_1.lineHeight = 20;
        this.text_1.lineWidth = 159;
        this.text_1.setTransform(756.9, 472.8);

        this.text_2 = new cjs.Text(txt['btn2'], "20px Verdana");
        this.text_2.textAlign = "center";
        this.text_2.lineHeight = 20;
        this.text_2.lineWidth = 159;
        this.text_2.setTransform(475.9, 472.8);

        this.text_3 = new cjs.Text(txt['btn1'], "20px Verdana");
        this.text_3.textAlign = "center";
        this.text_3.lineHeight = 20;
        this.text_3.lineWidth = 159;
        this.text_3.setTransform(195.9, 472.8);

this.shape = new cjs.Shape();
	this.shape.graphics.f("#CCCCCC").s().p("A1NCEIAAkHMAqbAAAIAAEHg");
	this.shape.setTransform(475.2,563.2,1,1.136);

        this.instance_4 = new lib.SantaTeresa0001MW01_1();
        this.instance_4.setTransform(677.6, 112.8, 0.5, 0.5);

        this.instance_5 = new lib.SanJuan000M3U01_1();
        this.instance_5.setTransform(397.1, 112.8, 0.5, 0.5);

        this.instance_6 = new lib.FrayLuisdeLeon();
        this.instance_6.setTransform(116.7, 112.8, 0.5, 0.5);

        this.instance_2.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.instance_1.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.instance.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });

        this.addChild(this.logo, this.titulo,this.shape, this.text_4, this.text_3, this.text_2, this.text_1, this.text, this.instance_6, this.instance_5, this.instance_4, this.instance_3, this.instance_2, this.instance_1, this.instance);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_1 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 0, 1, 0, 0);

        titulo2(this, txt['tit1']);

        this.instance_1 = new lib.FrayLuisdeLeon_1();
        this.instance_1.setTransform(516.7, 62.8, 0.695, 0.695);

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_2());
        });

        this.addChild(this.logo, this.home, this.titulo, this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_2 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 0, 0);

        var html = createDiv(txt['text1_2'], "Verdana", "20px", '770px', '100px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 0);
        this.texto1.setTransform(100, -520);

        var flecha = new lib.flecha();
        this.shape = new lib.fadeElement(flecha, 25);
        this.shape.setTransform(100, 80);
        var html = createDiv(txt['text1_2b'], "Verdana", "20px", '770px', '100px', "20px", "185px", "left");
        this.texto2 = new lib.fadeText(html, 45);
        this.texto2.setTransform(100, -310);

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });

        this.addChild(this.logo, this.home, this.anterior, this.texto1, this.siguiente, this.shape, this.shape_1, this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_3 = function () {
         var audioOn=false;
         
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 1, 0, 1);
        titulo2(this, txt['tit1_3']);
        var html = createDiv(txt['text1_3'], "Verdana", "20px", '770px', '100px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 0);
        this.texto1.setTransform(100, -480);

        var flecha = new lib.Thinkstock_200367652001();
        this.instance = new lib.fadeElement(flecha, 25);
        this.instance.setTransform(330, 255, .382, .382, 0, 0, 0, 301.7, 148.8);

        this.audioplay.on("click", function (evt) {
             if (window.reproductor === undefined || window.reproductor===null)
                reproductor = cjs.Sound.play("misonido");
            else
                reproductor.resume();
            audioOn=true;
            this.visible = false;
            this.parent.audiopause.visible = true;
        });

        this.audiopause.on("click", function (evt) {
              reproductor.pause();
                          audioOn=false;

            this.visible = false;
            this.parent.audioplay.visible = true;
        });

        this.home.on("click", function (evt) {
            
            if (window.reproductor !== undefined){
                 if (audioOn){ 
            
            reproductor.stop();
        }
            window.reproductor=null;
            }
            putStage(new lib.frame1());
        });
        this.informacion.on("click", function (evt) {
             if (window.reproductor !== undefined){
                  if (audioOn)
            reproductor.stop();
            reproductor=null;
            }
            putStage(new lib.frame1_info1(1));
        });
        this.anterior.on("click", function (evt) {
             if (window.reproductor !== undefined){
                  if (audioOn)
            reproductor.stop();
            reproductor=null;
            }
            putStage(new lib.frame1_2());
        });
        this.siguiente.on("click", function (evt) {
             if (window.reproductor !== undefined){
                   if (audioOn)
            reproductor.stop();
            reproductor=null;
            }
            putStage(new lib.frame1_4());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto1, this.siguiente, this.instance, this.audioplay, this.audiopause);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_4 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit1_4']);

        texto(this, txt['text1_4'], 0, 100);


        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame1_info1(2));
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame1_5 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit1_5']);

        texto(this, txt['text1_5'], 0, 100);


        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame1_info1(3));
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_6());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


    (lib.frame1_6 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 1, 0, 0);
        titulo2(this, txt['tit1_6']);
 this.imagen = new lib.Thinkstock_108684726();
        var ancho = imagen(this, 1, 0.5, 0.5);
        //this.instance_1.setTransform(180.5, 299.5, 1, 1, 0, 0, 0, 151.5, 187.5);
        texto(this, txt['text1_6'], 0, ancho,-482);
        


        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame1_info1(4));
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame1_7());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto, this.siguiente,this.imagen);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame1_7 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit1_7']);
        
        texto(this, txt['text1_7'], 0, 100,-492);
        
this.instance = new lib.mc_p6();
	this.instance.setTransform(466.9,300,1,1,0,0,0,393.7,164.6);

 this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.practica.on("click", function (evt) {
            putStage(new lib.frame1_8());
        });
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_5());
        });
        

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto, this.siguiente,this.instance, this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame1_8 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0, 0, 0, 0, 1, 0);
        titulo2(this, txt['tit1_8']);
        
        texto(this, txt['text1_8'], 0, 250,-400);
        this.texto.setTransform(250,-400);

 this.practica = new lib.btn_practica(txt['textbtnsolucion']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.practica.on("click", function (evt) {
            putStage(new lib.frame1_9());
        });
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_7());
        });
      
        

        this.addChild(this.logo,this.cerrar, this.titulo, this.home, this.informacion, this.anterior, this.texto, this.siguiente,this.instance, this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  
     (lib.frame1_9 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0, 1, 0, 0, 1, 0);
        titulo2(this, txt['tit1_9']);
        
       this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(2,1,1).p("AEriKQgHBvhRBOQhXBYh8AAQh7AAhYhYQhQhOgHhv");
	this.shape.setTransform(609.9,367,0.626,0.626);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(2,1,1).p("AEriKQgHBvhRBOQhXBYh8AAQh7AAhYhYQhQhOgHhv");
	this.shape_1.setTransform(409,367,0.626,0.626);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(2,1,1).p("AEriKQgHBvhRBOQhXBYh8AAQh7AAhYhYQhQhOgHhv");
	this.shape_2.setTransform(363.5,320,0.626,0.626);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(2,1,1).p("AEriKQgHBvhRBOQhXBYh8AAQh7AAhYhYQhQhOgHhv");
	this.shape_3.setTransform(265.1,278,0.626,0.626);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(2,1,1).p("AEriKQgHBvhRBOQhXBYh8AAQh7AAhYhYQhQhOgHhv");
	this.shape_4.setTransform(225.9,230,0.626,0.626);

	this.text = new cjs.Text("7a\n\n11B\n\n7a\n\n7b\n\n11B", "bold 20px Verdana", "#243186");
	this.text.textAlign = "right";
	this.text.lineHeight = 22;
	this.text.lineWidth = 58;
	this.text.setTransform(877.4,157.5);


	this.text_2 = new cjs.Text("¡Qué – des – can – sa - da – vi - da\n\nla - del - que hu – ye - (d)el – mun – da – nal -  ru – ï - do,\n\ny – si – gue – la es – con – di – da\n\nsen – da – por – don - de han - i – do\n\nlos – po – cos – sa - bios - que en - el – mun - do han – si - do!", "italic 20px Verdana");
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 654;
	this.text_2.setTransform(94,157.5);

 var html = createDiv(txt['text1_9'], "Verdana", "15px",  '400px', '100px', "20px", "185px", "right");
         this.text_3 = new cjs.DOMElement(html);
        
        this.text_3.setTransform(360,-200);
 
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame1_8());
        });
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame1_7());
        });
        
        
        this.addChild(this.logo, this.titulo,this.cerrar, this.home, this.informacion, this.anterior, this.texto, this.siguiente,this.instance,this.text_3, this.text_2,this.text_1,this.text,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 
 
    (lib.frame1_info1 = function (retorno) {
        this.initialize();
        clearTexts();
        basicos(this, 0, 0, 0, 0, 1, 0);
        titulo2(this, txt['tit1_info']);
        var html = createDiv(txt['text1_info'], "Verdana", "20px", '600px', '400px', "20px", "185px", "left");
        html.style.overflow = "scroll";

        this.texto1 = new cjs.DOMElement(html);
        this.texto1.setTransform(100, -480);
        


        this.cerrar.on("click", function (evt) {
            if (retorno == 1)
                putStage(new lib.frame1_3());
            else if (retorno == 2)
                putStage(new lib.frame1_4());
            else if (retorno == 3)
                putStage(new lib.frame1_5());
            else if (retorno == 4)
                putStage(new lib.frame1_6());
        });
        this.addChild(this.logo, this.titulo, this.cerrar, this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);



    (lib.frame2_1 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 0, 1, 0, 0);

        titulo2(this, txt['tit2']);

        this.instance_1 = new lib.SanJuan000M3U01();
        this.instance_1.setTransform(516.7, 112.8, 0.55, 0.55);

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });

        this.addChild(this.logo, this.home, this.titulo, this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_2 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 0, 0);

        var html = createDiv(txt['text2_2'], "Verdana", "20px", '770px', '100px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 0);
        this.texto1.setTransform(100, -520);

        

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });

        this.addChild(this.logo, this.home, this.anterior, this.texto1, this.siguiente, this.shape, this.shape_1, this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_3 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 0, 0, 0);
        titulo2(this, txt['tit2_3']);
        var html = createDiv(txt['text2_3'], "Verdana", "16px", '370px', '100px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 0);
        this.texto1.setTransform(130, -460);

         html = createDiv(txt['text2_3b'], "Verdana", "16px", '370px', '100px', "20px", "185px", "left");
        this.texto2 = new lib.fadeText(html, 0);
        this.texto2.setTransform(460, -460);


      

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
     
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_2());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto1, this.texto2, this.siguiente, this.instance, this.audioplay, this.audiopause);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_4 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 1, 0, 0);
       

        texto(this, txt['text2_4'], 0, 100,-482);


        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.informacion.on("click", function (evt) {
            putStage(new lib.frame2_info1(2));
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2_5 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 0, 0, 0);
        titulo2(this, txt['tit2_5'],"20px");

        var html = createDiv(txt['text2_5'], "Verdana", "16px", '400px', '100px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 0);
        this.texto1.setTransform(100, -460);

         html = createDiv(txt['text2_5b'], "Verdana", "16px", '400px', '100px', "20px", "185px", "left");
        this.texto2 = new lib.fadeText(html, 0);
        this.texto2.setTransform(500, -460);


        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_6());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto1, this.texto2, this.siguiente);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


    (lib.frame2_6 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 0, 0, 0);
          var html = createDiv(txt['text2_6'], "Verdana", "16px", '400px', '100px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 0);
        this.texto1.setTransform(100, -460);

         html = createDiv(txt['text2_6b'], "Verdana", "16px", '370px', '100px', "20px", "185px", "left");
        this.texto2 = new lib.fadeText(html, 0);
        this.texto2.setTransform(500, -460);
        


        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2_7());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto1, this.texto2, this.siguiente,this.imagen);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame2_7 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit2_7'],"20px");
        
        
        
this.instance = new lib.mc_h6();
	this.instance.setTransform(490.2,345.1,1,1,0,0,0,343.6,169.6);

 this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.practica.on("click", function (evt) {
            putStage(new lib.frame2_8());
        });
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_5());
        });
        

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto, this.siguiente,this.instance, this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame2_8 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0, 0, 0, 0, 1, 0);
        titulo2(this, txt['tit2_8']);
        
         var html = createDiv(txt['text2_8'], "Verdana", "20px", '370px', '100px', "20px", "185px", "left");
             this.texto1 = new cjs.DOMElement(html);
        this.texto1.setTransform(100, -460);

         html = createDiv(txt['text2_8b'], "Verdana", "20px", '370px', '100px', "20px", "185px", "left");
             this.texto2 = new cjs.DOMElement(html);
        this.texto2.setTransform(510, -460);

 this.practica = new lib.btn_practica(txt['textbtnsolucion']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

        this.practica.on("click", function (evt) {
            putStage(new lib.frame2_9());
        });
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_7());
        });
      
        

        this.addChild(this.logo,this.cerrar, this.titulo, this.home, this.informacion, this.anterior, this.texto1, this.texto2, this.siguiente,this.instance, this.practica);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
  
     (lib.frame2_9 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 0, 1, 0, 0, 1, 0);
       
        
      this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(3,1,1).p("AEriKQgHBvhRBOQhXBYh8AAQh7AAhYhYQhQhOgHhv");
	this.shape.setTransform(596,325,0.441,0.301,0,0,0,0,-0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#000000").ss(3,1,1).p("AEriKQgHBvhRBOQhXBYh8AAQh7AAhYhYQhQhOgHhv");
	this.shape_1.setTransform(321.9,325,0.441,0.301,0,0,0,0,-0.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#000000").ss(3,1,1).p("AEriKQgHBvhRBOQhXBYh8AAQh7AAhYhYQhQhOgHhv");
	this.shape_2.setTransform(522.8,195.5,0.441,0.301,0,0,0,0,-0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#000000").ss(3,1,1).p("AEriKQgHBvhRBOQhXBYh8AAQh7AAhYhYQhQhOgHhv");
	this.shape_3.setTransform(334.5,170.3,0.441,0.301,0,0,0,0,-0.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#000000").ss(3,1,1).p("AEriKQgHBvhRBOQhXBYh8AAQh7AAhYhYQhQhOgHhv");
	this.shape_4.setTransform(386.8,148.4,0.441,0.301,0,0,0,0,-0.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#000000").ss(3,1,1).p("AEriKQgHBvhRBOQhXBYh8AAQh7AAhYhYQhQhOgHhv");
	this.shape_5.setTransform(226.7,148.4,0.441,0.301,0,0,0,0,-0.1);

	this.text = new cjs.Text("7a\n11B\n7a\n7b\n11B\n\n7c\n11D\n7c\n7c\n11D\n\n7e\n11F\n7e\n7f\n11F", "bold 20px Verdana", "#B30218");
	this.text.textAlign = "right";
	this.text.lineHeight = 22;
	this.text.lineWidth = 61;
	this.text.setTransform(825.2,82);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f().s("#000000").ss(3,1,1).p("AEriKQgHBvhRBOQhXBYh8AAQh7AAhYhYQhQhOgHhv");
	this.shape_6.setTransform(332.7,103,0.441,0.301,0,0,0,0,-0.1);

	this.text_1 = new cjs.Text("¿A – dón – de - te es – con – dis - te,\nA – ma - do, y – me – de – xas – te – con – ge – mi - do?\nCo - mo el – ci - er - vo hu – ys – te\na – vién – do - me he – ri - do;\nsa – lí – tras – ti – cla – man - do - y e - ras – y - do.\n\nPas – to - res, - los – que – fuer – des\na – llá – por - las – ma – ja – das -  al -  o – te - ro,\nsi  - por – ven – tu – ra – vier – des\na - quél – que - yo – más – quie - ro,\nde – zil –de - que a – do – lez - co, - pe - no y – mue - ro.\n\nBus – can - do - mis – a – mo – res\ny - ré - por – e – sos – mon - tes - y – ri – be - ras;\nni – co – ge - ré - las – flo - res,\nni – te – me – ré - las – fie - ras.\ny – pas – sa – ré - los – fuer - tes - y – fron – te - ras. (…)", "italic 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 612;
	this.text_1.setTransform(143.4,82);
 
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame2_8());
        });
        
        this.cerrar.on("click", function (evt) {
            putStage(new lib.frame2_7());
        });
      
        

        this.addChild(this.logo, this.titulo,this.cerrar, this.home, this.informacion, this.anterior, this.texto, this.siguiente,this.instance,this.text_3, this.text_2,this.text_1,this.shape_6,this.text,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 
 
    (lib.frame2_info1 = function (retorno) {
        this.initialize();
        clearTexts();
        basicos(this, 0, 0, 0, 0, 1, 0);
       
         var html = createDiv(txt['text2_info'], "Verdana", "16px", '370px', '100px', "20px", "185px", "left");
             this.texto1 = new cjs.DOMElement(html);
        this.texto1.setTransform(130, -460);

         html = createDiv(txt['text2_infob'], "Verdana", "16px", '370px', '100px', "20px", "185px", "left");
             this.texto2 = new cjs.DOMElement(html);
        this.texto2.setTransform(460, -460);
        
    
        


        this.cerrar.on("click", function (evt) {
           
                putStage(new lib.frame2_4());
          
        });
        this.addChild(this.logo, this.titulo, this.cerrar, this.texto1, this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


  (lib.frame3_1 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 0, 1, 0, 0);

        titulo2(this, txt['tit3']);

        this.instance_1 = new lib.SantaTeresa0001MW01();
        this.instance_1.setTransform(516.7, 62.8, 0.695, 0.695);

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_2());
        });

        this.addChild(this.logo, this.home, this.titulo, this.siguiente, this.instance_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_2 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 0, 0);

        var html = createDiv(txt['text3_2'], "Verdana", "20px", '770px', '100px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 0);
        this.texto1.setTransform(100, -520);

        var flecha = new lib.flecharoja();
        this.shape = new lib.fadeElement(flecha, 25);
        this.shape.setTransform(100, 80);
        var html = createDiv(txt['text3_2b'], "Verdana", "20px", '770px', '100px', "20px", "185px", "left");
        this.texto2 = new lib.fadeText(html, 45);
        this.texto2.setTransform(100, -280);

        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_1());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });

        this.addChild(this.logo, this.home, this.anterior, this.texto1, this.siguiente, this.shape, this.shape_1, this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_3 = function () {
         var audioOn=false;
         
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 1, 0, 1);
        titulo2(this, txt['tit3_3']);
        var html = createDiv(txt['text3_3'], "Verdana", "20px", '450px', '100px', "20px", "185px", "left");
        this.texto1 = new lib.fadeText(html, 0);
        this.texto1.setTransform(100, -480);

        var flecha = new lib._000FOA01();
        this.instance = new lib.fadeElement(flecha, 25);
        this.instance.setTransform(740, 220, .545, .545, 0, 0, 0, 301.7, 148.8);

        this.audioplay.on("click", function (evt) {
            
               if (window.reproductor === undefined || window.reproductor===null)
                reproductor = cjs.Sound.play("misonido2");
            else
                reproductor.resume();
             audioOn=true;
            this.visible = false;
            this.parent.audiopause.visible = true;
        });

        this.audiopause.on("click", function (evt) {
            reproductor.pause();
              audioOn=false;
         
            this.visible = false;
            this.parent.audioplay.visible = true;
        });

        this.home.on("click", function (evt) {
             if (window.reproductor !== undefined){
                 if (audioOn)
            reproductor.stop();
            reproductor=null;
            }
            putStage(new lib.frame1());
        });
        this.informacion.on("click", function (evt) {
             if (window.reproductor !== undefined){
                 if (audioOn)
            reproductor.stop();
            reproductor=null;
            }
            putStage(new lib.frame3_info1());
        });
        this.anterior.on("click", function (evt) {
             if (window.reproductor !== undefined){
                 if (audioOn)
            reproductor.stop();
            reproductor=null;
            }
            putStage(new lib.frame3_2());
        });
        this.siguiente.on("click", function (evt) {
             if (window.reproductor !== undefined){
                 if (audioOn)
            reproductor.stop();
            reproductor=null;
            }
            putStage(new lib.frame3_4());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto1, this.siguiente, this.instance, this.audioplay, this.audiopause);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_4 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1, 0, 0, 0);
        titulo2(this, txt['tit3_4'],"25px");

        texto(this, txt['text3_4'], 0, 00,-482);

var html = createDiv(txt['text3_4b'], "Verdana", "20px", '370px', '100px', "20px", "185px", "left");
             this.texto1 = new cjs.DOMElement(html);
        this.texto1.setTransform(100, -420);

         html = createDiv(txt['text3_4c'], "Verdana", "20px", '370px', '100px', "20px", "185px", "left");
             this.texto2 = new cjs.DOMElement(html);
        this.texto2.setTransform(510, -420);
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_3());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto, this.siguiente, this.texto1, this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame3_5 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 1,0, 0, 0);
        titulo2(this, txt['tit3_5']);

       this.text = new cjs.Text("b\ne\ne\nd\nd\nd\nd", "bold 16px Verdana", "#B30218");
	this.text.lineHeight = 18;
	this.text.lineWidth = 41;
	this.text.setTransform(868.7,185.5);

	this.text_1 = new cjs.Text("a\nb\nb\n\na\nc\nc\na\na\nb\nb", "bold 16px Verdana", "#B30218");
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 144;
	this.text_1.setTransform(446.2,185.5);

	this.text_2 = new cjs.Text("¡Ay, - qué – lar - ga es – es - ta – vi - da!\n¡Qué – du - ros – es - tos – des – tier - ros,\nes - ta – cár - cel, - es - tos – hier - ros\nen - que el – al - ma es - tá – me – ti - da!\nSo - lo es – pe - rar - la – sa – li – da\nme – cau - sa – do - lor - tan – fie - ro,\nque – mue - ro – por - que - no – mue - ro. (…)", "italic 16px Verdana");
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 359;
	this.text_2.setTransform(491.5,185.5);

	this.text_3 = new cjs.Text("Vi – vo - sin – vi – vir - en - mí, (7+1)\ny - de - tal – ma – ne - ra  es – pe - ro,\nque – mue - ro – por - que - no – mue - ro.\n\nVi - vo - ya – fue - ra - de – mí (7+1)\ndes - pués - que – mue - ro - de a - mor; (7+1)\npor - que – vi - vo en - el – Se - ñor, (7+1)\nque - me – qui - so – pa - ra - sí; (7+1)\ncuan - do el – co – ra - zón - le – di (7+1)\npu - se en - él – es - te – le – tre - ro:\nque  - mue - ro – por - que - no – mue - ro.\n\n  (…)", "italic 16px Verdana");
	this.text_3.lineHeight = 18;
	this.text_3.lineWidth = 400;
	this.text_3.setTransform(41,185.5);

	this.text_4 = new cjs.Text("8\n8\n8\n8\n8\n8\n8", "bold 16px Verdana", "#187E1B");
	this.text_4.lineHeight = 18;
	this.text_4.lineWidth = 41;
	this.text_4.setTransform(856.5,185.5);

	this.text_5 = new cjs.Text("8\n8\n8\n\n8\n8\n8\n8\n8\n8\n8", "bold 16px Verdana", "#187E1B");
	this.text_5.lineHeight = 18;
	this.text_5.lineWidth = 42;
	this.text_5.setTransform(431.5,185.5);


        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
       
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_4());
        });
        this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3_6());
        });

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.texto, this.siguiente,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


    (lib.frame3_6 = function () {
        this.initialize();
        clearTexts();
        basicos(this, 1, 1, 0, 0, 0, 0);
        titulo2(this, txt['tit3_6']);
 
        var html = createDiv(txt['text3_6'], "Verdana", "18px", '370px', '100px', "20px", "185px", "left");
             this.texto1 = new cjs.DOMElement(html);
        this.texto1.setTransform(300, -530);

	this.instance_1 = new lib.figuras();
	this.instance_1.setTransform(430,363,1,1,0,0,0,301.9,288.9);
        
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
      
        this.anterior.on("click", function (evt) {
            putStage(new lib.frame3_5());
        });
       

        this.addChild(this.logo, this.titulo, this.home, this.informacion, this.anterior, this.text, this.shape,this.instance_1,this.texto1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 
(lib.frame3_info1 = function (retorno) {
        this.initialize();
        clearTexts();
        basicos(this, 0, 0, 0, 0, 1, 0);
       titulo2(this,txt['tit3_info']);
         var html = createDiv(txt['text3_info'], "Verdana", "16px", '770px', '100px', "20px", "185px", "left");
             this.texto1 = new cjs.DOMElement(html);
        this.texto1.setTransform(100, -490);

        
    
        


        this.cerrar.on("click", function (evt) {
           
                putStage(new lib.frame3_3());
          
        });
        this.addChild(this.logo, this.titulo, this.cerrar, this.texto1, this.texto2);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top||-532;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

   /* function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(190.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(167, 578, 1.44, 1.44);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(167, 578, 1.44, 1.44);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }*/
    
     /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 578, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(232, 578, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }

(lib.figuras = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#334BEF").ss(2,1,1).p("AAAh4IAADy");
	this.shape.setTransform(142.9,361.1);

	this.text = new cjs.Text("exclamación", "bold 18px Verdana", "#334BEF");
	this.text.lineHeight = 20;
	this.text.setTransform(3.5,345.6);

	this.text_1 = new cjs.Text("paralelismo", "bold 18px Verdana", "#334BEF");
	this.text_1.lineHeight = 20;
	this.text_1.setTransform(11.3,54.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#334BEF").ss(2,1,1).p("AAAnrIAAPX");
	this.shape_1.setTransform(142.9,66.9,1,0.856);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#334BEF").ss(2,1,1).p("ADtAAInZAA");
	this.shape_2.setTransform(154.6,373.2,0.478,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#334BEF").ss(2,1,1).p("ADtAAInZAA");
	this.shape_3.setTransform(154.6,348.9,0.478,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f().s("#334BEF").ss(2,1,1).p("ADtAAInZAA");
	this.shape_4.setTransform(154.5,109.2,0.474,0.856);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f().s("#334BEF").ss(2,1,1).p("ADtAAInZAA");
	this.shape_5.setTransform(154.5,24.9,0.474,0.856);

	this.text_2 = new cjs.Text("paradoja\n\n\nparadoja\n\n\n\nhipérbole\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nmetáfora", "bold 16px Verdana", "#334BEF");
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 99;
	this.text_2.setTransform(457.5,9);

	

	this.addChild(this.text_2,this.shape_5,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.text_1,this.text,this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(3.5,11.9,527.4,452.5);


(lib.mc_h6_02 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Thinkstock_90358935();
	this.instance.setTransform(0,0,0.452,0.452);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,264.1,339.1);


(lib.mc_h6_01 = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.Thinkstock_83163341();
	this.instance.setTransform(0,0,0.452,0.452);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,264.1,339.1);


(lib.mc_h6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Thinkstock_90358935.jpg
	this.instance = new lib.mc_h6_02();
	this.instance.setTransform(555.1,169.6,1,1,0,0,0,132,169.6);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({regY:169.5,y:169.5},0).wait(18).wait(1).to({alpha:0.048},0).wait(1).to({alpha:0.095},0).wait(1).to({alpha:0.143},0).wait(1).to({alpha:0.19},0).wait(1).to({alpha:0.238},0).wait(1).to({alpha:0.286},0).wait(1).to({alpha:0.333},0).wait(1).to({alpha:0.381},0).wait(1).to({alpha:0.429},0).wait(1).to({alpha:0.476},0).wait(1).to({alpha:0.524},0).wait(1).to({alpha:0.571},0).wait(1).to({alpha:0.619},0).wait(1).to({alpha:0.667},0).wait(1).to({alpha:0.714},0).wait(1).to({alpha:0.762},0).wait(1).to({alpha:0.81},0).wait(1).to({alpha:0.857},0).wait(1).to({alpha:0.905},0).wait(1).to({alpha:0.952},0).wait(1).to({alpha:1},0).wait(2));

	// Thinkstock_83163341.jpg
	this.instance_1 = new lib.mc_h6_01();
	this.instance_1.setTransform(132,169.6,1,1,0,0,0,132,169.6);
	this.instance_1.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({regY:169.5,y:169.5,alpha:0.053},0).wait(1).to({alpha:0.105},0).wait(1).to({alpha:0.158},0).wait(1).to({alpha:0.211},0).wait(1).to({alpha:0.263},0).wait(1).to({alpha:0.316},0).wait(1).to({alpha:0.368},0).wait(1).to({alpha:0.421},0).wait(1).to({alpha:0.474},0).wait(1).to({alpha:0.526},0).wait(1).to({alpha:0.579},0).wait(1).to({alpha:0.632},0).wait(1).to({alpha:0.684},0).wait(1).to({alpha:0.737},0).wait(1).to({alpha:0.789},0).wait(1).to({alpha:0.842},0).wait(1).to({alpha:0.895},0).wait(1).to({alpha:0.947},0).wait(1).to({alpha:1},0).wait(23));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,687.2,339.1);

(lib.mc_p6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 6 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("A70BSIAAijMA3pAAAIAACjg");
	var mask_graphics_118 = new cjs.Graphics().p("A70BSIAAijMA3pAAAIAACjg");
	var mask_graphics_119 = new cjs.Graphics().p("A70BtIAAjZMA3pAAAIAADZg");
	var mask_graphics_120 = new cjs.Graphics().p("A70CHIAAkNMA3pAAAIAAENg");
	var mask_graphics_121 = new cjs.Graphics().p("A70CiIAAlDMA3pAAAIAAFDg");
	var mask_graphics_122 = new cjs.Graphics().p("A70C8IAAl3MA3pAAAIAAF3g");
	var mask_graphics_123 = new cjs.Graphics().p("A70DXIAAmtMA3pAAAIAAGtg");
	var mask_graphics_124 = new cjs.Graphics().p("A70DxIAAnhMA3pAAAIAAHhg");
	var mask_graphics_125 = new cjs.Graphics().p("A70EMIAAoXMA3pAAAIAAIXg");
	var mask_graphics_126 = new cjs.Graphics().p("A70EmIAApLMA3pAAAIAAJLg");
	var mask_graphics_127 = new cjs.Graphics().p("A70FBIAAqBMA3pAAAIAAKBg");
	var mask_graphics_128 = new cjs.Graphics().p("A70FbIAAq1MA3pAAAIAAK1g");
	var mask_graphics_129 = new cjs.Graphics().p("A70F2IAArrMA3pAAAIAALrg");
	var mask_graphics_130 = new cjs.Graphics().p("A70GQIAAsfMA3pAAAIAAMfg");
	var mask_graphics_131 = new cjs.Graphics().p("A70GrIAAtVMA3pAAAIAANVg");
	var mask_graphics_132 = new cjs.Graphics().p("A70HFIAAuJMA3pAAAIAAOJg");
	var mask_graphics_133 = new cjs.Graphics().p("A70HgIAAu/MA3pAAAIAAO/g");
	var mask_graphics_134 = new cjs.Graphics().p("A70H7IAAv1MA3pAAAIAAP1g");
	var mask_graphics_135 = new cjs.Graphics().p("A70IVIAAwpMA3pAAAIAAQpg");
	var mask_graphics_136 = new cjs.Graphics().p("A70IwIAAxfMA3pAAAIAARfg");
	var mask_graphics_137 = new cjs.Graphics().p("A70JKIAAyTMA3pAAAIAASTg");
	var mask_graphics_138 = new cjs.Graphics().p("A70JlIAAzJMA3pAAAIAATJg");
	var mask_graphics_139 = new cjs.Graphics().p("A70J/IAAz9MA3pAAAIAAT9g");
	var mask_graphics_140 = new cjs.Graphics().p("A70KaIAA0zMA3pAAAIAAUzg");
	var mask_graphics_141 = new cjs.Graphics().p("A70K0IAA1nMA3pAAAIAAVng");
	var mask_graphics_142 = new cjs.Graphics().p("A70LPIAA2dMA3pAAAIAAWdg");
	var mask_graphics_143 = new cjs.Graphics().p("A70LpIAA3RMA3pAAAIAAXRg");
	var mask_graphics_144 = new cjs.Graphics().p("A70MEIAA4HMA3pAAAIAAYHg");
	var mask_graphics_145 = new cjs.Graphics().p("A70MeIAA47MA3pAAAIAAY7g");
	var mask_graphics_146 = new cjs.Graphics().p("A70M5IAA5xMA3pAAAIAAZxg");
	var mask_graphics_147 = new cjs.Graphics().p("A70NTIAA6lMA3pAAAIAAalg");
	var mask_graphics_148 = new cjs.Graphics().p("A70NuIAA7bMA3pAAAIAAbbg");
	var mask_graphics_149 = new cjs.Graphics().p("A70OJIAA8RMA3pAAAIAAcRg");
	var mask_graphics_150 = new cjs.Graphics().p("A70OjIAA9FMA3pAAAIAAdFg");
	var mask_graphics_151 = new cjs.Graphics().p("A70O+IAA97MA3pAAAIAAd7g");
	var mask_graphics_152 = new cjs.Graphics().p("A70PYIAA+vMA3pAAAIAAevg");
	var mask_graphics_153 = new cjs.Graphics().p("A70PzIAA/lMA3pAAAIAAflg");
	var mask_graphics_154 = new cjs.Graphics().p("A70QNMAAAggZMA3pAAAMAAAAgZg");
	var mask_graphics_155 = new cjs.Graphics().p("A70QoMAAAghPMA3pAAAMAAAAhPg");
	var mask_graphics_156 = new cjs.Graphics().p("A70RCMAAAgiDMA3pAAAMAAAAiDg");
	var mask_graphics_157 = new cjs.Graphics().p("A70RdMAAAgi5MA3pAAAMAAAAi5g");
	var mask_graphics_158 = new cjs.Graphics().p("A70R3MAAAgjtMA3pAAAMAAAAjtg");
	var mask_graphics_159 = new cjs.Graphics().p("A70SSMAAAgkjMA3pAAAMAAAAkjg");
	var mask_graphics_160 = new cjs.Graphics().p("A70SsMAAAglXMA3pAAAMAAAAlXg");
	var mask_graphics_161 = new cjs.Graphics().p("A70THMAAAgmNMA3pAAAMAAAAmNg");
	var mask_graphics_162 = new cjs.Graphics().p("A70ThMAAAgnBMA3pAAAMAAAAnBg");
	var mask_graphics_163 = new cjs.Graphics().p("A70T8MAAAgn3MA3pAAAMAAAAn3g");
	var mask_graphics_164 = new cjs.Graphics().p("A70UXMAAAgotMA3pAAAMAAAAotg");
	var mask_graphics_165 = new cjs.Graphics().p("A70UxMAAAgphMA3pAAAMAAAAphg");
	var mask_graphics_166 = new cjs.Graphics().p("A70VMMAAAgqXMA3pAAAMAAAAqXg");
	var mask_graphics_167 = new cjs.Graphics().p("A70VmMAAAgrLMA3pAAAMAAAArLg");
	var mask_graphics_168 = new cjs.Graphics().p("A70WBMAAAgsBMA3pAAAMAAAAsBg");
	var mask_graphics_169 = new cjs.Graphics().p("A70WbMAAAgs1MA3pAAAMAAAAs1g");
	var mask_graphics_170 = new cjs.Graphics().p("A70W2MAAAgtrMA3pAAAMAAAAtrg");
	var mask_graphics_171 = new cjs.Graphics().p("A70XQMAAAgufMA3pAAAMAAAAufg");
	var mask_graphics_172 = new cjs.Graphics().p("A70XrMAAAgvVMA3pAAAMAAAAvVg");
	var mask_graphics_173 = new cjs.Graphics().p("A70YFMAAAgwJMA3pAAAMAAAAwJg");
	var mask_graphics_174 = new cjs.Graphics().p("A70YgMAAAgw/MA3pAAAMAAAAw/g");
	var mask_graphics_175 = new cjs.Graphics().p("A70Y6MAAAgxzMA3pAAAMAAAAxzg");
	var mask_graphics_176 = new cjs.Graphics().p("A70ZVMAAAgypMA3pAAAMAAAAypg");
	var mask_graphics_177 = new cjs.Graphics().p("AFFcTMAAAgzeMA3rAAAMAAAAzeg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:599.5,y:41.2}).wait(118).to({graphics:mask_graphics_118,x:599.5,y:41.2}).wait(1).to({graphics:mask_graphics_119,x:599.5,y:43.8}).wait(1).to({graphics:mask_graphics_120,x:599.5,y:46.5}).wait(1).to({graphics:mask_graphics_121,x:599.5,y:49.1}).wait(1).to({graphics:mask_graphics_122,x:599.5,y:51.8}).wait(1).to({graphics:mask_graphics_123,x:599.5,y:54.4}).wait(1).to({graphics:mask_graphics_124,x:599.5,y:57.1}).wait(1).to({graphics:mask_graphics_125,x:599.5,y:59.7}).wait(1).to({graphics:mask_graphics_126,x:599.5,y:62.4}).wait(1).to({graphics:mask_graphics_127,x:599.5,y:65}).wait(1).to({graphics:mask_graphics_128,x:599.5,y:67.7}).wait(1).to({graphics:mask_graphics_129,x:599.5,y:70.3}).wait(1).to({graphics:mask_graphics_130,x:599.5,y:73}).wait(1).to({graphics:mask_graphics_131,x:599.5,y:75.6}).wait(1).to({graphics:mask_graphics_132,x:599.5,y:78.3}).wait(1).to({graphics:mask_graphics_133,x:599.5,y:80.9}).wait(1).to({graphics:mask_graphics_134,x:599.5,y:83.6}).wait(1).to({graphics:mask_graphics_135,x:599.5,y:86.2}).wait(1).to({graphics:mask_graphics_136,x:599.5,y:88.9}).wait(1).to({graphics:mask_graphics_137,x:599.5,y:91.5}).wait(1).to({graphics:mask_graphics_138,x:599.5,y:94.2}).wait(1).to({graphics:mask_graphics_139,x:599.5,y:96.8}).wait(1).to({graphics:mask_graphics_140,x:599.5,y:99.5}).wait(1).to({graphics:mask_graphics_141,x:599.5,y:102.1}).wait(1).to({graphics:mask_graphics_142,x:599.5,y:104.8}).wait(1).to({graphics:mask_graphics_143,x:599.5,y:107.4}).wait(1).to({graphics:mask_graphics_144,x:599.5,y:110.1}).wait(1).to({graphics:mask_graphics_145,x:599.5,y:112.7}).wait(1).to({graphics:mask_graphics_146,x:599.5,y:115.4}).wait(1).to({graphics:mask_graphics_147,x:599.5,y:118}).wait(1).to({graphics:mask_graphics_148,x:599.5,y:120.6}).wait(1).to({graphics:mask_graphics_149,x:599.5,y:123.3}).wait(1).to({graphics:mask_graphics_150,x:599.5,y:125.9}).wait(1).to({graphics:mask_graphics_151,x:599.5,y:128.6}).wait(1).to({graphics:mask_graphics_152,x:599.5,y:131.2}).wait(1).to({graphics:mask_graphics_153,x:599.5,y:133.9}).wait(1).to({graphics:mask_graphics_154,x:599.5,y:136.5}).wait(1).to({graphics:mask_graphics_155,x:599.5,y:139.2}).wait(1).to({graphics:mask_graphics_156,x:599.5,y:141.8}).wait(1).to({graphics:mask_graphics_157,x:599.5,y:144.5}).wait(1).to({graphics:mask_graphics_158,x:599.5,y:147.1}).wait(1).to({graphics:mask_graphics_159,x:599.5,y:149.8}).wait(1).to({graphics:mask_graphics_160,x:599.5,y:152.4}).wait(1).to({graphics:mask_graphics_161,x:599.5,y:155.1}).wait(1).to({graphics:mask_graphics_162,x:599.5,y:157.7}).wait(1).to({graphics:mask_graphics_163,x:599.5,y:160.4}).wait(1).to({graphics:mask_graphics_164,x:599.5,y:163}).wait(1).to({graphics:mask_graphics_165,x:599.5,y:165.7}).wait(1).to({graphics:mask_graphics_166,x:599.5,y:168.3}).wait(1).to({graphics:mask_graphics_167,x:599.5,y:171}).wait(1).to({graphics:mask_graphics_168,x:599.5,y:173.6}).wait(1).to({graphics:mask_graphics_169,x:599.5,y:176.3}).wait(1).to({graphics:mask_graphics_170,x:599.5,y:178.9}).wait(1).to({graphics:mask_graphics_171,x:599.5,y:181.6}).wait(1).to({graphics:mask_graphics_172,x:599.5,y:184.2}).wait(1).to({graphics:mask_graphics_173,x:599.5,y:186.9}).wait(1).to({graphics:mask_graphics_174,x:599.5,y:189.5}).wait(1).to({graphics:mask_graphics_175,x:599.5,y:192.2}).wait(1).to({graphics:mask_graphics_176,x:599.5,y:194.8}).wait(1).to({graphics:mask_graphics_177,x:388.8,y:181.1}).wait(13));

	// Capa 2
	this.text = new cjs.Text("LIRA", "20px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 22;
	this.text.lineWidth = 317;
	this.text.setTransform(572.7,71.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#243186").s().p("Ah0hkIDpAAIh1DJg");
	this.shape.setTransform(575.7,190.8);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#243186").s().p("Ag+D7IAAn1IB+AAIAAH1g");
	this.shape_1.setTransform(575.7,157.4);

	this.text_1 = new cjs.Text(txt['text1_7c'], "20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 317;
	this.text_1.setTransform(443.8,222);

	this.text.mask = this.shape.mask = this.shape_1.mask = this.text_1.mask = mask;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.shape_1},{t:this.shape},{t:this.text}]}).wait(190));

	// Capa 5 (mask)
	var mask_1 = new cjs.Shape();
	mask_1._off = true;
	var mask_1_graphics_0 = new cjs.Graphics().p("A6OBIIAAiPMA0dAAAIAACPg");
	var mask_1_graphics_33 = new cjs.Graphics().p("A6OBIIAAiPMA0dAAAIAACPg");
	var mask_1_graphics_34 = new cjs.Graphics().p("A6OBkIAAjHMA0dAAAIAADHg");
	var mask_1_graphics_35 = new cjs.Graphics().p("A6OCAIAAj/MA0dAAAIAAD/g");
	var mask_1_graphics_36 = new cjs.Graphics().p("A6OCcIAAk3MA0dAAAIAAE3g");
	var mask_1_graphics_37 = new cjs.Graphics().p("A6OC3IAAltMA0dAAAIAAFtg");
	var mask_1_graphics_38 = new cjs.Graphics().p("A6ODTIAAmlMA0dAAAIAAGlg");
	var mask_1_graphics_39 = new cjs.Graphics().p("A6ODvIAAndMA0dAAAIAAHdg");
	var mask_1_graphics_40 = new cjs.Graphics().p("A6OELIAAoVMA0dAAAIAAIVg");
	var mask_1_graphics_41 = new cjs.Graphics().p("A6OEnIAApNMA0dAAAIAAJNg");
	var mask_1_graphics_42 = new cjs.Graphics().p("A6OFCIAAqDMA0dAAAIAAKDg");
	var mask_1_graphics_43 = new cjs.Graphics().p("A6OFeIAAq7MA0dAAAIAAK7g");
	var mask_1_graphics_44 = new cjs.Graphics().p("A6OF6IAArzMA0dAAAIAALzg");
	var mask_1_graphics_45 = new cjs.Graphics().p("A6OGWIAAsrMA0dAAAIAAMrg");
	var mask_1_graphics_46 = new cjs.Graphics().p("A6OGyIAAtjMA0dAAAIAANjg");
	var mask_1_graphics_47 = new cjs.Graphics().p("A6OHNIAAuZMA0dAAAIAAOZg");
	var mask_1_graphics_48 = new cjs.Graphics().p("A6OHpIAAvRMA0dAAAIAAPRg");
	var mask_1_graphics_49 = new cjs.Graphics().p("A6OIFIAAwJMA0dAAAIAAQJg");
	var mask_1_graphics_50 = new cjs.Graphics().p("A6OIhIAAxBMA0dAAAIAARBg");
	var mask_1_graphics_51 = new cjs.Graphics().p("A6OI9IAAx5MA0dAAAIAAR5g");
	var mask_1_graphics_52 = new cjs.Graphics().p("A6OJYIAAyvMA0dAAAIAASvg");
	var mask_1_graphics_53 = new cjs.Graphics().p("A6OJ0IAAznMA0dAAAIAATng");
	var mask_1_graphics_54 = new cjs.Graphics().p("A6OKQIAA0fMA0dAAAIAAUfg");
	var mask_1_graphics_55 = new cjs.Graphics().p("A6OKsIAA1XMA0dAAAIAAVXg");
	var mask_1_graphics_56 = new cjs.Graphics().p("A6OLIIAA2PMA0dAAAIAAWPg");
	var mask_1_graphics_57 = new cjs.Graphics().p("A6OLjIAA3FMA0dAAAIAAXFg");
	var mask_1_graphics_58 = new cjs.Graphics().p("A6OL/IAA39MA0dAAAIAAX9g");
	var mask_1_graphics_59 = new cjs.Graphics().p("A6OMbIAA41MA0dAAAIAAY1g");
	var mask_1_graphics_60 = new cjs.Graphics().p("A6OM3IAA5tMA0dAAAIAAZtg");
	var mask_1_graphics_61 = new cjs.Graphics().p("A6ONSIAA6jMA0dAAAIAAajg");
	var mask_1_graphics_62 = new cjs.Graphics().p("A6ONuIAA7bMA0dAAAIAAbbg");
	var mask_1_graphics_63 = new cjs.Graphics().p("A6OOKIAA8TMA0dAAAIAAcTg");
	var mask_1_graphics_64 = new cjs.Graphics().p("A6OOmIAA9LMA0dAAAIAAdLg");
	var mask_1_graphics_65 = new cjs.Graphics().p("A6OPCIAA+DMA0dAAAIAAeDg");
	var mask_1_graphics_66 = new cjs.Graphics().p("A6OPdIAA+5MA0dAAAIAAe5g");
	var mask_1_graphics_67 = new cjs.Graphics().p("A6OP5IAA/xMA0dAAAIAAfxg");
	var mask_1_graphics_68 = new cjs.Graphics().p("A6OQVMAAAggpMA0dAAAMAAAAgpg");
	var mask_1_graphics_69 = new cjs.Graphics().p("A6OQxMAAAghhMA0dAAAMAAAAhhg");
	var mask_1_graphics_70 = new cjs.Graphics().p("A6ORNMAAAgiZMA0dAAAMAAAAiZg");
	var mask_1_graphics_71 = new cjs.Graphics().p("A6ORoMAAAgjPMA0dAAAMAAAAjPg");
	var mask_1_graphics_72 = new cjs.Graphics().p("A6OSEMAAAgkHMA0dAAAMAAAAkHg");
	var mask_1_graphics_73 = new cjs.Graphics().p("A6OSgMAAAgk/MA0dAAAMAAAAk/g");
	var mask_1_graphics_74 = new cjs.Graphics().p("A6OS8MAAAgl3MA0dAAAMAAAAl3g");
	var mask_1_graphics_75 = new cjs.Graphics().p("A6OTYMAAAgmvMA0dAAAMAAAAmvg");
	var mask_1_graphics_76 = new cjs.Graphics().p("A6OTzMAAAgnlMA0dAAAMAAAAnlg");
	var mask_1_graphics_77 = new cjs.Graphics().p("A6OUPMAAAgodMA0dAAAMAAAAodg");
	var mask_1_graphics_78 = new cjs.Graphics().p("A6OUrMAAAgpVMA0dAAAMAAAApVg");
	var mask_1_graphics_79 = new cjs.Graphics().p("A6OVHMAAAgqNMA0dAAAMAAAAqNg");
	var mask_1_graphics_80 = new cjs.Graphics().p("A6OVjMAAAgrFMA0dAAAMAAAArFg");
	var mask_1_graphics_81 = new cjs.Graphics().p("A6OV+MAAAgr7MA0dAAAMAAAAr7g");
	var mask_1_graphics_82 = new cjs.Graphics().p("A6OWaMAAAgszMA0dAAAMAAAAszg");
	var mask_1_graphics_83 = new cjs.Graphics().p("A6OW2MAAAgtrMA0dAAAMAAAAtrg");
	var mask_1_graphics_84 = new cjs.Graphics().p("A6OXSMAAAgujMA0dAAAMAAAAujg");
	var mask_1_graphics_85 = new cjs.Graphics().p("A6OXuMAAAgvbMA0dAAAMAAAAvbg");
	var mask_1_graphics_86 = new cjs.Graphics().p("A6OYJMAAAgwRMA0dAAAMAAAAwRg");
	var mask_1_graphics_87 = new cjs.Graphics().p("A6OYlMAAAgxJMA0dAAAMAAAAxJg");
	var mask_1_graphics_88 = new cjs.Graphics().p("A6OZBMAAAgyBMA0dAAAMAAAAyBg");
	var mask_1_graphics_89 = new cjs.Graphics().p("A6OZdMAAAgy5MA0dAAAMAAAAy5g");
	var mask_1_graphics_90 = new cjs.Graphics().p("A5sciMAAAgzwMA0dAAAMAAAAzwg");

	this.timeline.addTween(cjs.Tween.get(mask_1).to({graphics:mask_1_graphics_0,x:167,y:41.2}).wait(33).to({graphics:mask_1_graphics_33,x:167,y:41.2}).wait(1).to({graphics:mask_1_graphics_34,x:167.1,y:44}).wait(1).to({graphics:mask_1_graphics_35,x:167.2,y:46.8}).wait(1).to({graphics:mask_1_graphics_36,x:167.4,y:49.6}).wait(1).to({graphics:mask_1_graphics_37,x:167.5,y:52.3}).wait(1).to({graphics:mask_1_graphics_38,x:167.6,y:55.1}).wait(1).to({graphics:mask_1_graphics_39,x:167.8,y:57.9}).wait(1).to({graphics:mask_1_graphics_40,x:167.9,y:60.7}).wait(1).to({graphics:mask_1_graphics_41,x:168,y:63.5}).wait(1).to({graphics:mask_1_graphics_42,x:168.2,y:66.2}).wait(1).to({graphics:mask_1_graphics_43,x:168.3,y:69}).wait(1).to({graphics:mask_1_graphics_44,x:168.4,y:71.8}).wait(1).to({graphics:mask_1_graphics_45,x:168.6,y:74.6}).wait(1).to({graphics:mask_1_graphics_46,x:168.7,y:77.4}).wait(1).to({graphics:mask_1_graphics_47,x:168.9,y:80.1}).wait(1).to({graphics:mask_1_graphics_48,x:169,y:82.9}).wait(1).to({graphics:mask_1_graphics_49,x:169.1,y:85.7}).wait(1).to({graphics:mask_1_graphics_50,x:169.3,y:88.5}).wait(1).to({graphics:mask_1_graphics_51,x:169.4,y:91.3}).wait(1).to({graphics:mask_1_graphics_52,x:169.5,y:94}).wait(1).to({graphics:mask_1_graphics_53,x:169.7,y:96.8}).wait(1).to({graphics:mask_1_graphics_54,x:169.8,y:99.6}).wait(1).to({graphics:mask_1_graphics_55,x:169.9,y:102.4}).wait(1).to({graphics:mask_1_graphics_56,x:170.1,y:105.2}).wait(1).to({graphics:mask_1_graphics_57,x:170.2,y:107.9}).wait(1).to({graphics:mask_1_graphics_58,x:170.3,y:110.7}).wait(1).to({graphics:mask_1_graphics_59,x:170.5,y:113.5}).wait(1).to({graphics:mask_1_graphics_60,x:170.6,y:116.3}).wait(1).to({graphics:mask_1_graphics_61,x:170.8,y:119}).wait(1).to({graphics:mask_1_graphics_62,x:170.9,y:121.8}).wait(1).to({graphics:mask_1_graphics_63,x:171,y:124.6}).wait(1).to({graphics:mask_1_graphics_64,x:171.2,y:127.4}).wait(1).to({graphics:mask_1_graphics_65,x:171.3,y:130.2}).wait(1).to({graphics:mask_1_graphics_66,x:171.4,y:132.9}).wait(1).to({graphics:mask_1_graphics_67,x:171.6,y:135.7}).wait(1).to({graphics:mask_1_graphics_68,x:171.7,y:138.5}).wait(1).to({graphics:mask_1_graphics_69,x:171.8,y:141.3}).wait(1).to({graphics:mask_1_graphics_70,x:172,y:144.1}).wait(1).to({graphics:mask_1_graphics_71,x:172.1,y:146.8}).wait(1).to({graphics:mask_1_graphics_72,x:172.3,y:149.6}).wait(1).to({graphics:mask_1_graphics_73,x:172.4,y:152.4}).wait(1).to({graphics:mask_1_graphics_74,x:172.5,y:155.2}).wait(1).to({graphics:mask_1_graphics_75,x:172.7,y:158}).wait(1).to({graphics:mask_1_graphics_76,x:172.8,y:160.7}).wait(1).to({graphics:mask_1_graphics_77,x:172.9,y:163.5}).wait(1).to({graphics:mask_1_graphics_78,x:173.1,y:166.3}).wait(1).to({graphics:mask_1_graphics_79,x:173.2,y:169.1}).wait(1).to({graphics:mask_1_graphics_80,x:173.3,y:171.9}).wait(1).to({graphics:mask_1_graphics_81,x:173.5,y:174.6}).wait(1).to({graphics:mask_1_graphics_82,x:173.6,y:177.4}).wait(1).to({graphics:mask_1_graphics_83,x:173.7,y:180.2}).wait(1).to({graphics:mask_1_graphics_84,x:173.9,y:183}).wait(1).to({graphics:mask_1_graphics_85,x:174,y:185.8}).wait(1).to({graphics:mask_1_graphics_86,x:174.2,y:188.5}).wait(1).to({graphics:mask_1_graphics_87,x:174.3,y:191.3}).wait(1).to({graphics:mask_1_graphics_88,x:174.4,y:194.1}).wait(1).to({graphics:mask_1_graphics_89,x:174.6,y:196.9}).wait(1).to({graphics:mask_1_graphics_90,x:171.3,y:182.7}).wait(100));

	// Capa 3
	this.text_2 = new cjs.Text("ODA", "20px Verdana");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 22;
	this.text_2.lineWidth = 300;
	this.text_2.setTransform(164.5,71.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#243186").s().p("Ah0hkIDpAAIh1DJg");
	this.shape_2.setTransform(168.9,190.8);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#243186").s().p("Ag+D7IAAn1IB+AAIAAH1g");
	this.shape_3.setTransform(168.9,157.4);

	this.text_3 = new cjs.Text(txt['text1_7b'], "20px Verdana");
	this.text_3.lineHeight = 22;
	this.text_3.lineWidth = 300;
	this.text_3.setTransform(21.4,222);

	this.text_2.mask = this.shape_2.mask = this.shape_3.mask = this.text_3.mask = mask_1;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_3},{t:this.shape_3},{t:this.shape_2},{t:this.text_2}]}).wait(190));

	

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,788.4,329.2);


    (lib.flecha = function () {
        this.initialize();

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#000000").s().p("Ah0hkIDpAAIh1DJg");
        this.shape.setTransform(376.2, 228.3);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#000000").s().p("Ag+D7IAAn1IB+AAIAAH1g");
        this.shape_1.setTransform(376.2, 194.9);

        this.addChild(this.shape, this.shape_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 100);
 (lib.flecharoja = function () {
        this.initialize();

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#B30218").s().p("Ah0hkIDpAAIh1DJg");
        this.shape.setTransform(376.2, 228.3);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#B30218").s().p("Ag+D7IAAn1IB+AAIAAH1g");
        this.shape_1.setTransform(376.2, 194.9);

        this.addChild(this.shape, this.shape_1);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 100);
    (lib.btn_01 = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("AtHcHMAAAg4NIaPAAMAAAA4Ng");
        this.shape.setTransform(84, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("rgba(0,255,255,0.502)").s().p("AtHcHMAAAg4NIaPAAMAAAA4Ng");
        this.shape_1.setTransform(84, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: []}).to({state: [{t: this.shape}]}, 1).to({state: []}, 1).to({state: [{t: this.shape_1}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 0, 0);


    (lib._000FOA01 = function () {
        this.initialize(img._000FOA01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 546, 768);


    (lib.FrayLuisdeLeon = function () {
        this.initialize(img.FrayLuisdeLeon);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 323, 700);


    (lib.FrayLuisdeLeon_1 = function () {
        this.initialize(img.FrayLuisdeLeon_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 435, 708);



    (lib.SanJuan000M3U01 = function () {
        this.initialize(img.SanJuan000M3U01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 520, 750);


    (lib.SanJuan000M3U01_1 = function () {
        this.initialize(img.SanJuan000M3U01_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 323, 700);


    (lib.SantaTeresa0001MW01 = function () {
        this.initialize(img.SantaTeresa0001MW01);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 515, 646);


    (lib.SantaTeresa0001MW01_1 = function () {
        this.initialize(img.SantaTeresa0001MW01_1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 323, 700);


    (lib.Thinkstock_108684726 = function () {
        this.initialize(img.Thinkstock_108684726);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 489, 750);


    (lib.Thinkstock_200367652001 = function () {
        this.initialize(img.Thinkstock_200367652001);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 1580, 779);


    (lib.Thinkstock_83163341 = function () {
        this.initialize(img.Thinkstock_83163341);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 584, 750);


    (lib.Thinkstock_90358935 = function () {
        this.initialize(img.Thinkstock_90358935);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 584, 750);


    (lib.Txt1 = function () {
        this.initialize(img.Txt1);
    }).prototype = p = new cjs.Bitmap();
    p.nominalBounds = new cjs.Rectangle(0, 0, 215, 468);


    (lib.btn_AudioPlay_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#FFFFFF").p("AgUhxQAWAZALApQAXBQg4BT");
        this.shape.setTransform(6.8, 0, 0.697, 0.697);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").p("AgLhEIAIAKQAGAOAFAQQAOAvghAz");
        this.shape_1.setTransform(4.5, 0, 0.697, 0.697);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#FFFFFF").p("AgGglIAKAWQAIAZgSAc");
        this.shape_2.setTransform(2.5, 0.1, 0.697, 0.697);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").p("AAchWIAACuIg3gwIAAhIg");
        this.shape_3.setTransform(-2.2, -0.1, 0.697, 0.697);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#1D1D1B").s().p("AgbAoIAAhJIA3g1IAACtg");
        this.shape_4.setTransform(-2.2, 0, 0.697, 0.697);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f().s("#FFFFFF").p("AgZgmQgGAAAAAIIAAA9QAAAIAGAAIA0AAQAFAAAAgIIAAg9QAAgDgBgDQgCgCgCAAg");
        this.shape_5.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_6 = new cjs.Shape();
        this.shape_6.graphics.f("#1D1D1B").s().p("AgZAnQgGAAAAgIIAAg9QAAgIAGAAIA0AAQAAAAABAAQABAAAAABQAAAAABAAQAAABABAAQABADAAADIAAA9QAAAIgFAAg");
        this.shape_6.setTransform(-6.5, 0, 0.697, 0.697);

        this.shape_7 = new cjs.Shape();
        this.shape_7.graphics.f().s("#1D1D1B").p("ACWiBIAAEDQAAAJgGAFQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkDQAAgIAGgGQAFgGAIAAIEFAAQAIAAAFAGQAGAGAAAIg");
        this.shape_7.setTransform(0, 0, 0.697, 0.697);

        this.shape_8 = new cjs.Shape();
        this.shape_8.graphics.f("#1D1D1B").s().p("AiCCWQgHgBgGgFQgGgGABgIIAAkDQgBgIAGgGQAGgGAHABIEFAAQAIgBAFAGQAFAGABAIIAAEDQgBAIgFAGQgFAFgIABg");
        this.shape_8.setTransform(0, 0, 0.697, 0.697);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}).to({state: [{t: this.shape_8, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_7, p: {scaleX: 0.766, scaleY: 0.766}}, {t: this.shape_6, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_5, p: {scaleX: 0.766, scaleY: 0.766, x: -7.2}}, {t: this.shape_4, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5, y: -0.1}}, {t: this.shape_3, p: {scaleX: 0.766, scaleY: 0.766, x: -2.5}}, {t: this.shape_2, p: {scaleX: 0.766, scaleY: 0.766, x: 2.8, y: 0}}, {t: this.shape_1, p: {scaleX: 0.766, scaleY: 0.766, x: 5}}, {t: this.shape, p: {scaleX: 0.766, scaleY: 0.766, x: 7.5}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).to({state: [{t: this.shape_8, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_7, p: {scaleX: 0.697, scaleY: 0.697}}, {t: this.shape_6, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_5, p: {scaleX: 0.697, scaleY: 0.697, x: -6.5}}, {t: this.shape_4, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2, y: 0}}, {t: this.shape_3, p: {scaleX: 0.697, scaleY: 0.697, x: -2.2}}, {t: this.shape_2, p: {scaleX: 0.697, scaleY: 0.697, x: 2.5, y: 0.1}}, {t: this.shape_1, p: {scaleX: 0.697, scaleY: 0.697, x: 4.5}}, {t: this.shape, p: {scaleX: 0.697, scaleY: 0.697, x: 6.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 30, 30);


    (lib.btn_AudioPause_ok = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#1D1D1B").p("AAbA8QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape.setTransform(3, 0, 0.7, 0.7);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_1.setTransform(3, 0, 0.7, 0.7);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1D1D1B").p("AAbg7IAAB3QAAALgIAIQgIAIgLAAQgKAAgIgIQgIgIAAgLIAAh3QAAgLAIgIQAIgIAKAAQALAAAIAIQAIAIAAALg");
        this.shape_2.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#FFFFFF").s().p("AgSBPQgIgIAAgMIAAh1QAAgMAIgIQAIgIAKAAQALAAAIAIQAIAIAAAMIAAB1QAAAMgIAIQgIAIgLAAQgKAAgIgIg");
        this.shape_3.setTransform(-3.2, 0, 0.7, 0.7);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f().s("#1D1D1B").p("ACWiCIAAEEQAAAIgGAGQgFAGgIAAIkFAAQgIAAgFgGQgGgGAAgIIAAkEQAAgIAGgFQAFgGAIAAIEFAAQAIAAAFAGQAGAFAAAIg");
        this.shape_4.setTransform(0, 0, 0.7, 0.7);

        this.shape_5 = new cjs.Shape();
        this.shape_5.graphics.f("#1D1D1B").s().p("AiCCWQgIAAgFgHQgGgFABgIIAAkDQgBgJAGgFQAFgGAIABIEFAAQAHgBAGAGQAFAFABAJIAAEDQgBAIgFAFQgGAHgHAAg");
        this.shape_5.setTransform(0, 0, 0.7, 0.7);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}).to({state: [{t: this.shape_5, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_4, p: {scaleX: 0.77, scaleY: 0.77}}, {t: this.shape_3, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_2, p: {scaleX: 0.77, scaleY: 0.77, x: -3.6, y: -0.1}}, {t: this.shape_1, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}, {t: this.shape, p: {scaleX: 0.77, scaleY: 0.77, x: 3.2, y: -0.1}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).to({state: [{t: this.shape_5, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_4, p: {scaleX: 0.7, scaleY: 0.7}}, {t: this.shape_3, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_2, p: {scaleX: 0.7, scaleY: 0.7, x: -3.2, y: 0}}, {t: this.shape_1, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}, {t: this.shape, p: {scaleX: 0.7, scaleY: 0.7, x: 3, y: 0}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-10.5, -10.4, 21, 21);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}