(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 0, 0, 0, 0, 0);
        titulo1(this,txt['titulo']);


// Capa 1
	this.btn_03 = new lib.btn_01();
	this.btn_03.setTransform(562.7,482.6,1.006,1.294);
	new cjs.ButtonHelper(this.btn_03, 0, 1, 2, false, new lib.btn_01(), 3);
  this.btn_03.on("click", function (evt) {
        putStage(new lib.frame4());
    });

	this.btn_01 = new lib.btn_01();
	this.btn_01.setTransform(125.6,482.6,1.036,1.294);
	new cjs.ButtonHelper(this.btn_01, 0, 1, 2, false, new lib.btn_01(), 3);
  this.btn_01.on("click", function (evt) {
        putStage(new lib.frame2());
    });
	this.btn_04 = new lib.btn_01();
	this.btn_04.setTransform(782.8,482.6,1.039,1.294);
	new cjs.ButtonHelper(this.btn_04, 0, 1, 2, false, new lib.btn_01(), 3);
  this.btn_04.on("click", function (evt) {
        putStage(new lib.frame5());
    });

	this.btn_02 = new lib.btn_01();
	this.btn_02.setTransform(345.4,482.6,1.006,1.294);
	new cjs.ButtonHelper(this.btn_02, 0, 1, 2, false, new lib.btn_01(), 3);
  this.btn_02.on("click", function (evt) {
        putStage(new lib.frame3());
    });

	this.text = new cjs.Text(txt['intro_07'], "bold 13px Arial");
	this.text.textAlign = "center";
	this.text.lineHeight = 15;
	this.text.lineWidth = 248;
	this.text.setTransform(772.2,411.9);

	this.text_1 = new cjs.Text("1492\n\nDescubrimiento de América", "bold 14px Verdana");
	this.text_1.textAlign = "right";
	this.text_1.lineHeight = 11;
	this.text_1.lineWidth = 114;
	this.text_1.setTransform(801.8,151.5);
 var html = createDiv(txt['intro_05'], "Verdana", "14px", '120px', '40px', "20px", "185px", "right");
 html.style.lineHeight="110%";
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(801-120, 151-608);
	this.text_2 = new cjs.Text("1348\n\nPeste\nnegra", "bold 14px Verdana");
	this.text_2.textAlign = "right";
	this.text_2.lineHeight = 11;
	this.text_2.lineWidth = 46;
	this.text_2.setTransform(659.9,244.3);
html = createDiv(txt['intro_04'], "Verdana", "14px", '120px', '40px', "20px", "185px", "right");
 html.style.lineHeight="110%";
    this.text_2 = new cjs.DOMElement(html);
    this.text_2.setTransform(659-120, 244-608);
	this.text_3 = new cjs.Text("800\n\nImperio carolingio", "bold 14px Verdana");
	this.text_3.lineHeight = 11;
	this.text_3.lineWidth = 100;
	this.text_3.setTransform(383.5,244.3);
html = createDiv(txt['intro_03'], "Verdana", "14px", '120px', '40px', "20px", "185px", "left");
 html.style.lineHeight="110%";
    this.text_3 = new cjs.DOMElement(html);
    this.text_3.setTransform(383, 244-608);
	this.text_4 = new cjs.Text("622\n\nNacimiento del islam", "bold 14px Verdana");
	this.text_4.lineHeight = 11;
	this.text_4.lineWidth = 84;
	this.text_4.setTransform(214.8,244.3);
html = createDiv(txt['intro_02'], "Verdana", "14px", '120px', '40px', "20px", "185px", "left");
 html.style.lineHeight="110%";
    this.text_4 = new cjs.DOMElement(html);
    this.text_4.setTransform(214, 244-608);
	this.text_5 = new cjs.Text("476\n\nFin del Imperio romano de Occidente", "bold 14px Verdana");
	this.text_5.lineHeight = 11;
	this.text_5.lineWidth = 112;
	this.text_5.setTransform(128.8,151.5);
html = createDiv(txt['intro_01'], "Verdana", "14px", '120px', '40px', "20px", "185px", "left");
 html.style.lineHeight="100%";
    this.text_5 = new cjs.DOMElement(html);
    this.text_5.setTransform(129, 151-608);
	this.text_6 = new cjs.Text(txt['intro_06'], "bold 13px Arial");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 15;
	this.text_6.lineWidth = 473;
	this.text_6.setTransform(303.9,411.9);

	this.text_7 = new cjs.Text(txt['intro_08'], "bold 16px Arial");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 18;
	this.text_7.lineWidth = 363;
	this.text_7.setTransform(473.7,542.4);

	this.instance = new lib._00093G01();
	this.instance.setTransform(813,151.5,0.5,0.5);

	this.instance_1 = new lib._0008E801();
	this.instance_1.setTransform(322.2,244.3,0.5,0.5);

	this.instance_2 = new lib._00073R01();
	this.instance_2.setTransform(141.6,244.3,0.5,0.5);

	this.instance_3 = new lib._000WSL01();
	this.instance_3.setTransform(670.7,244.3,0.5,0.5);

	this.instance_4 = new lib._000Q4901();
	this.instance_4.setTransform(61.8,151.5,0.5,0.5);

	this.instance_5 = new lib.Mapadebits5();
	this.instance_5.setTransform(900,190.7);

	this.instance_6 = new lib.Mapadebits4();
	this.instance_6.setTransform(720.7,272.4);

	this.instance_7 = new lib.Mapadebits3();
	this.instance_7.setTransform(322.8,268.2);

	this.instance_8 = new lib.Mapadebits2();
	this.instance_8.setTransform(205.6,268.2);

	this.instance_9 = new lib.Mapadebits1();
	this.instance_9.setTransform(63.7,190.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(65.2,403.5,1.047,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(901.5,403.5,1.047,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_2.setTransform(323.8,403.5,1.047,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_3.setTransform(206.7,403.5,1.047,1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_4.setTransform(721.7,403.5,1.047,1);

	this.text_8 = new cjs.Text("1300", "bold 16px Arial");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 18;
	this.text_8.lineWidth = 48;
	this.text_8.setTransform(691.5,500.4);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_5.setTransform(761.5,432.8,0.322,1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s("#000000").ss(1,1,1).rc(-108.65,-9.35,217.3,18.7,6,0,0,6);
	this.shape_6.setTransform(802.6,482.6,1,1,0,0,180);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#D3D1CA").s("#000000").ss(1,1,1).rc(-108.65,-9.35,217.3,18.7,6,0,0,6);
	this.shape_7.setTransform(150.7,482.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f().s("#1A171B").p("ANmBdI7LAAIAAi5IbLAAg");
	this.shape_8.setTransform(585.2,482.6,1.249,1);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#D3D1CA").s().p("AtkBdIAAi5IbJAAIAAC5g");
	this.shape_9.setTransform(585.2,482.6,1.249,1);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f().s("#1A171B").p("ANmBdI7LAAIAAi5IbLAAg");
	this.shape_10.setTransform(367.9,482.6,1.249,1);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AtlBdIAAi5IbLAAIAAC5g");
	this.shape_11.setTransform(367.9,482.6,1.249,1);

	this.text_9 = new cjs.Text("1500", "bold 16px Arial");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 18;
	this.text_9.lineWidth = 50;
	this.text_9.setTransform(903.4,500.4);

	this.text_10 = new cjs.Text("1000", "bold 16px Arial");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 18;
	this.text_10.lineWidth = 53;
	this.text_10.setTransform(472,500.4);

	this.text_11 = new cjs.Text("700", "bold 16px Arial");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 18;
	this.text_11.lineWidth = 37;
	this.text_11.setTransform(259,500.4);

	this.text_12 = new cjs.Text("400", "bold 16px Arial");
	this.text_12.lineHeight = 18;
	this.text_12.lineWidth = 44;
	this.text_12.setTransform(25.9,500.4);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#8BB1D8").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_12.setTransform(342.9,419,0.641,1.979);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_13.setTransform(723.5,419,0.41,1.979);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#D3D1CA").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_14.setTransform(475.9,418.9,1,1.979);
       

        this.addChild(this.logo, this.titulo, this.siguiente,this.shape_14,this.shape_13,this.shape_12,this.text_12,this.text_11,this.text_10,this.text_9,this.shape_11,this.shape_10,this.shape_9,this.shape_8,this.shape_7,this.shape_6,this.shape_5,this.text_8,this.shape_4,this.shape_3,this.shape_2,this.shape_1,this.shape,this.instance_9,this.instance_8,this.instance_7,this.instance_6,this.instance_5,this.instance_4,this.instance_3,this.instance_2,this.instance_1,this.instance,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text,this.btn_02,this.btn_04,this.btn_01,this.btn_03);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame2 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
      	this.btn_next = new lib.Boto_Navegacio();
	this.btn_next.setTransform(924.9,504.1,0.862,1.395);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

if (boton == 2)
	this.btn_zona_1_02 = new lib.btn_zona_1_02("single",1);
    else
	this.btn_zona_1_02 = new lib.btn_zona_1_02();
	this.btn_zona_1_02.setTransform(666,380.2,1,1,0,0,0,100,22.5);
	new cjs.ButtonHelper(this.btn_zona_1_02, 0, 1, 2, false, new lib.btn_zona_1_02(), 3);
if (boton == 1)
	this.btn_zona_1_01 = new lib.btn_zona_1_01("single",1);
    else
	this.btn_zona_1_01 = new lib.btn_zona_1_01();
	this.btn_zona_1_01.setTransform(260.5,380.2,1,1,0,0,0,100,22.5);
	new cjs.ButtonHelper(this.btn_zona_1_01, 0, 1, 2, false, new lib.btn_zona_1_01(), 3);
  if (boton == 1) {
            this.popup = new lib.mc_1_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.mc_1_02("single", 0);
            this.addChild(this.popup);
        }
         if (boton != 1)
            this.btn_zona_1_01.on("click", function (evt) {
                putStage(new lib.frame2(1));
            });
        if (boton != 2)
            this.btn_zona_1_02.on("click", function (evt) {
                putStage(new lib.frame2(2));
            });
	this.text = new cjs.Text(txt['intro_06'], "bold 13px Arial");
	this.text.textAlign = "center";
	this.text.lineHeight = 15;
	this.text.lineWidth = 637;
	this.text.setTransform(583.1,497.5);

	this.instance = new lib.Mapadebits7();
	this.instance.setTransform(664,398.7);

	this.instance_1 = new lib.Mapadebits6();
	this.instance_1.setTransform(258.9,398.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(665.1,506.3,1.047,1);

	this.text_1 = new cjs.Text("622", "bold 16px Arial");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 55;
	this.text_1.setTransform(662.5,432.5);

	this.text_2 = new cjs.Text("400", "bold 18px Arial");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 20;
	this.text_2.lineWidth = 58;
	this.text_2.setTransform(40.2,442.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(259.9,506.3,1.047,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
	this.shape_2.setTransform(475.5,474.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#8BB1D8").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_3.setTransform(585,505,0.748,2.032);

	this.text_3 = new cjs.Text("700", "bold 18px Arial");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 58;
	this.text_3.setTransform(905.7,442.3);

	this.text_4 = new cjs.Text("476", "bold 16px Arial");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 18;
	this.text_4.lineWidth = 55;
	this.text_4.setTransform(257.4,432.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#D3D1CA").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_4.setTransform(475.5,505,1,2.032);

        this.btn_next.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });

        this.addChild(this.logo, this.titulo, this.home, this.btn_next,this.shape_4,this.text_4,this.text_3,this.shape_3,this.shape_2,this.shape_1,this.text_2,this.text_1,this.shape,this.instance_1,this.instance,this.text,this.btn_zona_1_01,this.btn_zona_1_02);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
 
    (lib.frame3 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 0, 0, 0, 0);
       // Capa 1
	this.btn_prev = new lib.Boto_Navegacio();
	this.btn_prev.setTransform(27.1,504.1,0.862,1.395,0,0,180);
	new cjs.ButtonHelper(this.btn_prev, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.btn_next = new lib.Boto_Navegacio();
	this.btn_next.setTransform(924.4,504.1,0.862,1.395);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

if (boton == 3)
	this.btn_zona_2_03 = new lib.btn_zona_2_03("single",1);
    else
	this.btn_zona_2_03 = new lib.btn_zona_2_03();

        this.btn_zona_2_03.setTransform(777.4,380.2,1,1,0,0,0,100,22.5);
	new cjs.ButtonHelper(this.btn_zona_2_03, 0, 1, 2, false, new lib.btn_zona_2_03(), 3);
if (boton == 2)
	this.btn_zona_2_02 = new lib.btn_zona_2_02("single",1);
 else
	this.btn_zona_2_02 = new lib.btn_zona_2_02();
	this.btn_zona_2_02.setTransform(392.5,380.2,1,1,0,0,0,100,22.5);
	new cjs.ButtonHelper(this.btn_zona_2_02, 0, 1, 2, false, new lib.btn_zona_2_02(), 3);

if (boton == 1)
	this.btn_zona_2_01 = new lib.btn_zona_2_01("single",1);
 else
	this.btn_zona_2_01 = new lib.btn_zona_2_01();

        this.btn_zona_2_01.setTransform(171.9,380.2,1,1,0,0,0,100,22.5);
	new cjs.ButtonHelper(this.btn_zona_2_01, 0, 1, 2, false, new lib.btn_zona_2_01(), 3);

if (boton == 1) {
            this.popup = new lib.mc_2_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.mc_2_02("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 3) {
            this.popup = new lib.mc_2_03("single", 0);
            this.addChild(this.popup);
        }
         if (boton != 1)
            this.btn_zona_2_01.on("click", function (evt) {
                putStage(new lib.frame3(1));
            });
        if (boton != 2)
            this.btn_zona_2_02.on("click", function (evt) {
                putStage(new lib.frame3(2));
            });
          if (boton != 3)
            this.btn_zona_2_03.on("click", function (evt) {
                putStage(new lib.frame3(3));
            });  
	this.text = new cjs.Text(txt['intro_06'], "bold 13px Arial");
	this.text.textAlign = "center";
	this.text.lineHeight = 15;
	this.text.lineWidth = 859;
	this.text.setTransform(471.9,497.5);

	this.instance = new lib.Mapadebits10();
	this.instance.setTransform(854.4,398.7);

	this.instance_1 = new lib.Mapadebits9();
	this.instance_1.setTransform(329.5,398.7);

	this.instance_2 = new lib.Mapadebits8();
	this.instance_2.setTransform(87.3,398.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(855.5,506.3,1.047,1);

	this.text_1 = new cjs.Text("982", "bold 16px Arial");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 55;
	this.text_1.setTransform(852.9,432.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(330.5,506.3,1.047,1);

	this.text_2 = new cjs.Text("800", "bold 16px Arial");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 55;
	this.text_2.setTransform(328,432.5);

	this.text_3 = new cjs.Text("700", "bold 18px Arial");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 58;
	this.text_3.setTransform(39.6,442.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_2.setTransform(88.4,506.3,1.047,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
	this.shape_3.setTransform(474.9,474.5);

	this.text_4 = new cjs.Text("1000", "bold 18px Arial");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 20;
	this.text_4.lineWidth = 58;
	this.text_4.setTransform(905.2,442.3);

	this.text_5 = new cjs.Text("711", "bold 16px Arial");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.lineWidth = 55;
	this.text_5.setTransform(85.8,432.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8BB1D8").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_4.setTransform(474.9,505,1,2.032);

      this.btn_prev.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.btn_next.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.home, this.shape_4,this.text_5,this.text_4,this.shape_3,this.shape_2,this.text_3,this.text_2,this.shape_1,this.text_1,this.shape,this.instance_2,this.instance_1,this.instance,this.text,this.btn_zona_2_01,this.btn_zona_2_02,this.btn_zona_2_03,this.btn_next,this.btn_prev);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame4 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 1, 0, 0);
        this.btn_prev = new lib.Boto_Navegacio();
	this.btn_prev.setTransform(27.7,504.1,0.862,1.395,0,0,180);
	new cjs.ButtonHelper(this.btn_prev, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

	this.btn_next = new lib.Boto_Navegacio();
	this.btn_next.setTransform(924.9,504.1,0.862,1.395);
	new cjs.ButtonHelper(this.btn_next, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);
 if (boton == 2) 
	this.btn_zona_3_02 = new lib.btn_zona_3_02("single",1);
else
        this.btn_zona_3_02 = new lib.btn_zona_3_02();
	this.btn_zona_3_02.setTransform(768.9,380.2,1,1,0,0,0,100,22.5);
	new cjs.ButtonHelper(this.btn_zona_3_02, 0, 1, 2, false, new lib.btn_zona_3_02(), 3);
 if (boton == 1) 
	this.btn_zona_3_01 = new lib.btn_zona_3_01("single",1);
        else
	this.btn_zona_3_01 = new lib.btn_zona_3_01();
	this.btn_zona_3_01.setTransform(315.3,380.2,1,1,0,0,0,100,22.5);
	new cjs.ButtonHelper(this.btn_zona_3_01, 0, 1, 2, false, new lib.btn_zona_3_01(), 3);
 if (boton == 1) {
            this.popup = new lib.mc_3_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.mc_3_02("single", 0);
            this.addChild(this.popup);
        }
         if (boton != 1)
            this.btn_zona_3_01.on("click", function (evt) {
                putStage(new lib.frame4(1));
            });
        if (boton != 2)
            this.btn_zona_3_02.on("click", function (evt) {
                putStage(new lib.frame4(2));
            });

	this.text = new cjs.Text(txt['intro_07'], "bold 13px Arial");
	this.text.textAlign = "center";
	this.text.lineHeight = 15;
	this.text.lineWidth = 282;
	this.text.setTransform(762.5,511.5);

	this.text_1 = new cjs.Text(txt['intro_06'], "bold 13px Arial");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 15;
	this.text_1.lineWidth = 574;
	this.text_1.setTransform(329.9,511.5);

	this.instance = new lib.Mapadebits12();
	this.instance.setTransform(836.8,398.7);

	this.instance_1 = new lib.Mapadebits11();
	this.instance_1.setTransform(313.5,398.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(837.9,497.4,1.047,1);

	this.text_2 = new cjs.Text("1271", "bold 16px Arial");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 55;
	this.text_2.setTransform(835.3,432.5);

	this.text_3 = new cjs.Text("1000", "bold 18px Arial");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 58;
	this.text_3.setTransform(40.2,442.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(314.6,497.4,1.047,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
	this.shape_2.setTransform(475.5,474.5);

	this.text_4 = new cjs.Text("1300", "bold 18px Arial");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 20;
	this.text_4.lineWidth = 58;
	this.text_4.setTransform(905.7,442.3);

	this.text_5 = new cjs.Text("1095", "bold 16px Arial");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.lineWidth = 55;
	this.text_5.setTransform(312,432.5);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_3.setTransform(765.5,504.2,0.333,2.073);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8BB1D8").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_4.setTransform(403,505,0.833,2.032);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_5.setTransform(765.5,504.7,0.333,2.052);

       this.btn_prev.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.btn_next.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.home, this.shape_5,this.shape_4,this.shape_3,this.text_5,this.text_4,this.shape_2,this.shape_1,this.text_3,this.text_2,this.shape,this.instance_1,this.instance,this.text_1,this.text,this.btn_zona_3_01,this.btn_zona_3_02,this.btn_next,this.btn_prev);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

    (lib.frame5 = function (boton) {
        this.initialize();
        clearTexts();

        // Capa 1
        basicos(this, 1, 1, 0, 0, 0);
       this.btn_prev = new lib.Boto_Navegacio();
	this.btn_prev.setTransform(27.7,504.1,0.862,1.395,0,0,180);
	new cjs.ButtonHelper(this.btn_prev, 0, 1, 2, false, new lib.Boto_Navegacio(), 3);

if (boton == 3)
	this.btn_zona_4_03 = new lib.btn_zona_4_03("single",1);
   else
	this.btn_zona_4_03 = new lib.btn_zona_4_03();
	this.btn_zona_4_03.setTransform(806.8,380.2,1,1,0,0,0,100,22.5);
	new cjs.ButtonHelper(this.btn_zona_4_03, 0, 1, 2, false, new lib.btn_zona_4_03(), 3);
if (boton == 2)
	this.btn_zona_4_02 = new lib.btn_zona_4_02("single",1);
    else
	this.btn_zona_4_02 = new lib.btn_zona_4_02();
        
	this.btn_zona_4_02.setTransform(475.7,380.2,1,1,0,0,0,100,22.5);
	new cjs.ButtonHelper(this.btn_zona_4_02, 0, 1, 2, false, new lib.btn_zona_4_02(), 3);
if (boton == 1)
	this.btn_zona_4_01 = new lib.btn_zona_4_01("single",1);
    else
	this.btn_zona_4_01 = new lib.btn_zona_4_01();
	this.btn_zona_4_01.setTransform(175.8,380.2,1,1,0,0,0,100,22.5);
	new cjs.ButtonHelper(this.btn_zona_4_01, 0, 1, 2, false, new lib.btn_zona_4_01(), 3);

if (boton == 1) {
            this.popup = new lib.mc_4_01("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 2) {
            this.popup = new lib.mc_4_02("single", 0);
            this.addChild(this.popup);
        }
        if (boton == 3) {
            this.popup = new lib.mc_4_03("single", 0);
            this.addChild(this.popup);
        }
         if (boton != 1)
            this.btn_zona_4_01.on("click", function (evt) {
                putStage(new lib.frame5(1));
            });
        if (boton != 2)
            this.btn_zona_4_02.on("click", function (evt) {
                putStage(new lib.frame5(2));
            });
          if (boton != 3)
            this.btn_zona_4_03.on("click", function (evt) {
                putStage(new lib.frame5(3));
            });  
	this.text = new cjs.Text(txt['intro_07'], "bold 13px Arial");
	this.text.textAlign = "center";
	this.text.lineHeight = 15;
	this.text.lineWidth = 863;
	this.text.setTransform(474.3,508.4);

	this.instance = new lib.Mapadebits15();
	this.instance.setTransform(805.8,398.7);

	this.instance_1 = new lib.Mapadebits14();
	this.instance_1.setTransform(474.7,398.7);

	this.instance_2 = new lib.Mapadebits13();
	this.instance_2.setTransform(174.1,398.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape.setTransform(885,497.4,1.047,1);

	this.text_1 = new cjs.Text("1492", "bold 16px Arial");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 18;
	this.text_1.lineWidth = 55;
	this.text_1.setTransform(804.3,432.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_1.setTransform(475.7,497.4,1.047,1);

	this.text_2 = new cjs.Text("1453", "bold 16px Arial");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 18;
	this.text_2.lineWidth = 55;
	this.text_2.setTransform(473.2,432.5);

	this.text_3 = new cjs.Text("1300", "bold 18px Arial");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 20;
	this.text_3.lineWidth = 58;
	this.text_3.setTransform(40.2,442.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgdAfQgMgNAAgSQAAgRAMgOQAMgNARABQASgBAMANQAMAOAAARQAAASgMANQgMAOgSAAQgRAAgMgOg");
	this.shape_2.setTransform(175.1,497.4,1.047,1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#1D1D1B").ss(4).p("EhD1AAAMCHrAAA");
	this.shape_3.setTransform(475.5,474.5);

	this.text_4 = new cjs.Text("1500", "bold 18px Arial");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 20;
	this.text_4.lineWidth = 58;
	this.text_4.setTransform(905.7,442.3);

	this.text_5 = new cjs.Text("1348", "bold 16px Arial");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 18;
	this.text_5.lineWidth = 55;
	this.text_5.setTransform(172.6,432.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#8FBF67").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_4.setTransform(463,504.7,0.971,2.052);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#D3D1CA").s().p("EhD3ACNIAAkZMCHvAAAIAAEZg");
	this.shape_5.setTransform(475.5,504.7,1,2.052);
   this.btn_prev.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
        this.addChild(this.logo, this.titulo, this.home,this.shape_5,this.shape_4,this.text_5,this.text_4,this.shape_3,this.shape_2,this.text_3,this.text_2,this.shape_1,this.text_1,this.shape,this.instance_2,this.instance_1,this.instance,this.text,this.btn_zona_4_01,this.btn_zona_4_02,this.btn_zona_4_03,this.btn_prev);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);


// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto, size) {
        size = size || '25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho,top) {
        width = 730 - ancho;
        top=top || -482;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, top);
        else
            escena.texto.setTransform(130 + ancho, top);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }
   
   //Simbolillos
   
   
(lib.Mapadebits1 = function() {
	this.initialize(img.Mapadebits1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,218);


(lib.Mapadebits10 = function() {
	this.initialize(img.Mapadebits10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,108);


(lib.Mapadebits11 = function() {
	this.initialize(img.Mapadebits11);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,104);


(lib.Mapadebits12 = function() {
	this.initialize(img.Mapadebits12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,104);


(lib.Mapadebits13 = function() {
	this.initialize(img.Mapadebits13);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,104);


(lib.Mapadebits14 = function() {
	this.initialize(img.Mapadebits14);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,104);


(lib.Mapadebits15 = function() {
	this.initialize(img.Mapadebits15);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,80,100);


(lib.Mapadebits2 = function() {
	this.initialize(img.Mapadebits2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,137);


(lib.Mapadebits3 = function() {
	this.initialize(img.Mapadebits3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,137);


(lib.Mapadebits4 = function() {
	this.initialize(img.Mapadebits4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,137);


(lib.Mapadebits5 = function() {
	this.initialize(img.Mapadebits5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2,218);


(lib.Mapadebits6 = function() {
	this.initialize(img.Mapadebits6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,108);


(lib.Mapadebits7 = function() {
	this.initialize(img.Mapadebits7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,108);


(lib.Mapadebits8 = function() {
	this.initialize(img.Mapadebits8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,108);


(lib.Mapadebits9 = function() {
	this.initialize(img.Mapadebits9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,3,108);

   (lib._00073R01 = function() {
	this.initialize(img._00073R01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,133,150);


(lib._00073R01_1 = function() {
	this.initialize(img._00073R01_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,800,550);


(lib._00073R01_2 = function() {
	this.initialize(img._00073R01_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1106,767);


(lib._0007TL01 = function() {
	this.initialize(img._0007TL01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,403,550);


(lib._0007TL01_1 = function() {
	this.initialize(img._0007TL01_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,479,728);


(lib._0008E801 = function() {
	this.initialize(img._0008E801);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,108,150);


(lib._0008E801_1 = function() {
	this.initialize(img._0008E801_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,397,550);


(lib._0008E801_2 = function() {
	this.initialize(img._0008E801_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,592,755);


(lib._00093G01 = function() {
	this.initialize(img._00093G01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,179,150);


(lib._00093G01_1 = function() {
	this.initialize(img._00093G01_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,656,550);


(lib._00093G01_2 = function() {
	this.initialize(img._00093G01_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,916,768);


(lib._0009O101 = function() {
	this.initialize(img._0009O101);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,418,550);


(lib._0009O101_1 = function() {
	this.initialize(img._0009O101_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,566,748);


(lib._0009T101 = function() {
	this.initialize(img._0009T101);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,429,550);


(lib._0009T101_1 = function() {
	this.initialize(img._0009T101_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,563,719);


(lib._000Q4901 = function() {
	this.initialize(img._000Q4901);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,120,150);


(lib._000Q4901_1 = function() {
	this.initialize(img._000Q4901_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,595,550);


(lib._000Q4901_2 = function() {
	this.initialize(img._000Q4901_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,613,768);


(lib._000WSL01 = function() {
	this.initialize(img._000WSL01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,106,150);


(lib._000WSL01_1 = function() {
	this.initialize(img._000WSL01_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,544,550);


(lib._000WSL01_2 = function() {
	this.initialize(img._000WSL01_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,980,768);


(lib._000YC001 = function() {
	this.initialize(img._000YC001);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,521,550);


(lib._000YC001_1 = function() {
	this.initialize(img._000YC001_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,997,768);


(lib._0026YO01 = function() {
	this.initialize(img._0026YO01);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,396,550);


(lib._0026YO01_1 = function() {
	this.initialize(img._0026YO01_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,511,768);


(lib.pautas950x608nuevosarreglos = function() {
	this.initialize(img.pautas950x608nuevosarreglos);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.MarcaAgua = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
	this.shape.setTransform(30,30);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,60,60);


(lib.mc_Fundido_Int = function() {
	this.initialize();

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("EhJ/AvPMAAAhedMCT/AAAMAAABedg");
	this.shape.setTransform(475,304,1.003,1.005);

	this.addChild(this.shape);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.btn_inicio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
	this.shape.setTransform(0,0,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(0,0,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(0,0,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14.9,-14.9,30,30);


(lib.btn_cerrar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("x", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-2.7,-12.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_1.setTransform(-0.4,5.1,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]}).to({state:[{t:this.shape,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:-4.2,y:-14.4}}]},1).to({state:[{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).to({state:[{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape_1},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.2,-12.8,31,33.1);


(lib.btn_ampliarneg = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("+", "bold 22px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-2.7,-12.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,0,1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
	this.shape.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_1.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_2.setTransform(-0.4,5.1,0.673,0.673);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]}).to({state:[{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.shape,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:-4.2,y:-14.4}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).to({state:[{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.2,-12.8,31,33.1);


(lib.btn_ampliar = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.text = new cjs.Text("+", "bold 22px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 24;
	this.text.lineWidth = 27;
	this.text.setTransform(-2.7,-12.8);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#1E120D").ss(1,0,1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
	this.shape.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
	this.shape_1.setTransform(-0.4,5.1,0.673,0.673);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#1E120D").ss(1,0,1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
	this.shape_2.setTransform(-0.4,5.3,0.74,0.74);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]}).to({state:[{t:this.shape_1,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.shape_2,p:{scaleX:0.74,scaleY:0.74,y:5.3}},{t:this.text,p:{scaleX:1.1,scaleY:1.1,x:-4.2,y:-14.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).to({state:[{t:this.shape_1,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.shape_2,p:{scaleX:0.673,scaleY:0.673,y:5.1}},{t:this.text,p:{scaleX:1,scaleY:1,x:-2.7,y:-12.8}}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-16.2,-12.8,31,33.1);


(lib.Boto_Navegacio = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer: Arrow
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhviXIDfCXIjfCYg");
	this.shape.setTransform(3.8,0.6,0.673,0.673,0,180,0);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgfA6IAAhzIA/AAIAABzg");
	this.shape_1.setTransform(-6.2,0.7);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AiPCpIAAlSIEfAAIAAFSg");
	this.shape_2.setTransform(4.3,1.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1,p:{scaleX:1,scaleY:1,x:-6.2}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.8}}]}).to({state:[{t:this.shape_1,p:{scaleX:1.2,scaleY:1.2,x:-7.6}},{t:this.shape,p:{scaleX:0.808,scaleY:0.808,x:4.4}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1,scaleY:1,x:-6.2}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.8}}]},1).to({state:[{t:this.shape_1,p:{scaleX:1,scaleY:1,x:-6.2}},{t:this.shape,p:{scaleX:0.673,scaleY:0.673,x:3.8}},{t:this.shape_2}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-9.5,-9.6,20.9,20.6);


(lib.btn_zona_4_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Conquista musulmana de la península Ibérica
	this.text = new cjs.Text("Descubrimiento de \nAmérica", "bold 14px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(98,2.6+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(100,22.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D2E6C3").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_1.setTransform(100,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8FBF67").s("#8FBF67").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_2.setTransform(100,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0.1,200,45);


(lib.btn_zona_4_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Conquista musulmana de la península Ibérica
	this.text = new cjs.Text(txt['textfriso_09'], "bold 14px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(98,12+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(100,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D2E6C3").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_1.setTransform(100,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8FBF67").s("#8FBF67").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_2.setTransform(100,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200,45);


(lib.btn_zona_4_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Conquista musulmana de la península Ibérica
	this.text = new cjs.Text(txt['textfriso_08'], "bold 14px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(98,12+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(100,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#E6EEC5").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_1.setTransform(100,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8FBF67").s("#8FBF67").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_2.setTransform(100,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200,45);


(lib.btn_zona_3_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Conquista musulmana de la península Ibérica
	this.text = new cjs.Text(txt['textfriso_07'], "bold 14px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(98,12+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(100,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D2E6C3").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_1.setTransform(100,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8FBF67").s("#8FBF67").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_2.setTransform(100,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200,45);


(lib.btn_zona_3_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Conquista musulmana de la península Ibérica
	this.text = new cjs.Text(txt['textfriso_06'], "bold 14px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(98,12+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(100,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D1E0F0").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_1.setTransform(100,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8BB1D8").s("#8BB1D8").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_2.setTransform(100,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200,45);


(lib.btn_zona_2_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Conquista musulmana de la península Ibérica
	this.text = new cjs.Text('Erik el Rojo \nen Groenlandia', "bold 14px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(98,2.5+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(100,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D1E0F0").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_1.setTransform(100,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8BB1D8").s("#8BB1D8").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_2.setTransform(100,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200,45);


(lib.btn_zona_2_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Conquista musulmana de la península Ibérica
	this.text = new cjs.Text(txt['textfriso_04'], "bold 14px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(98,12+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(100,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D1E0F0").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_1.setTransform(100,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8BB1D8").s("#8BB1D8").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_2.setTransform(100,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200,45);


(lib.btn_zona_2_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Conquista musulmana de la península Ibérica
	this.text = new cjs.Text(txt['textfriso_03'], "bold 14px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(98,2.5+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(100,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D1E0F0").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_1.setTransform(100,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8BB1D8").s("#8BB1D8").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_2.setTransform(100,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200,45);


(lib.btn_zona_1_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Conquista musulmana de la península Ibérica
	this.text = new cjs.Text(txt['textfriso_02'], "bold 14px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(98,12+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(100,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D1E0F0").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_1.setTransform(100,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8BB1D8").s("#8BB1D8").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_2.setTransform(100,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200,45);


(lib.btn_zona_1_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Conquista musulmana de la península Ibérica
	this.text = new cjs.Text(txt['textfriso_01'], "bold 14px Verdana");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(98,2.5+incremento);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text,p:{color:"#000000"}}]}).to({state:[{t:this.text,p:{color:"#FFFFFF"}}]},2).wait(2));

	// Capa 3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(100,22.5);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#D1E0F0").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_1.setTransform(100,22.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#8BB1D8").s("#8BB1D8").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape_2.setTransform(100,22.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape}]}).to({state:[{t:this.shape_1}]},1).to({state:[{t:this.shape_2}]},1).wait(2));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,200,45);


(lib.btn_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.702)").s().p("AtkBdIAAi5IbJAAIAAC5g");
	this.shape.setTransform(21.7,0,1.249,1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#1A171B").p("ANlBdI7JAAIAAi5IbJAAg");
	this.shape_1.setTransform(21.7,0,1.249,1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1F8AB2").s().p("AtkBdIAAi5IbJAAIAAC5g");
	this.shape_2.setTransform(21.7,0,1.249,1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape}]},1).to({state:[]},1).to({state:[{t:this.shape_2},{t:this.shape_1}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,0,0);


(lib.mc_fundido = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,false,{});

	// Capa 1
	this.instance = new lib.mc_Fundido_Int();
	this.instance.setTransform(475,304,1,1,0,0,0,475,304);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1).to({alpha:0.143},0).wait(1).to({alpha:0.286},0).wait(1).to({alpha:0.429},0).wait(1).to({alpha:0.571},0).wait(1).to({alpha:0.714},0).wait(1).to({alpha:0.857},0).wait(1).to({alpha:1},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.mc_4_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.text = new cjs.Text(txt['btn_08'], "bold 14px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(173.8,369.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8FBF67").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(175.8,380.2);

	this.btn_ampliar_08 = new lib.btn_ampliar();
	this.btn_ampliar_08.setTransform(434.5,56.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_08, 0, 1, 2, false, new lib.btn_ampliar(), 3);
 this.btn_ampliar_08.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_08());
        });
	this.instance = new lib._000WSL01_1();
	this.instance.setTransform(178.8,44.2,0.502,0.502);

	this.text_1 = new cjs.Text(txt['text_08'], "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 302;
	this.text_1.setTransform(465,43.3);
var html = createDiv(txt['text_08'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(465, 43-608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.instance},{t:this.btn_ampliar_08},{t:this.shape},{t:this.text}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(75.8,43.3,694.7,359.3);


(lib.mc_4_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.text = new cjs.Text(txt['btn_09'], "bold 14px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(473.7,369.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8FBF67").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(475.7,380.2);

	this.btn_ampliar_09 = new lib.btn_ampliar();
	this.btn_ampliar_09.setTransform(372.8,56.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_09, 0, 1, 2, false, new lib.btn_ampliar(), 3);
 this.btn_ampliar_09.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_09());
        });
	this.instance = new lib._0009O101();
	this.instance.setTransform(178.3,44.2,0.503,0.503);

	this.text_1 = new cjs.Text(txt['text_09'], "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 365;
	this.text_1.setTransform(400.3,43.3);
var html = createDiv(txt['text_09'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(400, 43-608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.instance},{t:this.btn_ampliar_09},{t:this.shape},{t:this.text}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(178.3,43.3,590.6,359.3);


(lib.mc_4_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.text = new cjs.Text(txt['btn_10'], "bold 14px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(804.8,360.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8FBF67").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(806.8,380.2);

	this.btn_ampliar_10 = new lib.btn_ampliar();
	this.btn_ampliar_10.setTransform(437.4,56.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_10, 0, 1, 2, false, new lib.btn_ampliar(), 3);
 this.btn_ampliar_10.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_10());
        });
	this.instance = new lib._00093G01_1();
	this.instance.setTransform(124.1,44.2,0.503,0.503);

	this.text_1 = new cjs.Text(txt['text_10'], "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 356;
	this.text_1.setTransform(464.9,43.3);
var html = createDiv(txt['text_10'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(464, 43-608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.instance},{t:this.btn_ampliar_10},{t:this.shape},{t:this.text}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(124.1,43.3,782.7,359.4);


(lib.mc_3_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.text = new cjs.Text(txt['btn_07'], "bold 14px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(766.9,369.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8FBF67").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(768.9,380.2);

	this.btn_ampliar_07 = new lib.btn_ampliar();
	this.btn_ampliar_07.setTransform(422.1,56.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_07, 0, 1, 2, false, new lib.btn_ampliar(), 3);
 this.btn_ampliar_07.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_07());
        });
	this.instance = new lib._000YC001();
	this.instance.setTransform(176.2,44.2,0.503,0.503);

	this.text_1 = new cjs.Text(txt['text_07'], "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 321;
	this.text_1.setTransform(449.6,43.3);
var html = createDiv(txt['text_07'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(449, 43-608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.instance},{t:this.btn_ampliar_07},{t:this.shape},{t:this.text}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(176.2,43.3,692.7,359.3);


(lib.mc_3_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.text = new cjs.Text(txt['btn_06'], "bold 14px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(313.3,369.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8BB1D8").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(315.3,380.2);

	this.btn_ampliar_06 = new lib.btn_ampliar();
	this.btn_ampliar_06.setTransform(391.1,56.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_06, 0, 1, 2, false, new lib.btn_ampliar(), 3);
 this.btn_ampliar_06.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_06());
        });
	this.instance = new lib._0007TL01();
	this.instance.setTransform(208.8,44.2,0.502,0.502);

	this.text_1 = new cjs.Text(txt['text_06'], "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 317;
	this.text_1.setTransform(421.6,43.3);
var html = createDiv(txt['text_06'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(421, 43-608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.instance},{t:this.btn_ampliar_06},{t:this.shape},{t:this.text}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(208.8,43.3,534.2,359.3);


(lib.mc_2_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.text = new cjs.Text(txt['btn_03'], "bold 14px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(170.5,360.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8BB1D8").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(172.5,380.2);

	this.btn_ampliar_03 = new lib.btn_ampliar();
	this.btn_ampliar_03.setTransform(383.1,56.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_03, 0, 1, 2, false, new lib.btn_ampliar(), 3);
 this.btn_ampliar_03.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_03());
        });
	this.instance = new lib._0026YO01();
	this.instance.setTransform(200.8,44.2,0.502,0.502);

	this.text_1 = new cjs.Text(txt['text_03'], "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 329;
	this.text_1.setTransform(413.6,43.3);
var html = createDiv(txt['text_03'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(413, 43-608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.instance},{t:this.btn_ampliar_03},{t:this.shape},{t:this.text}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(72.5,43.3,674.6,359.3);


(lib.mc_2_03 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.text = new cjs.Text(txt['btn_05'], "bold 14px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(776,360.2);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8BB1D8").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(778,380.2);

	this.btn_ampliar_05 = new lib.btn_ampliarneg();
	this.btn_ampliar_05.setTransform(381.1,56.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_05, 0, 1, 2, false, new lib.btn_ampliarneg(), 3);
 this.btn_ampliar_05.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_05());
        });
	this.instance = new lib._0009T101();
	this.instance.setTransform(180.8,44.2,0.507,0.507);

	this.text_1 = new cjs.Text(txt['text_05'], "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 357;
	this.text_1.setTransform(409.6,43.3);
var html = createDiv(txt['text_05'], "Verdana", "20px", '450px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(409, 43-608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.instance},{t:this.btn_ampliar_05},{t:this.shape},{t:this.text}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(180.8,43.3,697.2,359.3);


(lib.mc_2_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.text = new cjs.Text(txt['btn_04'], "bold 14px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(391,369.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8BB1D8").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(393,380.2);

	this.btn_ampliar_04 = new lib.btn_ampliar();
	this.btn_ampliar_04.setTransform(385.1,56.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_04, 0, 1, 2, false, new lib.btn_ampliar(), 3);
 this.btn_ampliar_04.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_04());
        });
	this.instance = new lib._0008E801_1();
	this.instance.setTransform(200.8,44.2,0.503,0.503);

	this.text_1 = new cjs.Text(txt['text_04'], "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 333;
	this.text_1.setTransform(412.6,43.3);
var html = createDiv(txt['text_04'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(412, 43-608);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.instance},{t:this.btn_ampliar_04},{t:this.shape},{t:this.text}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(200.8,43.3,549.3,359.3);


(lib.mc_1_02 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.text = new cjs.Text(txt['btn_02'], "bold 14px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(664,369.7);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#8BB1D8").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(666,380.2);

	this.btn_ampliar_02 = new lib.btn_ampliar();
	this.btn_ampliar_02.setTransform(478.8,56.9,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_02, 0, 1, 2, false, new lib.btn_ampliar(), 3);
 this.btn_ampliar_02.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_02());
        });
	this.text_1 = new cjs.Text(txt['text_02'], "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 332;
	this.text_1.setTransform(506.8,44.2);
var html = createDiv(txt['text_02'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(506, 43-608);

	this.instance = new lib._00073R01_1();
	this.instance.setTransform(107.4,44.2,0.486,0.486);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.text_1},{t:this.btn_ampliar_02},{t:this.shape},{t:this.text}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(107.4,44.2,735.6,358.5);


(lib.mc_1_01 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// MapaFons
	this.btn_ampliar_01 = new lib.btn_ampliar();
	this.btn_ampliar_01.setTransform(429.1,56.8,0.8,0.8);
	new cjs.ButtonHelper(this.btn_ampliar_01, 0, 1, 2, false, new lib.btn_ampliar(), 3);
   this.btn_ampliar_01.on("click", function (evt) {
            clearTexts();
            putStage(new lib.popup_ampliar_01());
        });
	this.instance = new lib._000Q4901_1();
	this.instance.setTransform(145.8,44.2,0.503,0.503);

	this.text = new cjs.Text("", "bold 14px Verdana", "#FFFFFF");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 189;
	this.text.setTransform(258.5,360.2);

	this.shape = new cjs.Shape();
	//this.shape.graphics.f("#8BB1D8").s("#000000").ss(1,1,1).rr(-100,-22.5,200,45,6);
	this.shape.setTransform(260.5,380.2);

	this.text_1 = new cjs.Text(txt['text_01'], "bold 20px Verdana");
	this.text_1.lineHeight = 22;
	this.text_1.lineWidth = 348;
	this.text_1.setTransform(454.6,43.3);
  var html = createDiv(txt['text_01'], "Verdana", "20px", '350px', '40px', "20px", "185px", "left");
    this.text_1 = new cjs.DOMElement(html);
    this.text_1.setTransform(454, 43-608);
	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.text_1},{t:this.shape},{t:this.text},{t:this.instance},{t:this.btn_ampliar_01}]}).to({state:[]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(145.8,43.3,661.2,359.3);


(lib.popup_ampliar_10 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame5(3));
        });
	// Agua
	this.instance = new lib.MarcaAgua();
	this.instance.setTransform(45,45,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// Imatge
	this.text = new cjs.Text(txt['popup_10'], "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 568;
	this.text.setTransform(188,532.3);

	this.instance_1 = new lib._00093G01_2();
	this.instance_1.setTransform(187.9,44.4,0.628,0.628);

	// Capa 1
	this.instance_2 = new lib.mc_fundido();
	this.instance_2.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_2,this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_09 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame5(2));
        });
	// Agua
	this.instance = new lib.MarcaAgua();
	this.instance.setTransform(45,45,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// Imatge
	this.text = new cjs.Text(txt['popup_09'], "18px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 507;
	this.text.setTransform(219.5,531.3);

	this.instance_1 = new lib._0009O101_1();
	this.instance_1.setTransform(291.5,44.4,0.648,0.648);

	// Capa 1
	this.instance_2 = new lib.mc_fundido();
	this.instance_2.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_2,this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_08 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame5(1));
        });
	// Agua
	this.instance = new lib.MarcaAgua();
	this.instance.setTransform(45,45,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// Imatge
	this.text = new cjs.Text(txt['popup_08'], "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 604;
	this.text.setTransform(162,530.6);

	this.instance_1 = new lib._000WSL01_2();
	this.instance_1.setTransform(162,44.4,0.627,0.627);

	// Capa 1
	this.instance_2 = new lib.mc_fundido();
	this.instance_2.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_2,this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_07 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame4(2));
        });
	// Agua
	this.instance = new lib.MarcaAgua();
	this.instance.setTransform(45,45,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// Imatge
	this.text = new cjs.Text(txt['popup_07'], "italic 18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 620;
	this.text.setTransform(162,530.6);

	this.instance_1 = new lib._000YC001_1();
	this.instance_1.setTransform(162,44.4,0.627,0.627);

	// Capa 1
	this.instance_2 = new lib.mc_fundido();
	this.instance_2.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_2,this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_06 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame4(1));
        });
	// Agua
	this.instance = new lib.MarcaAgua();
	this.instance.setTransform(45,45,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// Imatge
	this.text = new cjs.Text(txt['popup_06'], "18px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 461;
	this.text.setTransform(253,533.6);

	this.instance_1 = new lib._0007TL01_1();
	this.instance_1.setTransform(314.5,44.4,0.672,0.672);

	// Capa 1
	this.instance_2 = new lib.mc_fundido();
	this.instance_2.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_2,this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_05 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame3(3));
        });
	// Agua
	this.instance = new lib.MarcaAgua();
	this.instance.setTransform(45,45,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// Imatge
	this.text = new cjs.Text(txt['popup_05'], "italic 18px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 495;
	this.text.setTransform(225,529.6);
  var html = createDiv(txt['popup_05'], "Verdana", "18px", '500px', '40px', "20px", "185px", "left");
    this.text = new cjs.DOMElement(html);
    this.text.setTransform(225, 529-608);
	this.instance_1 = new lib._0009T101_1();
	this.instance_1.setTransform(285.3,44.4,0.672,0.672);

	// Capa 1
	this.instance_2 = new lib.mc_fundido();
	this.instance_2.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_2,this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_04 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame3(2));
        });
	// Agua
	this.instance = new lib.MarcaAgua();
	this.instance.setTransform(45,45,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// Imatge
	this.text = new cjs.Text(txt['popup_04'], "18px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 371;
	this.text.setTransform(284,527.6);

	this.instance_1 = new lib._0008E801_2();
	this.instance_1.setTransform(285,44.4,0.639,0.639);

	// Capa 1
	this.instance_2 = new lib.mc_fundido();
	this.instance_2.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_2,this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_03 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame3(1));
        });
	// Agua
	this.instance = new lib.MarcaAgua();
	this.instance.setTransform(45,45,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// Imatge
	this.text = new cjs.Text(txt['popup_03'], "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 355;
	this.text.setTransform(313,536);

	this.instance_1 = new lib._0026YO01_1();
	this.instance_1.setTransform(313,44.4,0.632,0.632);

	// Capa 1
	this.instance_2 = new lib.mc_fundido();
	this.instance_2.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_2,this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_02 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame2(2));
        });
	// Agua
	this.instance = new lib.MarcaAgua();
	this.instance.setTransform(45,45,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// Imatge
	this.text = new cjs.Text(txt['popup_02'], "18px Verdana");
	this.text.lineHeight = 20;
	this.text.lineWidth = 744;
	this.text.setTransform(121,537);

	this.instance_1 = new lib._00073R01_2();
	this.instance_1.setTransform(126,44.4,0.632,0.632);

	// Capa 1
	this.instance_2 = new lib.mc_fundido();
	this.instance_2.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_2,this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


(lib.popup_ampliar_01 = function() {
	this.initialize();

	// btn_salir
	this.btn_salir = new lib.btn_cerrar();
	this.btn_salir.setTransform(892.8,53.5);
	new cjs.ButtonHelper(this.btn_salir, 0, 1, 2, false, new lib.btn_cerrar(), 3);
    this.btn_salir.on("click", function (evt) {
            putStage(new lib.frame2(1));
        });
	// Agua
	this.instance = new lib.MarcaAgua();
	this.instance.setTransform(45,45,1,1,0,0,0,30,30);
	this.instance.alpha = 0.301;

	// Imatge
	this.text = new cjs.Text(txt['popup_01'], "18px Verdana");
	this.text.lineHeight = 18;
	this.text.lineWidth = 486;
	this.text.setTransform(232.8,517.6);

	this.instance_1 = new lib._000Q4901_2();
	this.instance_1.setTransform(290.7,43.3,0.606,0.606);

	// Capa 1
	this.instance_2 = new lib.mc_fundido();
	this.instance_2.setTransform(475,304,1,1,0,0,0,475,304);

	this.addChild(this.instance_2,this.instance_1,this.text,this.instance,this.btn_salir);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,950,608);


    (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
(lib.btn_ampliarneg = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#1E120D").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#FFFFFF").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#FFFFFF").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);


    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.btn_practica = function (texto, mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.text = new cjs.Text(texto, "bold 16px Verdana");
        this.text.textAlign = "center";
        this.text.lineHeight = 18;
        this.text.lineWidth = 149;
        this.text.setTransform(74.5, 10);

        this.shape = new cjs.Shape();
        this.shape.graphics.f().s("#000000").ss(1, 1, 1).p("AK4imI1vAAQhGAAAABDIAADHQAABDBGAAIVvAAQBGAAAAhDIAAjHQAAhDhGAAg");
        this.shape.setTransform(76.7, 16.8);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_1.setTransform(76.7, 16.8);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#CCCCCC").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_2.setTransform(76.7, 16.8);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#666666").s().p("Aq3CnQhGAAAAhDIAAjHQAAhDBGAAIVvAAQBGAAAABDIAADHQAABDhGAAg");
        this.shape_3.setTransform(76.7, 16.8);

        this.shape_4 = new cjs.Shape();
        this.shape_4.graphics.f("#FFFFFF").s("#000000").ss(1, 1, 1).rr(-65, -15, 130, 30, 6);
        this.shape_4.setTransform(76.7, 16.8, 1.18, 1.118);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_1}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}).to({state: [{t: this.shape_2}, {t: this.shape}, {t: this.text, p: {color: "#000000"}}]}, 1).to({state: [{t: this.shape_3}, {t: this.text, p: {color: "#FFFFFF"}}]}, 1).to({state: [{t: this.shape_4}, {t: this.text, p: {color: "#000000"}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 153.4, 33.6);

    (lib.fadeText = function (textohtml, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        this.texto = new cjs.DOMElement(textohtml);
        this.texto.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(this.texto).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
    (lib.fadeElement = function (elemento, espera, delay, mode, startPosition, loop) {
        espera = espera || 0;
        delay = delay || 20;
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha = 0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({alpha: 1}, delay).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
       if (childNodes[i].nodeType == 1 && (childNodes[i].nodeName == 'DIV' || childNodes[i].nodeName == 'IMG')){
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}

function chuleta() {
    //Esqueletos popup; BG_09_07_08
    //Cajas con animaciones: FQ_09_08_04 FQ_10_11_01
    //Textos pinchar y popups respuestas: LC_10_10_05
    //gif: MTB_10_02_06
    //Imagen+texto
    this.imagen = new lib.Bitmap45copy();
    var ancho = imagen(this, 1, 0.471, 0.471);
    texto(this, txt['pantalla2_2'], 0, ancho);

//Texto simple
    var html = createDiv(texto, "Verdana", "20px", '770px', '10px', "20px", "185px", "left");
    this.texto = new cjs.DOMElement(html);
    this.texto.setTransform(90, -482);
    //Botón ampliar
    this.ampliar = new lib.btn_ampliar();
    this.ampliar.setTransform(376.7, 178);
    new cjs.ButtonHelper(this.ampliar, 0, 1, 2, false, new lib.btn_ampliar(), 3);

    this.ampliar.on("click", function (evt) {
        putStage(new lib.frame1_1b());
    });

    //Fade text y element
    var html = createDiv(txt['txt_01_01'], "Verdana", "20px", '800px', '100px', "20px", "185px", "left");
    this.texto1 = new lib.fadeText(html, 0);
    this.texto1.setTransform(100, -520);
    var flecha = new lib.flecha();
    this.flechaA = new lib.fadeElement(flecha, 25);
    this.flechaA.setTransform(300.1, 193.2, 1, 1, 0, 0, 0, 5.7, 36.8);
    
    //Botón práctiva
    this.practica = new lib.btn_practica(txt['textbtnpractica']);
        this.practica.setTransform(837, 575, 1, 1, 0, 0, 0, 65, 15);
        new cjs.ButtonHelper(this.practica, 0, 1, 2, false, new lib.btn_practica(), 3);

}