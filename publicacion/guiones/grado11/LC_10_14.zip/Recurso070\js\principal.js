(function (lib, img, cjs, txt) {

    var p; // shortcut to reference prototypes

// stage content:
    (lib.frame1 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 0,0,1,0,0);
        titulo1(this, txt['titulo']);

	this.btn_imatge = new lib.btn_imatge();
	this.btn_imatge.setTransform(475,340.9,1,1,0,0,0,395,188.5);
	new cjs.ButtonHelper(this.btn_imatge, 0, 1, 2, false, new lib.btn_imatge(), 3);
        

 this.btn_imatge.on("click", function (evt) {
            putStage(new lib.frame2());
        });
 this.siguiente.on("click", function (evt) {
            putStage(new lib.frame2());
        });
        this.addChild(this.logo, this.titulo,  this.siguiente, this.btn_imatge);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);

 (lib.frame2 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,0,1,0,0);
        titulo1(this, txt['tit2']);

 this.imagen = new lib._76746394();
        var ancho = imagen(this, 1, 0.503, 0.503);
        //this.instance_1.setTransform(180.5, 299.5, 1, 1, 0, 0, 0, 151.5, 187.5);
        texto(this, txt['text2'], 0, ancho);        

 this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
 this.siguiente.on("click", function (evt) {
            putStage(new lib.frame3());
        });
        this.addChild(this.logo, this.titulo,  this.home,this.texto,this.siguiente, this.imagen);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
     (lib.frame3 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['tit3']);

        texto(this, txt['text3'], 0, 0);        

 this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame2());
        });
 this.siguiente.on("click", function (evt) {
            putStage(new lib.frame4());
        });
        this.addChild(this.logo, this.titulo, this.anterior, this.home,this.texto,this.siguiente, this.imagen);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame4 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['tit4']);
 this.imagen = new lib._95339915();
        var ancho = imagen(this, 1, 0.503, 0.503);
        //this.instance_1.setTransform(180.5, 299.5, 1, 1, 0, 0, 0, 151.5, 187.5);
        texto(this, txt['text4'], 0, ancho);      

 this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame3());
        });
 this.siguiente.on("click", function (evt) {
            putStage(new lib.frame5());
        });
        this.addChild(this.logo, this.titulo, this.anterior, this.home,this.texto,this.siguiente, this.imagen);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame5 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['tit5']);
        this.titulo0=this.titulo;
        titulo2(this, txt['tit5b']);
       this.titulo1=new lib.fadeElement(this.titulo,20);
 this.imagen = new lib.mc_p4();
          this.imagen.setTransform(473,65.4,1,1,0,0,0,434.5,16);
 this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame4());
        });
 this.siguiente.on("click", function (evt) {
            putStage(new lib.frame6());
        });
        this.addChild(this.logo, this.titulo0, this.titulo1, this.anterior, this.home,this.siguiente, this.imagen);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
     (lib.frame6 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,1,0,0);
        titulo2(this, txt['tit6']);
 this.imagen = new lib._76746390();
        var ancho = imagen(this, 1, 0.503, 0.503);
        //this.instance_1.setTransform(180.5, 299.5, 1, 1, 0, 0, 0, 151.5, 187.5);
        texto(this, txt['text6'], 0, ancho);      

 this.home.on("click", function (evt) {
            putStage(new lib.frame1());
        });
 this.anterior.on("click", function (evt) {
            putStage(new lib.frame5());
        });
 this.siguiente.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.addChild(this.logo, this.titulo, this.anterior, this.home,this.texto,this.siguiente, this.imagen);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame7 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 1,1,0,1,0);
        titulo2(this, txt['tit7']);
        texto(this, txt['text7'], 0, 300);   
           
        this.shape = new cjs.Shape();
		this.shape.graphics.f("#187E1B").s().p("AhEhOICJBOIiHBPg");
		this.shape.setTransform(310.1,455,1,0.717,90);
	
		this.shape_1 = new cjs.Shape();
		this.shape_1.graphics.f().s("#187E1B").ss(2,1,1).p("Al7AAIL3AA");
		this.shape_1.setTransform(310.1,410,1.047,1,90);
	
	
		 this.home.on("click", function (evt) {
		            putStage(new lib.frame1());
		        });
		 this.anterior.on("click", function (evt) {
		            putStage(new lib.frame6());
		        });
		 this.informacion.on("click", function (evt) {
		            putStage(new lib.frame8());
		        });
        this.addChild(this.logo, this.titulo, this.shape,this.shape_1,this.anterior, this.home,this.texto,this.informacion);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
    (lib.frame8 = function () {
        this.initialize();
        clearTexts();
        
        // Capa 1
        basicos(this, 0,0,0,0,1);
        texto(this, txt['text8'], 0, 0);      

 this.cerrar.on("click", function (evt) {
            putStage(new lib.frame7());
        });
        this.addChild(this.logo, this.texto,this.cerrar);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 849, 548.3);
    
// symbols:

    function titulo1(escena, texto) {
        var html = createDiv(texto, "Georgia", "31px", '770px', '100px', "20px", "185px", "center");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function titulo2(escena, texto,size) {
        size=size||'25px';
        var html = createDiv(texto, "Verdana", size, '770px', '100px', "20px", "185px", "left");
        escena.titulo = new cjs.DOMElement(html);
        escena.titulo.setTransform(90, -588);
    }
    function texto(escena, texto, side, ancho) {
        width = 730 - ancho;
        var html = createDiv(texto, "Verdana", "20px", width + 'px', '400px', "20px", "185px", "left");
        escena.texto = new cjs.DOMElement(html);
        if (side == 0)
            escena.texto.setTransform(90, -482);
        else
            escena.texto.setTransform(130+ancho, -482);
    }

    function imagen(escena, side, scX, scY) {
        var theBounds = escena.imagen.getBounds();

        if (side == 0)
            escena.imagen.setTransform(90, 130, scX, scY);
        else {
            escena.imagen.setTransform(860 - theBounds.width * scX, 130, scX, scY);
        }
        return theBounds.width * scX;
    }

    /*function basicos(escena, home, anterior, siguiente, informacion, cerrar) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(30, 578);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(83, 578);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(126, 578);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            escena.informacion.setTransform(158.6, 562);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(920, 25, 0.775, 0.733);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
    }*/
    
    function basicos(escena, home, anterior, siguiente, informacion, cerrar, audio) {
        escena.logo = new lib.gris();
        escena.logo.setTransform(45, 45, 1, 1, 0, 0, 0, 30, 30);
        escena.logo.alpha = 0.301;
        if (home == 1) {
            escena.home = new lib.btn_inicio();
            escena.home.setTransform(60, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (home == 2) {
            escena.home = new lib.btn_inicioneg();
            escena.home.setTransform(60, 57,1.15,1.15);
            new cjs.ButtonHelper(escena.home, 0, 1, 2, false, new lib.btn_inicio(), 3);
        }
        if (anterior == 1) {
            escena.anterior = new lib.btn_anterior();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
         if (anterior == 2) {
            escena.anterior = new lib.btn_anteriorneg();
            escena.anterior.setTransform(125, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.anterior, 0, 1, 2, false, new lib.btn_anterior(), 3);
        }
        if (siguiente == 1) {
            escena.siguiente = new lib.btn_siguiente();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
          if (siguiente == 2) {
            escena.siguiente = new lib.btn_siguienteNeg();
            escena.siguiente.setTransform(170, 578,1.15,1.15);
            new cjs.ButtonHelper(escena.siguiente, 0, 1, 2, false, new lib.btn_siguiente(), 3);
        }
        
      if (informacion == 1) {
            escena.informacion = new lib.btn_info();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
      if (informacion == 2) {
            escena.informacion = new lib.btn_infoneg();
            if (audio==1)
            escena.informacion.setTransform(280, 560,1.15,1.15);
        else
            escena.informacion.setTransform(217, 560,1.15,1.15);
            new cjs.ButtonHelper(escena.informacion, 0, 1, 2, false, new lib.btn_info(), 3);
        }
        if (cerrar == 1) {
            escena.cerrar = new lib.btn_cerrar();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
         if (cerrar == 2) {
            escena.cerrar = new lib.btn_cerrarneg();
            escena.cerrar.setTransform(908, 35, 1.15, 1.15);
            new cjs.ButtonHelper(escena.cerrar, 0, 1, 2, false, new lib.btn_cerrar(), 3);
        }
        if (audio == 1) {
            escena.audioplay = new lib.btn_AudioPlay_ok();
            escena.audioplay.setTransform(232, 568, 1.6, 1.6);
            new cjs.ButtonHelper(escena.audioplay, 0, 1, 2, false, new lib.btn_AudioPlay_ok(), 3);
            escena.audiopause = new lib.btn_AudioPause_ok();
            escena.audiopause.setTransform(267, 568, 1.54, 1.54);
            new cjs.ButtonHelper(escena.audiopause, 0, 1, 2, false, new lib.btn_AudioPause_ok(), 3);
            escena.audiopause.visible = false;
        }
    }


    
    
    
    
    
   (lib.fadeElement = function (elemento,espera,mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});
        elemento.alpha=0;
        this.timeline.addTween(cjs.Tween.get(elemento).wait(espera).to({ alpha: 1}, 20).wait(100000));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(0, 0, 950, 608);
  
(lib.mc_texto_B = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("Alimentos", "bold 14px Verdana", "#187E1B");
	this.text.textAlign = "center";
	this.text.lineHeight = 16;
	this.text.lineWidth = 120;
	this.text.setTransform(396.3,33.7);

	this.text_1 = new cjs.Text("frutas frescas", "14px Verdana", "#187E1B");
	this.text_1.textAlign = "center";
	this.text_1.lineHeight = 16;
	this.text_1.lineWidth = 123;
	this.text_1.setTransform(397.4,150.9);

	this.text_2 = new cjs.Text("especies", "14px Verdana", "#187E1B");
	this.text_2.textAlign = "center";
	this.text_2.lineHeight = 16;
	this.text_2.lineWidth = 89;
	this.text_2.setTransform(394.5,107.2);

	this.text_3 = new cjs.Text("conservas", "14px Verdana", "#187E1B");
	this.text_3.textAlign = "center";
	this.text_3.lineHeight = 16;
	this.text_3.lineWidth = 116;
	this.text_3.setTransform(394.5,63.4);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C1CBC1").s().p("A0JJ6IAAzzMAoTAAAIAATzg");
	this.shape.setTransform(400.1,106.6,0.543,1.233);

	this.text_4 = new cjs.Text("Documentos", "bold 14px Verdana", "#187E1B");
	this.text_4.textAlign = "center";
	this.text_4.lineHeight = 16;
	this.text_4.lineWidth = 147;
	this.text_4.setTransform(233,33.7);

	this.text_5 = new cjs.Text("Joyas", "bold 14px Verdana", "#187E1B");
	this.text_5.textAlign = "center";
	this.text_5.lineHeight = 16;
	this.text_5.lineWidth = 120;
	this.text_5.setTransform(66.3,33.7);

	this.text_6 = new cjs.Text("cartas de\nnavegación", "14px Verdana", "#187E1B");
	this.text_6.textAlign = "center";
	this.text_6.lineHeight = 16;
	this.text_6.lineWidth = 93;
	this.text_6.setTransform(233.1,141.5);

	this.text_7 = new cjs.Text("notificaciones\nreales", "14px Verdana", "#187E1B");
	this.text_7.textAlign = "center";
	this.text_7.lineHeight = 16;
	this.text_7.lineWidth = 110;
	this.text_7.setTransform(233.1,97.7);

	this.text_8 = new cjs.Text("mapas de nuevas islas descubiertas", "14px Verdana", "#187E1B");
	this.text_8.textAlign = "center";
	this.text_8.lineHeight = 16;
	this.text_8.lineWidth = 143;
	this.text_8.setTransform(233.1,53.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#C1CBC1").s().p("A0JJ6IAAzzMAoTAAAIAATzg");
	this.shape_1.setTransform(235.7,106.6,0.612,1.233);

	this.text_9 = new cjs.Text("anillos de \nesmeraldas", "14px Verdana", "#187E1B");
	this.text_9.textAlign = "center";
	this.text_9.lineHeight = 16;
	this.text_9.lineWidth = 91;
	this.text_9.setTransform(64.5,141.4);

	this.text_10 = new cjs.Text("pendientes\nde perlas", "14px Verdana", "#187E1B");
	this.text_10.textAlign = "center";
	this.text_10.lineHeight = 16;
	this.text_10.lineWidth = 89;
	this.text_10.setTransform(64.5,92.9);

	this.text_11 = new cjs.Text("collares de oro", "14px Verdana", "#187E1B");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 16;
	this.text_11.lineWidth = 116;
	this.text_11.setTransform(64.5,63.4);

	this.text_12 = new cjs.Text("Texto B:", "bold 20px Verdana", "#187E1B");
	this.text_12.textAlign = "center";
	this.text_12.lineHeight = 22;
	this.text_12.lineWidth = 464;
	this.text_12.setTransform(232.7,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#C1CBC1").s().p("A0JJ6IAAzzMAoTAAAIAATzg");
	this.shape_2.setTransform(70.1,106.6,0.543,1.233);

	this.addChild(this.shape_2,this.text_12,this.text_11,this.text_10,this.text_9,this.shape_1,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.shape,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,470.2,184.9);


(lib.mc_texto_A = function() {
	this.initialize();

	// Capa 1
	this.text = new cjs.Text("mapas de", "14px Verdana", "#2C8BB0");
	this.text.lineHeight = 16;
	this.text.lineWidth = 76;
	this.text.setTransform(208.1,58.7);

	this.text_1 = new cjs.Text("notificaciones reales", "14px Verdana", "#2C8BB0");
	this.text_1.lineHeight = 16;
	this.text_1.lineWidth = 163;
	this.text_1.setTransform(6.4,109.1);

	this.text_2 = new cjs.Text("frutas frescas", "14px Verdana", "#2C8BB0");
	this.text_2.lineHeight = 16;
	this.text_2.lineWidth = 111;
	this.text_2.setTransform(99.8,159.5);

	this.text_3 = new cjs.Text("especies", "14px Verdana", "#2C8BB0");
	this.text_3.lineHeight = 16;
	this.text_3.lineWidth = 80;
	this.text_3.setTransform(222.9,134.3);

	this.text_4 = new cjs.Text("conservas", "14px Verdana", "#2C8BB0");
	this.text_4.lineHeight = 16;
	this.text_4.lineWidth = 80;
	this.text_4.setTransform(126.7,134.3);

	this.text_5 = new cjs.Text("navegación", "14px Verdana", "#2C8BB0");
	this.text_5.lineHeight = 16;
	this.text_5.lineWidth = 93;
	this.text_5.setTransform(6.4,134.3);

	this.text_6 = new cjs.Text("cartas de", "14px Verdana", "#2C8BB0");
	this.text_6.lineHeight = 16;
	this.text_6.lineWidth = 76;
	this.text_6.setTransform(208.1,109.1);

	this.text_7 = new cjs.Text("nuevas islas descubiertas", "14px Verdana", "#2C8BB0");
	this.text_7.lineHeight = 16;
	this.text_7.lineWidth = 204;
	this.text_7.setTransform(6.4,83.9);

	this.text_8 = new cjs.Text("anillos de esmeraldas", "14px Verdana", "#2C8BB0");
	this.text_8.lineHeight = 16;
	this.text_8.lineWidth = 172;
	this.text_8.setTransform(6.4,58.7);

	this.text_9 = new cjs.Text("pendientes de perlas", "14px Verdana", "#2C8BB0");
	this.text_9.lineHeight = 16;
	this.text_9.lineWidth = 166;
	this.text_9.setTransform(143.6,33.5);

	this.text_10 = new cjs.Text("collares de oro", "14px Verdana", "#2C8BB0");
	this.text_10.lineHeight = 16;
	this.text_10.lineWidth = 116;
	this.text_10.setTransform(6.4,33.5);

	this.text_11 = new cjs.Text("Texto A:", "bold 20px Verdana", "#2C8BB0");
	this.text_11.textAlign = "center";
	this.text_11.lineHeight = 22;
	this.text_11.lineWidth = 312;
	this.text_11.setTransform(156.6,0);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#C3CDD0").s().p("A0JJ6IAAzzMAoTAAAIAATzg");
	this.shape.setTransform(159,106.6,1.233,1.233);

	this.addChild(this.shape,this.text_11,this.text_10,this.text_9,this.text_8,this.text_7,this.text_6,this.text_5,this.text_4,this.text_3,this.text_2,this.text_1,this.text);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,318,184.9);


(lib.mc_baul = function() {
	this.initialize();

	// Capa 1
	this.instance = new lib.shutterstock_69348553();
	this.instance.setTransform(0,0,0.243,0.243);

	this.addChild(this.instance);
}).prototype = p = new cjs.Container();
p.nominalBounds = new cjs.Rectangle(0,0,251.4,182);


(lib.mc_p4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// mc_texto_B
	this.instance = new lib.mc_texto_B();
	this.instance.setTransform(405.7,375.5,0.069,0.069,0,0,0,235.1,92.2);
	this.instance.alpha = 0;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(102).to({_off:false},0).wait(1).to({regY:92.4,scaleX:0.15,scaleY:0.15,x:420.9,y:357.6,alpha:0.091},0).wait(1).to({scaleX:0.24,scaleY:0.24,x:436.2,y:339.7,alpha:0.182},0).wait(1).to({scaleX:0.32,scaleY:0.32,x:451.4,y:321.8,alpha:0.273},0).wait(1).to({scaleX:0.41,scaleY:0.41,x:466.7,y:303.9,alpha:0.364},0).wait(1).to({scaleX:0.49,scaleY:0.49,x:482,y:286,alpha:0.455},0).wait(1).to({scaleX:0.58,scaleY:0.58,x:497.2,y:268.1,alpha:0.545},0).wait(1).to({scaleX:0.66,scaleY:0.66,x:512.5,y:250.2,alpha:0.636},0).wait(1).to({scaleX:0.75,scaleY:0.75,x:527.8,y:232.3,alpha:0.727},0).wait(1).to({scaleX:0.83,scaleY:0.83,x:543.1,y:214.4,alpha:0.818},0).wait(1).to({scaleX:0.92,scaleY:0.92,x:558.3,y:196.6,alpha:0.909},0).wait(1).to({scaleX:1,scaleY:1,x:573.6,y:178.6,alpha:1},0).wait(1));

	// mc_texto_A
	this.instance_1 = new lib.mc_texto_A();
	this.instance_1.setTransform(406.4,376.1,0.077,0.077,0,0,0,158.8,92.5);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(69).to({_off:false},0).wait(1).to({regX:159,regY:92.4,scaleX:0.15,scaleY:0.15,x:385.8,y:359.6,alpha:0.083},0).wait(1).to({scaleX:0.23,scaleY:0.23,x:365.1,y:343.1,alpha:0.167},0).wait(1).to({scaleX:0.31,scaleY:0.31,x:344.5,y:326.6,alpha:0.25},0).wait(1).to({scaleX:0.39,scaleY:0.39,x:324,y:310.2,alpha:0.333},0).wait(1).to({scaleX:0.46,scaleY:0.46,x:303.3,y:293.7,alpha:0.417},0).wait(1).to({scaleX:0.54,scaleY:0.54,x:282.7,y:277.2,alpha:0.5},0).wait(1).to({scaleX:0.62,scaleY:0.62,x:262.2,y:260.7,alpha:0.583},0).wait(1).to({scaleX:0.69,scaleY:0.69,x:241.5,y:244.2,alpha:0.667},0).wait(1).to({scaleX:0.77,scaleY:0.77,x:220.9,y:227.8,alpha:0.75},0).wait(1).to({scaleX:0.85,scaleY:0.85,x:200.4,y:211.3,alpha:0.833},0).wait(1).to({scaleX:0.92,scaleY:0.92,x:179.7,y:194.8,alpha:0.917},0).wait(1).to({scaleX:1,scaleY:1,x:159.1,y:178.3,alpha:1},0).wait(33));

	// mc_baul
	this.instance_2 = new lib.mc_baul();
	this.instance_2.setTransform(404.6,373,1,1,0,0,0,125.7,91);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(39).to({_off:false},0).wait(1).to({alpha:0.071},0).wait(1).to({alpha:0.143},0).wait(1).to({alpha:0.214},0).wait(1).to({alpha:0.286},0).wait(1).to({alpha:0.357},0).wait(1).to({alpha:0.429},0).wait(1).to({alpha:0.5},0).wait(1).to({alpha:0.571},0).wait(1).to({alpha:0.643},0).wait(1).to({alpha:0.714},0).wait(1).to({alpha:0.786},0).wait(1).to({alpha:0.857},0).wait(1).to({alpha:0.929},0).wait(1).to({alpha:1},0).wait(61000));


}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(11.6,0,846,32);

  (lib.btn_imatge = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Capa 1
	this.instance = new lib.Mosaico();
	this.instance.setTransform(0,0,0.5,0.5);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("rgba(255,255,255,0.502)").s().p("Eg+dAePMAAAg8dMB87AAAMAAAA8dg");
	this.shape.setTransform(396.4,188.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance},{t:this.shape}]},1).to({state:[{t:this.instance}]},1).to({state:[{t:this.instance}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,790,377);
  (lib._76746390 = function() {
	this.initialize(img._76746390);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,568,750);


(lib._76746394 = function() {
	this.initialize(img._76746394);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,552,750);


(lib._95339915 = function() {
	this.initialize(img._95339915);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,535,750);


(lib.Mosaico = function() {
	this.initialize(img.Mosaico);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1580,754);



(lib.shutterstock_69348553 = function() {
	this.initialize(img.shutterstock_69348553);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1036,750);

 (lib.btn_ampliar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgPBcIAAhNIhMAAIAAgeIBMAAIAAhMIAfAAIAABMIBMAAIAAAeIhMAAIAABNg");
        this.shape.setTransform(0, 5.4);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADNDNQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYIAAFFQAAAZgSARg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_3.setTransform(-0.4, 5.3, 0.74, 0.74);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1}, {t: this.shape, p: {x: 0, y: 5.4}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_3, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {x: -0.3, y: 5.4}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {x: 0.1, y: 5.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15.4, -9.8, 30, 30);
    
    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

    (lib.gris = function () {
        this.initialize();

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#666666").s().p("AipD2QhNg0gghTQgVg2AAg5QABgVACgWQARhuBThIQBUhKBwAAQBvAABUBKQBUBIASBuQADAYAAATQAAA4gXA3QggBThMA0QhMA2hdAAQhdAAhMg2gAhPDYQgRANgIAMQAyAWA2AAQA2AAAzgWQgHgNgTgMQgigZgtAAQgsAAgjAZgAgxBvQg8AFg4AXQgcALgPAKQAeAoApAZQANgRAYgTQAughA2AAQA7AAAuAhQAWARALARQApgaAcglQgPgKgagKQg2gYg9gFQgVgFgeAAQgcAAgVAFgAjuBvQAGAMAEAHQANgKAZgJQBXgpBngBQBnABBZApQAYAIAOAJIAIgRQAUguAFgwIoNAAQADAuAVAwgAEFgTQAAgPgDgJQgHgtgXgoQgYAPgnAOQhRAdhUAAQhTAAhSgcQgqgOgWgPQgXAogHAsIgDAYIILAAIAAAAgAjRidQATANAjANQBJAbBSAAQBSAABHgdQAjgNATgPQgZghgvgeQgKASgWAQQgsAig7AAQg7AAgtgiQgQgKgLgOIgIgKQgsAegaAlgAhqjvIAGAHQAHAJALAGQAjAZAvAAQAwgBAhgZQAPgLAHgOQgygSg1gBQg4AAgyAXg");
        this.shape.setTransform(30, 30);

        this.addChild(this.shape);
    }).prototype = p = new cjs.Container();
    p.nominalBounds = new cjs.Rectangle(0, 0, 60, 60);



    (lib.btn_inicio = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // FlashAICB
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("Ah9CQIAAioIg3ABIC0h4IC1B4Ig1gBIAACnIhPAAIAAiZIhgAAIAACag");
        this.shape.setTransform(0, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(0, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74}}, {t: this.shape, p: {scaleX: 0.74, scaleY: 0.74}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_anterior = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(-3.5, 0, 0.673, 0.673, 180);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(6.5, 0.1, 0.673, 0.673, 180);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673, 180);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673, 180);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: 7.2}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: -3.8}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: 6.5}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: -3.5}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);


    (lib.btn_siguiente = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FFFFFF").s().p("AhviXIDfCXIjfCYg");
        this.shape.setTransform(3.6, 0, 0.673, 0.673);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f("#FFFFFF").s().p("AgvBWIAAirIBgAAIAACrg");
        this.shape_1.setTransform(-6.4, 0, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_2.setTransform(0, 0, 0.673, 0.673);

        this.shape_3 = new cjs.Shape();
        this.shape_3.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_3.setTransform(0, 0, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}).to({state: [{t: this.shape_3, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741, x: -7.1}}, {t: this.shape, p: {scaleX: 0.741, scaleY: 0.741, x: 3.9}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).to({state: [{t: this.shape_3, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, x: -6.4}}, {t: this.shape, p: {scaleX: 0.673, scaleY: 0.673, x: 3.6}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-14.9, -14.9, 30, 30);

    (lib.btn_info = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AgUBbIAAiCIApAAIAACCgAgVg6IAAggIArAAIAAAgg");
        this.shape.setTransform(15.3, 16);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADeCiQAAAZgRASQgSARgZAAIlDAAQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZg");
        this.shape_1.setTransform(15, 15.9, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AihDeQgZAAgSgRQgRgSAAgZIAAlDQAAgZARgSQASgRAZAAIFDAAQAZAAASARQARASAAAZIAAFDQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(15, 15.9, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape_1, p: {scaleX: 0.741, scaleY: 0.741}}, {t: this.shape, p: {scaleX: 1.225, scaleY: 1.054, x: 15.4, y: 15.8}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: 15.3, y: 16}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-15, -15, 30, 30);

    (lib.btn_cerrar = function (mode, startPosition, loop) {
        this.initialize(mode, startPosition, loop, {});

        // Capa 1
        this.shape = new cjs.Shape();
        this.shape.graphics.f("#FEFEFE").s().p("AAcBCIgcgoIgcAoIgwAAIA0hCIg0hBIAyAAIAaAnIAcgnIAxAAIg0BBIA0BCg");
        this.shape.setTransform(-0.4, 4.5);

        this.shape_1 = new cjs.Shape();
        this.shape_1.graphics.f().s("#1E120D").ss(1, 0, 1).p("ADfCjQAAAZgSARQgRASgZAAIlFAAQgYAAgSgSQgSgRAAgZIAAlFQAAgYASgSQASgSAYAAIFFAAQAZAAARASQASASAAAYg");
        this.shape_1.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.shape_2 = new cjs.Shape();
        this.shape_2.graphics.f("#1E120D").s().p("AiiDeQgYAAgSgRQgRgSAAgZIAAlEQAAgYARgSQASgRAYAAIFEAAQAZAAASARQARASAAAYIAAFEQAAAZgRASQgSARgZAAg");
        this.shape_2.setTransform(-0.4, 5.1, 0.673, 0.673);

        this.timeline.addTween(cjs.Tween.get({}).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.5}}]}).to({state: [{t: this.shape_2, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape_1, p: {scaleX: 0.74, scaleY: 0.74, y: 5.3}}, {t: this.shape, p: {scaleX: 1.177, scaleY: 1.177, x: 0.1, y: 5.2}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.9, y: 4.5}}]}, 1).to({state: [{t: this.shape_2, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape_1, p: {scaleX: 0.673, scaleY: 0.673, y: 5.1}}, {t: this.shape, p: {scaleX: 1, scaleY: 1, x: -0.4, y: 4.8}}]}, 1).wait(1));

    }).prototype = p = new cjs.MovieClip();
    p.nominalBounds = new cjs.Rectangle(-19.5, -16.7, 38.7, 40.9);

})(lib = lib || {}, images = images || {}, createjs = createjs || {}, textos = textos || {});
var lib, images, createjs, textos;


function clearTexts() {
    var childNodes = document.body.childNodes;
    for (var i = childNodes.length - 1; i >= 0; i--) {
        if (childNodes[i].nodeType == 1 && childNodes[i].nodeName == 'DIV') {
            var child = childNodes[i];
            if (child != null)
                child.parentNode.removeChild(child);
        }
    }

}
function createDiv(texto, family, size, width, height, top, left, align, id) {

    var html = document.createElement('div');
    html.id = id;
    html.innerHTML = texto;

    html.style.textAlign = align;
    html.style.visibility = "hidden";
    html.style.fontFamily = family;
    html.style.fontSize = size;
    html.style.backgroundColor = "transparent";
    html.style.width = width;
    html.style.height = height;
    html.style.position = "absolute";

    document.body.appendChild(html);
    return html;
}